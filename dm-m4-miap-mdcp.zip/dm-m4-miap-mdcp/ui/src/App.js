import { BrowserRouter, Routes, Route } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import LandingPage from './Components/LandingPage';
import Chatbot from "./Components/Chatbot";
import ChatbotResponse from './Components/Chatbot/chatbot';
import './App.css';
import { FormProvider } from "./FormContext";
import Login from "./Components/LandingPage/login";
import { UserProvider } from "./UserContext";
import PrivateRoute from "./Components/PrivateRoute";
import { ApiProvider } from "./ApiProvider";
function App() {
  return (
    <div className="App">
      <UserProvider>
        <FormProvider>
          <BrowserRouter>
            <ApiProvider>

              <Routes>
                <Route path="/login" element={<Login />} />
                <Route
                  path="/chat"
                  element={
                    <PrivateRoute>
                      <Chatbot />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/"
                  element={
                    <PrivateRoute>
                      <LandingPage />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/chat-bot"
                  element={
                    <PrivateRoute>
                      <ChatbotResponse />
                    </PrivateRoute>
                  }
                />
              </Routes>
            </ApiProvider>
          </BrowserRouter>
        </FormProvider>
      </UserProvider>

    </div>
  );
}

export default App;
