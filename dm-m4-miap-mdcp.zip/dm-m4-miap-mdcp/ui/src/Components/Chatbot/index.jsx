import React, { useState } from 'react';
import pfizerLogoRGB from '../../assets/Pfizer_Logo_Color_RGB 1.svg';
import profileUser from '../../assets/person_outline.svg';
import Topbar from '../../Common/topbar';
import './index.css';
import { useNavigate } from "react-router-dom";
import { useFormContext } from '../../FormContext';
import { useUserContext } from '../../UserContext';
import { useApi } from '../../ApiProvider';

const Chatbot = () => {
    const { formData, handleChange, setFormData } = useFormContext();
    const { fetchData } = useApi();
    const navigate = useNavigate();
    const { user } = useUserContext();

    const [loading, setLoading] = useState(false);  // State to track the loading status
    const [error, setError] = useState({});  // State to track errors for each field

    const handleSubmit = async () => {
        // Perform field validation
        const newError = {};
        if (!formData.invNumber) newError.invNumber = 'INV Number is required.';
        if (!formData.product) newError.product = 'Product is required.';
        if (!formData.complaintDescription) newError.complaintDescription = 'Complaint Description is required.';
        if (!formData.argusNarrative) newError.argusNarrative = 'Argus Narrative is required.';
        if (!formData.dateEventOccurred) newError.dateEventOccurred = 'Date Event Occurred is required.';
        // if (!formData.expirationDate) newError.expirationDate = 'Expiration Date of Product is required.';
        // if (!formData.additionalInfo) newError.additionalInfo = 'Additional Information is required.';

        setError(newError);

        // If no errors, proceed with the API call or any further logic
        if (Object.keys(newError).length === 0) {
            setLoading(true);  // Show loading state when submitting
            try {
                await fetchData();  // Wait for the API call to complete
                // Handle response if needed
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                setLoading(false);  // Hide loading state after response
            }
        }
    };

    const handleClear = () => {
        setFormData({
            invNumber: '',
            product: '',
            complaintDescription: '',
            argusNarrative: '',
            dateEventOccurred: '',
            expirationDate: '',
            additionalInfo: '',
        });
        setError({}); // Clear any existing errors
    };

    return (
        <div className='d-flex flex-column' style={{ fontFamily: 'Product Sans, sans-serif', marginBottom: '40px' }}>
            <Topbar activeTab={"chatbot"} />
            <div className='d-flex flex-column justify-content-center align-items-center'>
                <div className='d-flex flex-column justify-content-center align-items-center'>
                    <img src={pfizerLogoRGB} alt="logo" className='logo-bg' />
                    <div className='d-flex flex-row'>
                        <span className='cs-text text-sz-35'>Hello {user.name}</span>
                        <span className='cs-black d-flex align-self-end text-sz-35 ml-px-5'>,</span>
                    </div>
                </div>
                <div className="card bg-white d-flex flex-column mt-5" style={{ width: "60rem", border: "1px solid #0000C9", borderRadius: "16px", boxShadow: "0px 8px 40px 0px #0000001A" }}>
                    <div className='d-flex flex-row align-items-center mt-2'>
                        <img src={profileUser} alt="user" className='ml-px-17 me-1' />
                        <span className='profile-text-ms mt-1'>User Query</span>
                    </div>
                    <hr />

                    <div className='container mb-3'>
                        <div className='row align-items-center'>
                            {/* INV Number */}
                            <div className="col d-flex flex-column ml-mr-10">
                                <label className='input-label-fs w-90 text-start mb-1'>INV Number</label>
                                <input className='input-mg' name="invNumber" value={formData.invNumber}
                                    onChange={handleChange} />
                                {error.invNumber && <span className="text-danger">{error.invNumber}</span>}
                            </div>

                            {/* Product */}
                            <div className="col-12 col-sm-6 col-md-3">
                                <label className='input-label-fs w-90 text-start mb-1'>Product</label>
                                <input className='input-mg' name="product" value={formData.product}
                                    onChange={handleChange} />
                                {error.product && <span className="text-danger">{error.product}</span>}
                            </div>

                            <div className="col-12 col-sm-6 col-md-3">
                                <label className='input-label-fs w-90 text-start mb-1'>Date Opened </label>
                                <input
                                    className='input-mg input-date'
                                    name="dateEventOccurred"
                                    type="date"
                                    value={formData.dateEventOccurred}
                                    onChange={handleChange}
                                />
                                {error.dateEventOccurred && <span className="text-danger">{error.dateEventOccurred}</span>}
                            </div>
                            <div className="col-12 col-sm-6 col-md-3">
                                <label className='input-label-fs w-90 text-start mb-1'>Expiration Date of Product</label>
                                <input
                                    className='input-mg input-date'
                                    name="expirationDate"
                                    type="date"
                                    value={formData.expirationDate}
                                    onChange={handleChange}
                                />
                                {error.expirationDate && <span className="text-danger">{error.expirationDate}</span>}
                            </div>
                        </div>
                    </div>

                    {/* Complaint Description (Full width row) */}
                    <div className='container mb-3'>
                        <div className='row align-items-center'>
                            <div className="col d-flex flex-column ml-mr-10">
                                <label className='input-label-fs w-90 text-start mb-1'>Complaint Description</label>
                                <textarea className='input-mg' rows="3" name="complaintDescription" value={formData.complaintDescription}
                                    onChange={handleChange} />
                                {error.complaintDescription && <span className="text-danger">{error.complaintDescription}</span>}
                            </div>
                        </div>
                    </div>

                    {/* Argus Narrative (Full width row) */}
                    <div className='container'>
                        <div className='row'>
                            <div className="col d-flex flex-column ml-mr-10">
                                <label className='input-label-fs w-90 text-start mb-1'>Argus Narrative</label>
                                <textarea className='input-mg' rows="3" name="argusNarrative" value={formData.argusNarrative}
                                    onChange={handleChange} />
                                {error.argusNarrative && <span className="text-danger">{error.argusNarrative}</span>}
                            </div>
                        </div>
                    </div>

                    {/* Remaining fields (Date Event Occurred, Expiration Date, etc.) */}
                    <div className='container mt-3 mb-3'>
                        <div className='row align-items-center'>

                            <div className="col d-flex flex-column ml-mr-10">
                                <label className='input-label-fs w-90 text-start mt-1 mb-1'>Additional Information</label>
                                <textarea
                                    className='input-mg'
                                    name="additionalInfo"
                                    value={formData.additionalInfo}
                                    onChange={handleChange}
                                    rows="3"
                                />
                                {error.additionalInfo && <span className="text-danger">{error.additionalInfo}</span>}
                            </div>
                        </div>
                    </div>

                    <div className='d-flex justify-content-end mb-3 mr-10'>
                        {loading ? (
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                        ) : (
                            <div>
                                <button className='button-widget me-2' onClick={handleClear}>
                                    Clear
                                </button>
                                <button className='button-widget' onClick={handleSubmit} disabled={loading}>
                                    Generate Response
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Chatbot;


