import React, { useState, useEffect } from 'react';
import Topbar from '../../Common/topbar';
import profileUser from '../../assets/person_outline.svg';
import bluedot from '../../assets/bluedot.svg';
import filter from '../../assets/filter_list.svg';
import toy from '../../assets/smart_toy.svg';
import circleArrow from '../../assets/circleArrow.svg';
import thumbUp from '../../assets/ThumbsUp.svg';
import thumbDown from '../../assets/ThumbsDown.svg';
import thumbsUpBlue from '../../assets/ThumbsUpBlue.svg'
import thumbsDownBlue from '../../assets/ThumbsDownBlue.svg'
import copy from '../../assets/Copy.svg';
import arrow from '../../assets/ArrowsClockwise.svg';
import './index.css';
import { useNavigate } from "react-router-dom";
import { useFormContext } from '../../FormContext';
import send from '../../assets/send.svg';
import { useApi } from '../../ApiProvider';
import expandCircleUp from '../../assets/expandCircleUp.svg'
import expandCircleDown from '../../assets/expandCircleDown.svg'


const ChatbotResponse = () => {
    const [show, setShow] = useState(false);
    const [feedback, setFeedback] = useState("");
    const [isThumbsUp, setIsThumbsUp] = useState(false);
    const { formData, setFormData } = useFormContext();
    const [collapsedState, setCollapsedState] = useState({});
    const navigate = useNavigate();
    const { fetchData } = useApi();
    const [thumbsState, setThumbsState] = useState([]);
    const [activeIndex, setActiveIndex] = useState(null); // To track the currently active response for feedback



    const { data } = useApi(); // Fetch API data using the custom hook
    const llm_response = data?.llm_response || []; // Use empty array if llm_response is undefined

    useEffect(() => {
        if (llm_response.length > 0) {
            // Initialize collapsedState when llm_response is available
            setCollapsedState(
                llm_response.reduce((acc, _, index) => {
                    acc[index] = true;
                    return acc;
                }, {})
            );

            setThumbsState(
                llm_response.map(() => ({
                    thumbsUpSubmitted: false,
                    thumbsDownSubmitted: false
                }))
            );
        }
    }, [llm_response]); // Re-run this effect whenever llm_response changes

    const toggleCollapse = (index) => {
        setCollapsedState(prevState => ({
            ...prevState,
            [index]: !prevState[index]
        }));
    };

    // Loading check for llm_response data
    if (llm_response.length === 0) {
        return <div>Loading...</div>; // Loading state while waiting for data
    }


    const handleNewQueryClick = () => {

        navigate("/chat");
        //-----------------------------
        setFormData({
            invNumber: '',
            product: '',
            complaintDescription: '',
            argusNarrative: '',
            dateEventOccurred: '',
            expirationDate: '',
            additionalInfo: '',
        });
    };

    const handleShow = (type, index) => {
        setIsThumbsUp(type === 'thumbsUp');
        setActiveIndex(index); // Set the active index for the feedback modal
        setShow(true);
    };

    const handleClose = () => {
        setShow(false);
        setFeedback('');
    };


    const handleSubmit = (e) => {
    
        e.preventDefault();

        const currentTime = new Date().toISOString(); // Get current time in ISO format

        const feedbackData = {
            feedback,
            invNumber: formData.invNumber,
            timestamp: currentTime, // Adding the current time to the data
            type_status: isThumbsUp ? "like" : "dislike"
        };


        fetch('http://10.11.225.163:8000/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(feedbackData), // Send the feedback and timestamp as JSON
        })
            .then(response => response.json()) // Handle the response as JSON
            .then(data => {
                handleClose(); // Close the form after submitting
            })
            .catch((error) => {
                console.error('Error:', error);
            });

            console.log("activeindex>", activeIndex);
            

        setThumbsState((prevThumbsState) => {
            const newState = [...prevThumbsState];
            if (isThumbsUp) {
                newState[activeIndex].thumbsUpSubmitted = true;
            } else {
                newState[activeIndex].thumbsDownSubmitted = true;
            }
            return newState;
        });
        setShow(false)
    };

    // function wordCount(inputString) {
    //     const words = inputString.trim().split(/\s+/);
    //     return words.length;
    // }

    const autoResizeTextarea = (textarea) => {
        textarea.style.height = "auto";
        textarea.style.height = `${textarea.scrollHeight}px`;
    };



    return (
        <div className='d-flex flex-column' style={{ fontFamily: 'Product Sans, sans-serif' }}>
            <Topbar activeTab={"chatbot"} />
            <div className='container-fluid p-4' style={{ backgroundColor: "#F5F5F5" }}>
                <div className='row justify-content-between'>
                    <div>
                        <div className="card bg-white d-flex flex-column" style={{ border: "1px solid #0000001A", borderRadius: "16px" }}>
                            <div className='d-flex flex-row align-items-center justify-content-between p-3'>
                                <div className='d-flex flex-row align-items-center'>
                                    <img src={profileUser} alt="user" className='me-1' />
                                    <span className='profile-text-ms mt-1'>User Query</span>
                                </div>
                                <div>
                                    <button
                                        className='btn cs-text profile-text-ms-20'
                                        style={{
                                            backgroundColor: "transparent",
                                            border: "none",
                                            padding: "0",
                                            fontSize: "inherit",
                                            cursor: "pointer",
                                        }}
                                        onClick={handleNewQueryClick}
                                    >
                                        New Query
                                    </button>
                                </div>
                            </div>
                            <hr className='mt-0' />
                            <div className='container mb-3'>
                                <div className='row align-items-center'>
                                    {/* INV Number */}
                                    <div className="col d-flex flex-column ml-mr-10">
                                        <label className='input-label-fs w-90 text-start mb-1'>INV Number</label>
                                        <input className='input-mg chatbot-input-bg' name="invNumber" value={formData.invNumber} disabled />
                                    </div>

                                    {/* Product */}
                                    <div className="col-12 col-sm-6 col-md-3">
                                        <label className='input-label-fs w-90 text-start mb-1'>Product</label>
                                        <input className='input-mg chatbot-input-bg' name="product" value={formData.product} disabled />
                                    </div>

                                    <div className="col-12 col-sm-6 col-md-3">
                                        <label className='input-label-fs w-90 text-start mb-1'>Date Opened </label>
                                        <input className='input-mg chatbot-input-bg' name="dateEventOccurred" type="date" value={formData.dateEventOccurred} disabled />
                                    </div>
                                    <div className="col-12 col-sm-6 col-md-3">
                                        <label className='input-label-fs w-90 text-start mb-1'>Expiration Date of Product</label>
                                        <input className='input-mg chatbot-input-bg' name="expirationDate" type="date" value={formData.expirationDate} disabled />
                                    </div>
                                </div>
                            </div>

                            <div className="container">
                                <div className="row">
                                    {/* Complaint Description */}
                                    <div className="col d-flex flex-column ml-mr-10">
                                        <label className="input-label-fs w-90 text-start mb-1">Complaint Description</label>
                                        <textarea
                                            className="input-mg chatbot-input-bg"
                                            name="complaintDescription"
                                            value={formData.complaintDescription}
                                            onInput={(e) => autoResizeTextarea(e.target)} // Resize on input
                                            style={{ overflow: "hidden", resize: "none" }} // Hide scrollbars and block manual resize
                                            ref={(el) => el && autoResizeTextarea(el)} // Trigger resize on initial render
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="container">
                                <div className="row">
                                    {/* Argus Narrative */}
                                    <div className="col d-flex flex-column ml-mr-10">
                                        <label className="input-label-fs w-90 text-start mb-1">Argus Narrative</label>
                                        <textarea
                                            className="input-mg chatbot-input-bg"
                                            name="argusNarrative"
                                            value={formData.argusNarrative}
                                            onInput={(e) => autoResizeTextarea(e.target)} // Resize on input
                                            style={{ overflow: "hidden", resize: "none" }} // Hide scrollbars and block manual resize
                                            ref={(el) => el && autoResizeTextarea(el)} // Trigger resize on initial render
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="container mt-3 mb-3">
                                <div className="row align-items-center">
                                    {/* Additional Information */}
                                    <div className="col d-flex flex-column ml-mr-10">
                                        <label className="input-label-fs w-90 text-start mt-1 mb-1">Additional Information</label>
                                        <textarea
                                            className="input-mg chatbot-input-bg"
                                            name="additionalInfo"
                                            value={formData.additionalInfo}
                                            onInput={(e) => autoResizeTextarea(e.target)} // Resize on input
                                            style={{ overflow: "hidden", resize: "none" }} // Hide scrollbars and block manual resize
                                            ref={(el) => el && autoResizeTextarea(el)} // Trigger resize on initial render
                                        />
                                    </div>
                                </div>
                            </div>


                        </div>
                        {/* AI Response */}

                        <div className='d-flex flex-column query-quest-list mt-4'>
                            {llm_response.map((responseItem, index) => {
                                const { thumbsUpSubmitted, thumbsDownSubmitted } = thumbsState[index] || {};

                                return (
                                    <div key={index} className="response-card-container mb-4">
                                        <div className="d-flex flex-row justify-content-between p-3 align-items-center">
                                            <div className="d-flex flex-row align-items-center">
                                                <img src={toy} alt="img" className="me-2" />
                                                <span>{responseItem.complaint_issue}</span>
                                            </div>

                                            {/* Move Accuracy to the extreme right */}
                                            <div className="d-flex flex-row align-items-center ms-auto">
                                                <span className="accuracy-text-cs col-grey me-2">Confidence Score:</span>
                                                <span className="accuracy-text-cs col-green me-2">{responseItem.accuracy || 'NA'}</span>
                                            </div>

                                            <button
                                                className="btn btn-link"
                                                onClick={() => toggleCollapse(index)}
                                                style={{ fontSize: '16px', color: '#007bff' }}
                                            >
                                                {collapsedState[index] ? (
                                                    <img
                                                        src={expandCircleUp}
                                                        alt="expandCircleUp"
                                                        style={{
                                                            marginRight: '4px',
                                                            width: '20px',
                                                            height: '30px',
                                                        }}
                                                    />
                                                ) : (
                                                    <img
                                                        src={expandCircleDown}
                                                        alt="expandCircleDown"
                                                        style={{
                                                            marginRight: '4px',
                                                            width: '20px',
                                                            height: '30px',
                                                        }}
                                                    />
                                                )}
                                            </button>
                                        </div>
                                        <hr className="ms-3 me-3 mt-0" />
                                        {!collapsedState[index] && (
                                            <>
                                                {/* Collapsible Details */}
                                                <div className="response-container d-flex flex-column">
                                                    <div className="d-flex flex-row m-3 gap-3">
                                                        <div className="response-widget flex-grow-1 d-flex flex-column align-items-start">
                                                            <span className="response-grid-title">Complaint Issue</span>
                                                            <p className="pb-3">{responseItem.complaint_issue}</p>
                                                        </div>
                                                        <div className="response-widget flex-grow-1 d-flex flex-column align-items-start">
                                                            <span className="response-grid-title">CAPA Reference</span>
                                                            <p className="pb-3">{responseItem.capa_reference}</p>
                                                        </div>
                                                        <div className="response-widget flex-grow-1 d-flex flex-column align-items-start">
                                                            <span className="response-grid-title">IMDRF Code</span>
                                                            <p className="pb-3">{responseItem.imdrf_code}</p>
                                                        </div>
                                                    </div>
                                                    <div className="response-widget m-3 d-flex flex-column align-items-start">
                                                        <span className="response-grid-title">Hazard Analysis</span>
                                                        <p className="pb-3">{responseItem.hazard_analysis}</p>
                                                    </div>
                                                </div>

                                                {/* Conclusion Section */}
                                                {/* <div className="response-widget m-3 d-flex flex-column align-items-start">
                                                    <span className="response-grid-title">Conclusion</span>
                                                    <p className="paragraph-style pb-3">{responseItem.conclusion}</p>
                                                </div> */}
                                                {/* <div className="response-widget m-3 d-flex flex-column align-items-start">
                                                    <span className="response-grid-title">Conclusion</span>
                                                    <p className="paragraph-style pb-3">
                                                        {responseItem.conclusion.split('\n').map((line, index) => (
                                                            <span key={index}>
                                                                {line}
                                                                <br />
                                                            </span>
                                                        ))}
                                                    </p>
                                                </div> */}

                                                    <div className="response-widget m-3 d-flex flex-column align-items-start">
                                                    <span className="response-grid-title">Conclusion</span>
                                                    <p className="paragraph-style" style={{ textAlign: 'left' }}>
                                                        {responseItem.conclusion.split('\n').map((line, index) => (
                                                        <span key={index} style={{ display: 'block', marginLeft: '0' }}>
                                                            {line.charAt(0).toUpperCase() + line.slice(1)}
                                                            <br />
                                                        </span>
                                                        ))}
                                                    </p>
                                                    </div>




                                                <div className="d-flex flex-row m-3 pb-3 align-items-start">
                                                    <button
                                                        className="border-0 bg-transparent"
                                                        onClick={() => handleShow('thumbsUp', index)}
                                                        disabled={thumbsUpSubmitted || thumbsDownSubmitted} // Disable both buttons after one is submitted
                                                    >
                                                        <img
                                                            src={thumbsUpSubmitted ? thumbsUpBlue : thumbUp}
                                                            alt="thumbsUp"
                                                            className="ms-2"
                                                        />
                                                    </button>
                                                    <button
                                                        className="border-0 bg-transparent"
                                                        onClick={() => handleShow('thumbsDown', index)}
                                                        disabled={thumbsUpSubmitted || thumbsDownSubmitted} // Disable both buttons after one is submitted
                                                    >
                                                        <img
                                                            src={thumbsDownSubmitted ? thumbsDownBlue : thumbDown}
                                                            alt="thumbsDown"
                                                            className="ms-2"
                                                        />
                                                    </button>

                                                    {/* Modal for Feedback */}
                                                    {show && activeIndex === index && (
                                                        <div
                                                            className="modal show d-block"
                                                            tabIndex="-1"
                                                            role="dialog"
                                                            style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                                                        >
                                                            <div
                                                                className="modal-dialog modal-dialog-centered"
                                                                role="document"
                                                                style={{
                                                                    maxWidth: '700px',
                                                                    height: 'auto',
                                                                }}
                                                            >
                                                                <div className="modal-content">
                                                                    <div className="modal-header">
                                                                        {isThumbsUp ? (
                                                                            <h5
                                                                                className="modal-title fw-bold"
                                                                                style={{ color: '#0000C9', fontSize: '18px' }}
                                                                            >
                                                                                Thank you for liking the response!
                                                                            </h5>
                                                                        ) : (
                                                                            <h5
                                                                                className="modal-title fw-bold"
                                                                                style={{ color: '#0000C9', fontSize: '18px' }}
                                                                            >
                                                                                Tell us, how could we do better?
                                                                            </h5>
                                                                        )}
                                                                        <button
                                                                            type="button"
                                                                            className="close btn-close"
                                                                            aria-label="Close"
                                                                            onClick={handleClose}
                                                                        ></button>
                                                                    </div>
                                                                    <div className="modal-body text-start">
                                                                        {isThumbsUp ? (
                                                                            <p>
                                                                                We'd love to hear your feedback—please share your thoughts to help us
                                                                                improve further!
                                                                            </p>
                                                                        ) : (
                                                                            <p>
                                                                                We’re sorry to hear you didn’t like suggestions. Please share what we
                                                                                can do to improve.
                                                                            </p>
                                                                        )}
                                                                        <form onSubmit={handleSubmit}>
                                                                            <div className="mb-3">
                                                                                <textarea
                                                                                    className="form-control"
                                                                                    rows="3"
                                                                                    placeholder="Type here ..."
                                                                                    value={feedback}
                                                                                    onChange={(e) => setFeedback(e.target.value)}
                                                                                    required
                                                                                ></textarea>
                                                                            </div>
                                                                            <button
                                                                                type="submit"
                                                                                className="btn btn-primary w-40"
                                                                                style={{
                                                                                    backgroundColor: '#0000C9',
                                                                                    float: 'right',
                                                                                    borderRadius: '30px',
                                                                                }}
                                                                            >
                                                                                <img
                                                                                    src={send}
                                                                                    alt={'send'}
                                                                                    style={{
                                                                                        marginRight: '4px',
                                                                                        width: '20px',
                                                                                        height: '30px',
                                                                                    }}
                                                                                />
                                                                                Send Feedback
                                                                            </button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    )}
                                                    <img src={copy} alt="icon" className="ms-2" />
                                                    <img src={arrow} alt="icon" />
                                                </div>
                                            </>
                                        )}
                                    </div>
                                );
                            })}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default ChatbotResponse;

