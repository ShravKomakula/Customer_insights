import React, { useState } from "react";
import pfizerLogo from '../../assets/Pfizer_Logo_Color_RGB 1.svg';
import { useNavigate } from "react-router-dom";
import { useUserContext } from "../../UserContext";
export default function Login() {
    const navigate = useNavigate();
    const { loginUser } = useUserContext(); 
    // List of allowed emails
    const allowedEmails = [
        "Teri.Anderson@pfizer.com",
        "Gayathri.Nagarajan@pfizer.com",
        "Vinoth.Muniraj@pfizer.com",
        "Nagapradeep.Banala@pfizer.com",
        "Karthik.Mandadi@pfizer.com",
        "Arasi.Rajendrakumar@pfizer.com",
        "Saravanan.R@pfizer.com",
        "Nitika@pfizer.com",
        "Aditya.Shenoy@pfizer.com",
        "Mohanasundaram.Sanjeevi@pfizer.com",
        "Dinesh.KC@pfizer.com",
        "Vignesh.Sakthivel@pfizer.com",
        "M.Jayaprakash@pfizer.com",
        "Patrick.Knickerbocker@pfizer.com",
        "Jennifer.Mantese@pfizer.com",
        "Jennifer.L.Shufelt@pfizer.com",
        "bob.mosquera@pfizer.com",
        "Fernando.Jaramillo@pfizer.com",
        "Arif.Husain@pfizer.com",
        "subba.chaparala@pfizer.com",
        "govinda.nidigattu@pfizer.com",
        "rishabh.sharma@pfizer.com",
        "sainath.kumar@pfizer.com",
        "David.Meek@pfizer.com",
        "ganesha.moorthi@pfizer.com"
    ];

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleLogin = (e) => {
        e.preventDefault();
    
        const correctPassword = "MDCPgenai098"; // The password for login validation
    
        if (allowedEmails.includes(email.trim()) && password === correctPassword) {
            const user = {
                email,
                name: email.split("@")[0].replace(".", " "), // Example name logic
            };
    
            loginUser(user); 
            navigate("/chat"); 
        } else if (!allowedEmails.includes(email.trim())) {
            setError("Access denied: Your email is not authorized.");
        } else {
            setError("Invalid password. Please try again.");
        }
    };

    return (
        <div
            className="container-fluid vh-100 d-flex align-items-center justify-content-center"
            style={{ fontFamily: "Product Sans, sans-serif" }}
        >
            <div className="row w-100 h-100">
                {/* Left Section */}
                <div
                    className="col-md-6 bg-white d-flex flex-column justify-content-center"
                    style={{ padding: "6rem" }}
                >
                    <div className="text-start">
                        <img
                            src={pfizerLogo}
                            alt="Pfizer Logo"
                            className="mb-4"
                            style={{ maxWidth: "150px" }}
                        />
                    </div>
                    <h2 className="mb-3 text-start" style={{ color: "#000" }}>
                        Welcome to
                    </h2>
                    <h1 className="fw-bold text-start" style={{ color: "#000" }}>
                        Device Investigation <br />
                        <span className="text-primary" style={{ color: "#0000C9" }}>
                            Gen-AI Tool
                        </span>
                    </h1>
                </div>

                {/* Right Section */}
                <div
                    className="col-md-6 d-flex align-items-center justify-content-center"
                    style={{ backgroundColor: "#ECECFF" }}
                >
                    <div className="w-75 p-4 bg-white rounded-3 shadow-sm text-start">
                        <h3 className="text-start mb-4">Log In</h3>
                        
                        <form onSubmit={handleLogin}>
                            <div className="mb-3">
                                <label htmlFor="email" className="form-label">
                                    Email Address
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    className="form-control"
                                    placeholder="Enter your email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="password" className="form-label">
                                    Password
                                </label>
                                <input
                                    type="password"
                                    id="password"
                                    className="form-control"
                                    placeholder="Enter your password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>
                            {error && <p className="text-danger">{error}</p>}
                            <button
                                type="submit"
                                className="btn btn-primary w-40"
                                style={{
                                    backgroundColor: "#0000C9",
                                    float: "right"
                                }}
                            >
                                Login
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
