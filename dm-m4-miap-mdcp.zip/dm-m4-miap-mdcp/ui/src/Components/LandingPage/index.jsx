import React from 'react';
import Topbar from '../../Common/topbar';
import './index.css'
import Dashboard from '../DashboardCard/card';
const LandingPage = () => {
    return (
        <div className='d-flex flex-column'>
            <Topbar activeTab={"dashboard"} />
            <Dashboard />
        </div>
    )
}
export default LandingPage;