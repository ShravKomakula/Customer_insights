import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import target from '../../assets/target.svg';
import infoicon from '../../assets/infoIcon.svg';
 
const Dashboard = () => {
    const [activeTab, setActiveTab] = useState("All Products");
    const [metrics, setMetrics] = useState([]);
    const [chartData, setChartData] = useState({
        chart1: { data: {} },
        chart2: { data: {} },
        chart3: { data: {} },
        chart4: { data: {} },
    });
 
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");
 
    useEffect(() => {
        const { startOfWeek, endOfWeek } = initializeWeek();
        setStartDate(formatDateInput(startOfWeek));
        setEndDate(formatDateInput(endOfWeek));
    }, []);
 
    const initializeWeek = () => {
        const today = new Date();
        const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay() + 1)); // Monday
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6); // Sunday
        return { startOfWeek, endOfWeek };
    };
 
    const formatDateInput = (date) => {
        return date.toISOString().split('T')[0];
    };
 
    const fetchMetrics = async () => {
        const productParam = activeTab === "All Products" ? "all" : activeTab;
 
        console.log("productParam",productParam)
 
        try {
            const responses = await Promise.all([
                axios.get('http://10.11.225.163:8000/get_accuracy_metrics', {
                    params: { start_date: startDate, end_date: endDate, product: productParam },
                }),
                axios.get(`http://10.11.225.163:8000/get_hazard_mapping_accuracy_by_date_range`, {
                    params: { start_date: startDate, end_date: endDate, product: productParam },
                }),
                axios.get(`http://10.11.225.163:8000/get_conclusion_accuracy_by_date_range`, {
                    params: { start_date: startDate, end_date: endDate, product: productParam },
                }),
                axios.get(`http://10.11.225.163:8000/get_accuracy_by_date_range_complaint_issue`, {
                    params: { start_date: startDate, end_date: endDate, product: productParam },
                }),
                axios.get(`http://10.11.225.163:8000/get_overall_accuracy_by_date_range`, {
                    params: { start_date: startDate, end_date: endDate, product: productParam },
                }),
            ]);
                        
            setMetrics(responses[0].data);
            setChartData({
                chart1: { data: responses[1].data },
                chart2: { data: responses[2].data },
                chart3: { data: responses[3].data },
                chart4: { data: responses[4].data },
            });
        } catch (error) {
            console.error("card Error fetching data:", error);
        }
    };
 
    useEffect(() => {
        if (startDate && endDate) {
            fetchMetrics();
        }
    }, [startDate, endDate, activeTab]);
 
    const changeWeek = (direction) => {
        const newStartDate = new Date(startDate);
        const newEndDate = new Date(endDate);
 
        newStartDate.setDate(newStartDate.getDate() + direction * 7);
        newEndDate.setDate(newEndDate.getDate() + direction * 7);
 
        setStartDate(formatDateInput(newStartDate));
        setEndDate(formatDateInput(newEndDate));
    };
 
    // const renderChartCard = (chartId, title, tooltip) => (
    //     <div className="col-md-6 mb-4" style={{ minHeight: '300px' }}>
    //         <div className="card shadow-sm" style={{ height: '100%' }}>
    //             <div className="card-body d-flex flex-column">
    //                 <div className="d-flex justify-content-between align-items-center mb-3">
    //                     <h6 className="card-title mb-0">{title}</h6>
    //                     <img
    //                         src={infoicon}
    //                         alt="info"
    //                         style={{ width: "20px", height: "20px", cursor: "pointer" }}
    //                         title={tooltip}
    //                     />
    //                 </div>
    //                 <div className="chart d-flex justify-content-between align-items-end" style={{ flex: 1 }}>
    //                     {Object.entries(chartData[chartId]?.data || {}).map(([day, percentage], index) => (
    //                         <div key={index} className="text-center" style={{ flex: 1 }}>
    //                             <div
    //                                 style={{
    //                                     width: "10px",
    //                                     height: `${parseFloat(percentage) * 2}px`,
    //                                     backgroundColor: "#0000C9",
    //                                     margin: "0 auto",
    //                                 }}
    //                             ></div>
    //                             <small className="text-muted">{day}</small>
    //                             <div style={{ fontSize: "0.9rem", color: "#0000C9" }}>{percentage}</div>
    //                         </div>
    //                     ))}
    //                 </div>
    //             </div>
    //         </div>
    //     </div>
    // );
    
    
    
    const renderChartCard = (chartId, title, tooltip) => (
        <div className="col-md-6 mb-4" style={{ minHeight: '300px' }}>
            <div className="card shadow-sm" style={{ height: '100%' }}>
                <div className="card-body d-flex flex-column">
                    <div className="d-flex justify-content-between align-items-center mb-3">
                        <h6 className="card-title mb-0">{title}</h6>
                        <img
                            src={infoicon}
                            alt="info"
                            style={{ width: "20px", height: "20px", cursor: "pointer" }}
                            title={tooltip}
                        />
                    </div>
                    <div className="chart d-flex justify-content-between align-items-end" style={{ flex: 1 }}>
                        {Object.entries(chartData[chartId]?.data || {}).map(([day, value], index) => {
                            // Split the value to get percentage and count
                            const [percentage, count] = value.split(",");
                            const percentageValue = parseFloat(percentage.replace("%", "")) || 0;
    
                            return (
                                <div key={index} className="text-center" style={{ flex: 1 }}>
                                    {/* Number (count) above the bar */}
                                    <div style={{ fontSize: "0.9rem", color: "#0000C9", marginBottom: "5px" }}>
                                        {count}
                                    </div>
                                    {/* Bar */}
                                    <div
                                        style={{
                                            width: "10px",
                                            height: `${percentageValue * 2}px`,
                                            backgroundColor: "#0000C9",
                                            margin: "0 auto",
                                        }}
                                    ></div>
                                    {/* Percentage below the bar */}
                                    <div style={{ fontSize: "0.8rem", color: "#0000C9", marginTop: "5px" }}>
                                        {percentage}
                                    </div>
                                    {/* Day */}
                                    <small className="text-muted">{day}</small>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
    
    
    
    return (
        <div className="container-fluid" style={{ fontFamily: "Arial, sans-serif", backgroundColor: "#f9f9f9" }}>
                
            {/* Filters Section */}
            <div className="row mb-4">
                <div className="col-md-4">
                    <label htmlFor="product-filter" className="form-label">Select Product</label>
                    <select
                        id="product-filter"
                        className="form-select"
                        value={activeTab}
                        onChange={(e) => setActiveTab(e.target.value)}
                    >
                        <option value="All Products">All Products</option>
                        <option value="U2">U2</option>
                        <option value="Abrysvo">Abrysvo</option>
                    </select>
                </div>
                <div className="col-md-4">
                    <label htmlFor="start-date" className="form-label">Start Date</label>
                    <input
                        type="date"
                        id="start-date"
                        className="form-control"
                        value={startDate}
                        readOnly
                        onChange={(e) => setStartDate(e.target.value)}
                    />
                </div>
                <div className="col-md-4">
                    <label htmlFor="end-date" className="form-label">End Date</label>
                    <input
                        type="date"
                        id="end-date"
                        className="form-control"
                        value={endDate}
                        readOnly
                        onChange={(e) => setEndDate(e.target.value)}
                    />
                </div>
            </div>
 
            <div className="row mb-4">
                <div className="col">
                    <button className="btn btn-primary me-2" onClick={() => changeWeek(-1)}>Previous Week</button>
                    <button className="btn btn-primary" onClick={() => changeWeek(1)}>Next Week</button>
                </div>
            </div>

            <div className="row mt-4">
                {metrics.filter((e) => e.title !== "Overall Prediction Accuracy").map((metric, index) => (
                    <div key={index} className="col-lg-4 col-md-6 mb-4">
                        <div className="card shadow-sm p-3 border-0 h-100">
                            <div className="d-flex flex-row">
                                <div className="d-flex flex-column">
                                    <div className='d-flex flex-row'>
                                        <p className="text-muted" style={{ fontSize: '0.9rem' }}>{metric.title}</p>
                                        <img
                                            src={infoicon}
                                            alt="icon"
                                            style={{ width: "20px", height: "20px", marginLeft: '4px', cursor: 'pointer' }}
                                            data-bs-toggle="tooltip"
                                            title={metric.tooltip}
                                        />
                                    </div>
                                    <h5>{metric.value}</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
 
            {/* Charts Section */}
            <div className="row">
                {renderChartCard("chart1", "Hazard Mapping Accuracy", "Accuracy by hazard type")}
                {renderChartCard("chart2", "Conclusion Accuracy", "Conclusion accuracy")}
                {renderChartCard("chart3", "Complaint Accuracy", "Complaint accuracy")}
                {/* {renderChartCard("chart4", "Overall Accuracy", "Overall accuracy")} */}
            </div>
        </div>
    );
};
 
export default Dashboard;