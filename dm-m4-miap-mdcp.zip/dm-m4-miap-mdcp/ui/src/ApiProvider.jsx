import React, { createContext, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { useFormContext } from "./FormContext";

// Create a context
const ApiContext = createContext();

// ApiProvider component to handle data fetching
export const ApiProvider = ({ children }) => {
    const { formData } = useFormContext();
    const [data, setData] = useState(null);
    const [error, setError] = useState(""); // State to store error message
    const navigate = useNavigate();

    // Fetch data from the API
    const fetchData = async () => {
        try {
            // POST request to the API
            const response = await fetch('http://10.11.225.163:8000/get_llm_response', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error('Failed to generate response');
            }

            const data = await response.json();
            setData(data);
            console.log('Response Data:', data);

            // Navigate to chatbot page after success
            navigate("/chat-bot");
        } catch (err) {
            console.error("Error:", err);
            setError("LLM response not found in the search response.");

            // Hide error popup after 5 seconds
            setTimeout(() => {
                setError("");
            }, 5000);
        }
    };

    return (
        <ApiContext.Provider value={{ data, fetchData }}>
            {children}

            {/* Error Popup */}
            {error && (
                <div style={popupStyle}>
                    {error}
                </div>
            )}
        </ApiContext.Provider>
    );
};

// Custom hook to use the API context
export const useApi = () => {
    return useContext(ApiContext);
};

// Popup Styling
const popupStyle = {
    position: "fixed",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    backgroundColor: "#ff4d4d",
    color: "white",
    padding: "15px 30px",
    borderRadius: "10px",
    boxShadow: "0px 0px 10px rgba(0,0,0,0.2)",
    zIndex: 1000,
};
