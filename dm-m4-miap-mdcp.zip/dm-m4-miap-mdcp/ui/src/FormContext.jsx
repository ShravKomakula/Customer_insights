import React, { createContext, useState, useContext } from "react";
 
const FormContext = createContext();
 
export const FormProvider = ({ children }) => {
    const [formData, setFormData] = useState({});
    
    const handleChange = (e) => {
        const { name, value } = e.target;        
        setFormData({ ...formData, [name]: value });
    };
 
    return (
        <FormContext.Provider value={{ formData, handleChange,setFormData }}>
            {children}
        </FormContext.Provider>
    );
};
 
export const useFormContext = () => useContext(FormContext);
 