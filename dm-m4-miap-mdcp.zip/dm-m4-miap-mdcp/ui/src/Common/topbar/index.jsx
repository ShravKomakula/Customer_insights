import React, { useState, useRef, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import pfizerLogo from '../../assets/pfizer-logo-topbar.svg';
import profileImg from '../../assets/defaultProfile.svg';
import './index.css';
import { useNavigate } from "react-router-dom";
import logOut from '../../assets/logout.svg'
import { useUserContext } from '../../UserContext';
const Topbar = () => {
    const { user, logoutUser } = useUserContext();
    const [dropdownVisible, setDropdownVisible] = useState(false);
    const dropdownRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setDropdownVisible(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const navigate = useNavigate();

    const handleLogOut = () => {
        navigate("/login");
        logoutUser()
    };
    
    return (
        <div className='d-flex topbar-widget flex-row align-items-center justify-content-between' style={{ fontFamily: 'Product Sans, sans-serif' }}>
            <div className='d-flex flex-row align-items-center'>
                <div>
                    <img src={pfizerLogo} alt="logo" />
                </div>
                <div className='custom-tab-info'>
                    <ul className="nav nav-tabs">
                        <li className="nav-item">
                            <NavLink
                                to="/"
                                className="nav-link"
                                exact
                                activeClassName="active"
                            >
                                Dashboard
                            </NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink
                                to="/chat"
                                className="nav-link"
                                activeClassName="active"
                            >
                                Chatbot
                            </NavLink>
                        </li>
                    </ul>
                </div>
            </div>
            <div className='d-flex align-items-center' style={{cursor: 'pointer'}} onClick={() => setDropdownVisible(!dropdownVisible)}>
                <span className='me-3'>{user.name || "Guest"}</span>

                {dropdownVisible && (
                    <div className='logout-div' style={{ display: 'flex', flexDirection: 'row'}}>
                        <img src={logOut} alt={'logout'} />
                        <button className='logout-button'  onClick={handleLogOut}>Logout</button> 
                    </div>
                )}
            </div>
        </div>
    );
};

export default Topbar;
