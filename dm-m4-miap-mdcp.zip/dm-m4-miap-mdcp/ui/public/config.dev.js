window._env_ = {
    API_BASE_URL: "https://mdcp-backend-dev.pfizer.com",
    Env:"Dev",
    BASE_URL : "https://mdcp-dev.pfizer.com/",
    Federate_URL:"https://devfederate.pfizer.com/as/authorization.oauth2?client_id=mdcp_client&grant_type=authorization_code&response_type=code&scope=edit&redirect_uri=https://mdcp-dev.pfizer.com",
     EnbrelUpstreamURL : ""
  };