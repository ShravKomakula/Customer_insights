from .get_information_from_tables import final_text,abrsyvo_complaint_issue,u2_complaint_issue,abrysvo_hazard_mappings,u2_hazard_mappings
from .context import context
import pandas as pd



def prompt_template(investigation_number,device_name,complaint_description,argus_narative,contact_date,expiration_date,parent_additional_information):
    # Hazard IDs, Hazard-Hazardous Situation
   prompt_template =f"""
    
    You are a Medical Device Analyst use the following pieces of context and question
    from a dataset to answer user's question.
    If you don't know the answer, reply "NA" for the fields that are required in output.
    Be concise and don't hallucinate.


    
    ###
    Context: {context}
             Go through in depth for '(Instructions for Use)' column to identify accurate 'Complaint Issue' and based on that 'IMDRF Code','CAPA Reference' 
             and also carefully understanding the 'Hazardous Situation' to fetch the most accurate 'Hazard ID + Hazard' based on the device and don't give false information as it is misleading investigation.
             'Hazardous Situation' is a column to consider very deeply to fetch correct Hazard ID + Hazard.
             \n
             {final_text}

    Question: Based on Complaint Description,Argus Narrative,Parent Additional information derive Conclusion,Complaint Issue,CAPA Reference,IMDRF Code,Hazard Id + Hazard Name | Hazard sitauation and Actual Failure.
              Given the below Inputs :
                    Investigation Number : {investigation_number}
                    Device Name : {device_name}
                    Complaint Description : {complaint_description}
                    Argus Narrative : {argus_narative}
                    contact_date : {contact_date}
                    expiration_date : {expiration_date}
                    parent_additional_information : {parent_additional_information}
    Answer:Should be in json that i have specified below and should follow exactly the content what i have asked
    ```json
    {{ 
       "Conclusion": "(conclusion must have 4 parts.
                       each thing should be covered in each line. and every point should start in new line.
 
                           Complaint Overview:
                               This investigation is based on the information captured in the Complaint Description and Argus report, if applicable, the corresponding Argus Report.
                               The Complaint Issue (enter the Complaint Issue exactly as selected in the Complaint Issue field above and observe each and every Complaint issue meticulosly to response accurate answer) was reported.
                               If necessary, provide further explanation or rationale for why or how the Complaint Issue was selected in this section in depth.
                              
                           Risk Management Review:
                               The Risk Management File was reviewed to confirm that the Hazard(IDs) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX# (enter the INX# of the document reviewed), Version # (enter the Version number of the document reviewed)).
                            (Please deeply understand and retrieve information for the product asked don't hallicunate and provide wrong information as it will mislead investigation..)                              

                            Trend Analysis:
                               All complaint investigations are trended. There is no current trend alert documented.
                          
                            CAPA Reference:
                               (Note: If there is a CAPA associated with the Complaint Issue being investigated, document the associated CAPA ID in the CAPA field. If no CAPA is associated, mark it as "NA.)",
      
       "Complaint Issue" :"(Based on the data provided for U2 and Abrysvo devices, identify the complaint issue accurately ensuring no misleading for this as it become crucial for investigation. Please use accurate Instruction of use to answer complaint Issue.)
                          Identify all possible Complaint Issues for {device_name}, ensuring accuracy to avoid misleading or incorrect investigations. Carefully review the 'Instructions for Use' to respond correctly. If the instructions indicate other more specific issues, refer to them and provide the correct response.
                          {abrsyvo_complaint_issue if device_name=='Abrysvo' else u2_complaint_issue}
                         
       Hazard Analysis: "Identify hazards, Hazard IDs, and Hazardous Situations based on the Complaint Issue and Description, considering the device. Provide precise and accurate information without assumptions or exaggerations. Use '|' to separate each item and format accordingly."
                         from the below hazard situations for the product select appropriate Hazard Id+Hazard and situation.\n
                         Below are the Hazard id + Hazard Name along with Hazard Situtation for {device_name}
                         {abrysvo_hazard_mappings if device_name=='Abrysvo' else u2_hazard_mappings}
 
       IMDRF Code:"Determine the appropriate IMDRF Code based on the Complaint Issue for the product. Stick strictly to the provided IMDRF Code data without any assumptions. Return the code that corresponds to the Complaint Issue.
                   (Get all possible IMDRF code that is possible)
                   Provide the relevant IMDRF Code based on the given complaint",
                
 
       CAPA Reference:"(Based on the IMDRF Code, provide the correct CAPA Reference linked to it. Ensure the IMDRF Code is checked thoroughly. If no CAPA is associated with the IMDRF Code, mark it as "NA." If there is a corresponding CAPA, provide the correct reference.
                       Return the correct CAPA Reference based on the IMDRF Code.)",
 
 
       Actual Failure:"(Was the device the actual failure? Provide the answer in YES or NO.)",
 
       Explanation:"(Explain why the selected Complaint Issue is being chosen. Provide a brief rationale for your selection.)"
 
   }}
   ```   
   """
# (Get all Complaint Issue whatever is possible but should be very accurate as this can lead to false investigation and can divert it.Take a deep study for this.)",
                        #   Below are the Complaint Issues for {device_name} look carefull through '(Instructions for Use)' to answer ('Complaint Issue') well don't answer false infromation or out of context and if '(Instructions for Use)' contains [there are other more specific complaint issues to be used] please look through relevant complaint and answer it correctly






#  Instructions: If the complaint is about cartridge shattered the complaint issue is 'Cartridge Broken/pen' issue similiary analyze each complaint and derive exact Complaint Issue
   return prompt_template


# "Based on the Complaint Issue and Complaint Description, map and identify the hazards along with their associated Hazard IDs and Hazardous Situations and the device should be taken into consideration, don't hallicunate and provide accurate response. Use "|" as a separator between each piece of information, and format as follows:
                        # (Get the one which is most accurate and close one don't hallicunate and provide correct information,don't mislead.)",


#  Mentioned below data for Abrysvo Complaint Issue, have given you again to understand well.
#                           {abrsyvo_complaint_issue}
#                           Up to the point of the Abrysvo Complaint Issue, the process has been completed.

#                            Mentioned below data for U2 Complaint Issue, have given you again to understand well.
#                            {u2_complaint_issue}
#                            Up to the point of the Abrysvo Complaint Issue, the process has been completed.
       