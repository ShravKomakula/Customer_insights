import requests
from .config import *
import json


def get_status(request_id, token):
    """
    Fetches the status of a request by its ID from a specified URL.

    This function sends a `GET` request to a status URL, appending the `request_id` as a query parameter. 
    It uses the provided `token` for authorization and retrieves the status of the request as a JSON response.

    Parameters:
    request_id (str): The unique identifier for the request whose status needs to be fetched.
    token (str): The authorization token used for authenticating the request.

    Returns:
    dict: A dictionary containing the response from the server, typically with the status of the request.

    Raises:
    Exception: If an error occurs during the HTTP request (e.g., network issues, invalid status code), 
               the exception is caught and printed.

    Example:
    >>> status = get_request_status("12345", "your_token")
    >>> print(status)
    {"status": "success", "message": "Request processed successfully"}
    """
    try:
        url = f"{STATUS_URL}?request_id={request_id}"
        headers = {
          'Content-Type': 'application/json',
          'Authorization': f'Bearer {token}'
        }
        response = requests.get(url, headers=headers)
        return response.json()
    except Exception as e:
        print(e)