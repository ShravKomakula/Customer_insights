import requests
import json
from .config import *


def ingest_document(presigned_url,token):
    """
    Submits a document to the ingestion endpoint with customizable chunking and metadata options.

    The function sends a POST request to an ingestion API using the provided pre-signed URL of the document. 
    It includes customizable parameters like document chunk size, overlap size, chunking strategy, and metadata schema.
    The request is authorized using a bearer token.

    Parameters:
    presigned_url (str): A URL pointing to the document to be ingested.
    token (str): Authorization token for authenticating the request.

    Returns:
    dict: The server's JSON response, which will indicate whether the ingestion was successful.

    Optional Parameters:
    - document_chunk_size (int): Size of each document chunk (defaults to 1000).
    - document_overlap_size (int): Size of overlapping content between chunks (defaults to 100).
    - document_chunking_strategy (str): Strategy for chunking, default is "RecursiveCharacterTextSplitter".
    - metadata_schema (dict): The schema for metadata about the document, e.g., "place", "name", "title".

    Example:
    >>> response = ingest_document("https://example.com/document", "your_token")
    >>> print(response)
    {'status': 'success', 'message': 'Document ingested'}
    """
    try:
        url = INGEST_URL
        payload = json.dumps({
            "src_document_path": presigned_url,
            "metadata": {
                "program": "booster"
            },
            "document_chunk_size": 500, #optional, it defaults to 1000
            "document_overlap_size": 50, #optional, it defaults to 100
            "document_chunking_strategy" :"RecursiveCharacterTextSplitter",
            # "document_chunking_strategy" :"SemanticSearchTextSplitter",
            "index": ["vectordb"],
            "engine": "text-embedding-ada-002",
            "update_document":True,
            "extract_table_image_element":True,
            "advance_table_filter":False,
            "embed_raw_table":False,
            "chunked_as_parent_child":True,
            "metadata_schema": {
                        "place": {"type": "string"},
                        "name": {"type": "string"},
                        "title": {"type": "string"}
            }            
        })
        headers = {
          'Content-Type': 'application/json',
          'Authorization': f'Bearer {token}'
        }
        response = requests.post(url, headers=headers, data=payload)
        return response.json()
    except Exception as e:
        print(e)