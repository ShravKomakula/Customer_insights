from .complaints_with_issues import *





def prompt_template(Product,Complaint_Description,Argus_Narrative,Additional_Information,date_opened,Expiration_Date_of_Product):
   Final_prompt =f"""
   Given the following inputs:  
      - Device Name: {Product}  
      - Complaint Description: {Complaint_Description}  
      - Argus Narrative: {Argus_Narrative} 
      - Additional Information: {Additional_Information} 
      - Date Opened : {date_opened}
      - batch_expiration_date : {Expiration_Date_of_Product}
   
   Please use the provided details for {'U2' if (Product=='u2' or Product == "U2") else 'Abrsyvo'}
   {u2_complaint_issue_with_capa_imdrf if (Product=='u2' or Product == "U2") else abrsyvo_complaint_issue_with_capa_imdrf}

   Please use the provided (Hazard Id- Hazard + Hazard Situation) from the given list for {'U2' if (Product=='u2' or Product == "U2") else 'Abrsyvo'}
   {U2_hazards if (Product=='u2' or Product == "U2") else abrysvo_hazards}
   Always use the above Hazard Id, Hazard + Hazard Situation based on ['Complaint Issue'] or Complaint Description, Argus Narrative, and Additional Information.
   And never make any assumptions on your own use the provided data only.
      
   use the Verion number as {'INX100281795 Version 9.0' if (Product=='u2' or Product == "U2") else 'INX100366593 Version 7.0'}

   Use below Json structure as output structure for each Complaint Issue seperately.
   ```json
      [
         {{
            "Complaint Issue": "(Top 3 complaint issues which should be from ['Complaint Issue'] information provided)",
            "IMDRF Code" : "(Get correct ['IMDRF Code'] with the provided information only which is linked to ['Complaint Issue'])",
            "CAPA Reference" : "(Get correct CAPA Refernce)",
            "Hazard Id + Hazard Situation" : "(Get me correct [Hazard Id + Hazard Situation] associated with [Compliant Issue]",
            "Conclusion" : "(Use the below template to generate Conclusion. Maintain case formatting as it is.
            


            This investigation is based on the information captured in the Complaint Description and, if applicable, the corresponding Argus Report.      "\n"
            The Complaint Issue,  ['Compliant Issue'], was reported.  (If needed, further explanation/rationale to clarify why/how the Complaint Issue was selected may be entered in this paragraph.)  "\n"
            The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis INX# VERSION NUMBER."\n"
            All complaint investigations are trended.  There is not (select one: is/is not) a current trend alert documented.),
            "Accuracy" : "(Confidence Score which is essential(In % describing closeness.))"
            )
         }},
      ]
   
      Instructions:
      1. Identify and extract the top 3 complaint issues from Complaint Description, Argus Narrative, and Additional Information and always display 3 Complaint Issue which are closely related to provided inputs.
      2. Identify and extract the CAPA Reference from Complaint Description, Argus Narrative, and Additional Information and it should not hallicunate.
         2.1 CAPA Reference for U2 device for ['Complaint Issue']:- [Leaking After Administration,Leaking During Loading,Leaking During Prep/Use] is 5237707 else it should be always NA.
         2.2 Abrysvo Device doesn't have CAPA Reference so always NA.
      3. If no CAPA Reference is reported from given Compliant Description, Argus Narrative, and Additional Information print NA
      4. Identify ['Hazard Id + Hazard Situation'] from Complaint Description,Argus Narrative, and Additional Information. 
      5. Extract the ['IMDRF Code'] associated with ['Complaint Issue'].
      6. Recheck and validate response generated and then show the outputs, which should be 100% accurate.
      7. Do not alter uppercase or lowercase letters from the source, maintain the structure provided.
      8. Ensure always to return Confidence score in % for top 3 ['Complaint Issue'] along with ['Complaint Issue'] which is must.
      9. In conclusion take all the information relatively what is specified and ensure to have new line where specified.
      10. ["Hazard Id + Hazard Situation"] is necessary and should not be blank. Always Give relevant "Hazard Id + Hazard Situation" matching to ['Complaint Issue'] and inputs provided.
      11. Accuracy should not be same for all the 3 ['Compalint Issue'].
   """
   return Final_prompt
# 4. Identify and extract the ['Hazard Id + Hazard Situation'] mapped with the ['Complaint Issue'] from Complaint Description, Argus Narrative, and Additional Information.


# complaint_issue=f"""
   
#    The following structure outlines how to derive the complaint issue from the provided details.
#    #Use the format 'Complaint Issue + Instructions for Use' to identify the correct ['Complaint Issue']. The + symbol separates the [Complaint Issue] from the [Instructions for Use]. Use the [Instructions for Use] to accurately determine the corresponding [Complaint Issue].

#    Please ensure you select the accurate Complaint Issues as listed below and avoid any misinterpretation. Do not attempt to make any assumption out of the list provided.
   
#    The complaint issue can be extracted 

#    The below tabular structure contains detials for ['IMDRF Code'] and ['CAPA Reference'] for associated ['Complaint Issue'] and ensure the text remains exactly as provided including all formatting, Capitalization and puntuations. Do not alter uppercase or lowercase letter
#    {u2_complaint_issue if (device_name =='u2' or device_name =='U2') else abrsyvo_complaint_issue}

#    To have a better reference for ['IMDRF Code'] and ['CAPA Reference'] please understand ['Complaint Issue'] well. Ensure the text remains exactly as provided including all formatting, Capitalization and puntuations. Do not alter uppercase or lowercase letter
#    {u2_complaint_issue_with_capa_imdrf if (device_name =='u2' or device_name =='U2') else abrsyvo_complaint_issue_with_capa_imdrf}

#    To map correctly the hazard mapping of {device_name} use the below information.
#    {'Extract the correct [Hazard] details by properly understanding the given information and mapping them to the [Complaint Issue] column.' if (device_name =='u2' or device_name =='U2') else "Retrieve [Hazard Id], [Hazard Name], and [Hazard Situation] by thoroughly understanding the details of [Hazard Situation]."}
#    {u2_complaint_issue_with_hazards if (device_name =='u2' or device_name =='U2') else abrysvo_hazards}


   # Use below Json structure as output structure for each Complaint Issue seperately.
   # ```json
   # [
   #    {{
   #       "Complaint Issue": "(Top 3 complaint issues which should be from list of 'Complaint Issue' provided and use everything before + symbol as ['Complaint Issue'], (also always add confidence score in % describing closeness.))",
   #       "IMDRF Code" : "(Get correct IMDRF Code associated with the ['Complaint Issue'])",
   #       "CAPA Reference" : "(Get correct CAPA Refernce associated with the ['Complaint Issue'])",
   #       "Hazard iD" : "(Get me correct Hazard ID from the narrative or parent additional information.)",
   #       "Conclusion" : "( Use the below template to generate Conclusion. Maintain case formatting as it is.

   #       This investigation is based on the information captured in the Complaint Description and, if applicable, the corresponding Argus Report.
   #       The Complaint Issue, VARIABLE COMPLAINT ISSUE, was reported.  (If needed, further explanation/rationale to clarify why/how the Complaint Issue was selected may be entered in this paragraph.)
   #       The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis INX# VARIABLE HAZARD DOCUMENT IDENTIFIER, Version # VARIABLE HAZARD DOCUMENT VERSION NUMBER.
   #       All complaint investigations are trended.  There is not (select one: is/is not) a current trend alert documented.)

   #    }},
   # ]   
#    """





# Instructions:
#       1. Identify the top 3 most relevant complaint issues based on the provided data, by understanding  Narrative and parent additional information and complaint description. Ensure do not hallucinate.
#       2. Do not alter uppercase or lowercase letters from the source.
#       3. if the response contains 'like there’s no data available for this request right now. let me know if there’s anything else i can help you' retry again against the ['Complaint Issue'] from the below context 
#       {u2_complaint_issue if (device_name =='u2' or device_name =='U2') else abrsyvo_complaint_issue}
#       to provide accurate answer instead of giving the above statement.