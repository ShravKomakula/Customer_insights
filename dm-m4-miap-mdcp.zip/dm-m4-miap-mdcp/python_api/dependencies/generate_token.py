import requests
from .config import *


def federate_auth() -> str:
    """
    Obtains auth access token for accessing GPT endpoints.

    Sends a POST request to the PingFederate authentication endpoint to retrieve an access token.

    This function constructs a `client_id` and `client_secret` payload, sends the data to the specified 
    PingFederate URL using the `application/x-www-form-urlencoded` content type, and extracts the access 
    token from the JSON response. It handles various types of HTTP errors, including connection errors, 
    timeouts, and other request issues.

    Returns:
    str: The access token retrieved from the PingFederate service.

    Raises:
    requests.exceptions.HTTPError: If the HTTP response indicates an error (e.g., 4xx or 5xx status code).
    requests.exceptions.ConnectionError: If there is a network-related error.
    requests.exceptions.Timeout: If the request times out.
    requests.exceptions.RequestException: For other general request-related errors.

    Example:
    >>> token = federate_auth()
    >>> print(token)
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
    
    """
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        # print(response.__dict__)
        token = response.json()["access_token"]
        print("This is token :- ",token)
        return token
    except requests.exceptions.HTTPError as e:
        print("HTTP Error:", e.response.status_code, e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error:", e.response.status_code, e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error:", e.response.status_code, e)
    except requests.exceptions.RequestException as e:
        print("Other Error:", e.response.status_code, e)