import pandas as pd
import os
# Get the absolute path of the current script
script_path = os.path.abspath(__file__)

# Get the directory of the script
script_dir = os.path.dirname(script_path)

# **********************************************************************************************
#                                             Abrysvo Complaint Listing
# **********************************************************************************************


text="""
**********************************************************************************************
                                             Abrysvo Complaint Listing
**********************************************************************************************
"""
df = pd.read_excel(f"{script_dir}/Complaint Issue Listing - Abrysvo.xlsx",sheet_name="Single Complaint Issue Listing")
text+="""
below is the data for complaint issues table that contains IMDRF Code,CAPA Reference and data should be linked properly, please understant it well for abrysvo..\n
"""

for index, row in df.iterrows():
    text+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} | 'Instructions for Use': {row['Instructions for Use']} \n"

abrsyvo_complaint_issue = ""

for index, row in df.iterrows():
    abrsyvo_complaint_issue+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} | 'CAPA Reference' :  {row['CAPA Reference']} | 'Instructions for Use': {row['Instructions for Use']} \n"

# **********************************************************************************************
#                                             U2 Complaint Listing
# **********************************************************************************************
text+="""
**********************************************************************************************
                                             U2 Complaint Listing
**********************************************************************************************
"""
df = pd.read_excel(f"{script_dir}/Complaint Issue Listing - U2.xlsx",sheet_name="Single Complaint Issue Listing")
text+="""\n\n
below is the data for complaint issues table that contains IMDRF Code,CAPA Reference and data should be linked properly, please understant it well for U2..\n
"""


for index, row in df.iterrows():
    text+= f"'table name': U2 Complaint listing | 'Device': U2 | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} | 'CAPA Reference' :  {row['CAPA Reference']} | 'Instructions for Use': {row['Instructions for Use']} \n"


u2_complaint_issue = ""
for index, row in df.iterrows():
    u2_complaint_issue+= f"'table name': U2 Complaint listing | 'Device': U2 | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} | 'CAPA Reference' :  {row['CAPA Reference']} | 'Instructions for Use': {row['Instructions for Use']} \n"


# **********************************************************************************************
#                                             U2 Complaint Listing to get hazard id 
# **********************************************************************************************

text+="""
**********************************************************************************************
                                             U2 Complaint Listing to get hazard id 
**********************************************************************************************
"""

df = pd.read_excel(f"{script_dir}/Complaint Issue Listing - U2 New.xlsx",sheet_name="U2 Mapping")
text+="""\n\n
From the user query given for U2 device try to map Hazard id mentioned , please use appropriate to the complaint description mentioned.\n
"""
# print("New columns :-")
# print(df.columns)
df.rename(columns={'Related HA Line Items\nINX100281795 V9.0':'HA_item'},inplace=True)
for index, row in df.iterrows():
    text+= f"'table name': U2 Complaint listing for Hazard mapping U2 | 'Device': U2 | 'Complaint Issue': {row['New Complaint Issue']} |'General Guidance':{row['General Guidance']} | 'Old CITI Failure Mode' : {row['Old CITI Failure Mode']}| 'Related HA Line Items INX100281795 V9.0' : {row['HA_item']}"

print("##############################################################################",text)


text+="""
**********************************************************************************************
                                             HAZARD MAPPING Abrysvo
**********************************************************************************************
"""


df = pd.read_excel(f"{script_dir}/Hazard mapping and information.xlsx",sheet_name="Abrysvo Kit")
text+="""\n\n
Based on Complaint Issue, Complaint Description, Argus Narrative and parent_additional_information, Try to match out ['Hazardous Situation']and get me the exact hazard mapping information for Abrysvo device (can be multiple) and please go through precisely
"""
# print("New columns :-")
# print(df.columns)
# for index, row in df.iterrows():
#     text+= f"'table name': Hazard mapping and information Abryso | 'Device': Abrysvo | 'Hazard ID + Hazard': {row['Hazard ID + Hazard']} | 'Hazardous Situation' : {row['Hazardous Situation']}"

abrysvo_hazard_mappings = "Based on Complaint Issue, Complaint Description, Argus Narrative and parent_additional_information, Try to match out ['Hazardous Situation']and get me the exact hazard mapping information for Abrysvo device (can be multiple) and please go through precisely\n"

for index, row in df.iterrows():
    abrysvo_hazard_mappings+= f"'table name': Hazard mapping and information Abryso | 'Device': 'Abrysvo' | 'Hazard ID + Hazard': {row['Hazard ID + Hazard']} | 'Hazardous Situation' : {row['Hazardous Situation']}"


text+="""
**********************************************************************************************
                                             HAZARD MAPPING U2
**********************************************************************************************
"""


df = pd.read_excel(f"{script_dir}/Hazard mapping and information.xlsx",sheet_name="Genotropin U2 Pen")
text+="""\n\n
Based on Complaint Issue, Complaint Description, Argus Narrative and parent_additional_information, Try to match out ['Hazardous Situation']and get me the exact hazard mapping information for U2 device (can be multiple) and please go through precisely
"""
# print("New columns :-")
# print(df.columns)
# for index, row in df.iterrows():
#     text+= f"'table name': Hazard mapping and information U2 | 'Device': U2 | 'Hazard ID + Hazard': {row['Hazard ID + Hazard']} | 'Hazardous Situation' : {row['Hazardous Situation']}"

u2_hazard_mappings = "Based on Complaint Issue, Complaint Description, Argus Narrative and parent_additional_information, Try to match out ['Hazardous Situation']and get me the exact hazard mapping information for U2 device (can be multiple) and please go through precisely\n"

for index, row in df.iterrows():
    u2_hazard_mappings+= f"'table name': Hazard mapping and information U2 | 'Device': U2 | 'Hazard ID + Hazard': {row['Hazard ID + Hazard']} | 'Hazardous Situation' : {row['Hazardous Situation']}"



text+="""
*********************************************************************************************************************
                                             HAZARD MAPPING U2 with additional Hazard Information
*********************************************************************************************************************
"""


df = pd.read_excel(f"{script_dir}/Complaint Issue Listing - U2 New.xlsx",sheet_name="U2 HA Line Items")
text+="""\n\n
From the user input for U2 try to fetch appropriate Hazard ids anc information as mentioned , please go deeply to get accurate Hazard information.\n
"""
# print("New columns :-")
# print(df.columns)
# for index, row in df.iterrows():
#     text+= f"'table name': U2 Complaint listing for Hazard mapping U2 | 'Device': U2 | 'Hazard ID(s), Hazard - Hazardous Situation':row{'Hazard ID(s), Hazard - Hazardous Situation'}"




# # **********************************************************************************************
# df1 = pd.read_csv(f"{script_dir}/dei_cleaned.csv")
# text+="""
# -------------------------------------------------------------------------------------------------
# below is the data for dei table please understant it well..\n
# """
# for index, row in df1.iterrows():
#     text+= f"Hazard ID: {row['Hazard ID']} | Hazardous Situation: {row['Hazardous Situation']}\n"


# # ***********************************************************************************************
# df2 = pd.read_csv(f"{script_dir}/Hazard_cleaned.csv")
# text+="""
# -------------------------------------------------------------------------------------------------
# please understand hazard situtations as listed below.
# """
# for index, row in df2.drop(columns=['Unnamed: 0']).iterrows():
#     text+= f"Hazard ID: {row['Hazard ID']} | Hazard: {row['Hazard']} |  Hazardous Situation: {row['Hazardous Situation']} \n"

final_text = text
# print(text)
# print(final_text)


