import os
import pandas as pd
# Get the absolute path of the current script
script_path = os.path.abspath(__file__)

# Get the directory of the script
script_dir = os.path.dirname(script_path)

# **********************************************************************************************
#                                             Abrysvo Complaint Listing
# **********************************************************************************************


# df = pd.read_excel(f"{script_dir}\\Complaint Issue Listing - Abrysvo.xlsx",sheet_name="Single Complaint Issue Listing")
# abrsyvo_complaint_issue = ""
# abrsyvo_complaint_issue_with_capa_imdrf=""
# for index, row in df.iterrows():
#     abrsyvo_complaint_issue+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo |'Complaint Issue + Instructions for Use': {row['Complaint Issue']} + {row['Instructions for Use']} | 'IMDRF Code':{row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
#     # abrsyvo_complaint_issue_with_capa_imdrf+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo |'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code':{row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
#     abrsyvo_complaint_issue_with_capa_imdrf+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo |'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code':{row['IMDRF Code']} \n"

script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, "Complaint Issue Listing - Abrysvo.xlsx")

df = pd.read_excel(file_path, sheet_name="Single Complaint Issue Listing")
abrsyvo_complaint_issue = ""
abrsyvo_complaint_issue_with_capa_imdrf = ""

for index, row in df.iterrows():
    abrsyvo_complaint_issue += f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo | 'Complaint Issue + Instructions for Use': {row['Complaint Issue']} + {row['Instructions for Use']} | 'IMDRF Code': {row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
    abrsyvo_complaint_issue_with_capa_imdrf += f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} \n"

# **********************************************************************************************
#                                             U2 Complaint Listing
# **********************************************************************************************

# df = pd.read_excel(f"{script_dir}\\Complaint Issue Listing - U2.xlsx",sheet_name="Single Complaint Issue Listing")
# u2_complaint_issue = ""
# u2_complaint_issue_with_capa_imdrf=""
# for index, row in df.iterrows():
#     u2_complaint_issue+= f"'table name': U2 Complaint listing | 'Device': U2 | 'Complaint Issue + Instructions for Use': {row['Complaint Issue']} + {row['Instructions for Use']} | 'IMDRF Code':{row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
#     # u2_complaint_issue_with_capa_imdrf+= f"'table name': Abrysvo Complaint listing | 'Device': Abrysvo |'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code':{row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
#     u2_complaint_issue_with_capa_imdrf+= f"'table name': U2 Complaint listing | 'Device': Abrysvo |'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code':{row['IMDRF Code']} \n"


# Get the script directory
script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, "Complaint Issue Listing - U2.xlsx")

# Read the Excel file
df = pd.read_excel(file_path, sheet_name="Single Complaint Issue Listing")

# Initialize strings to store the output
u2_complaint_issue = ""
u2_complaint_issue_with_capa_imdrf = ""

# Iterate through the rows in the DataFrame
for index, row in df.iterrows():
    # Update the complaint issue string
    u2_complaint_issue += f"'table name': U2 Complaint listing | 'Device': U2 | 'Complaint Issue + Instructions for Use': {row['Complaint Issue']} + {row['Instructions for Use']} | 'IMDRF Code': {row['IMDRF Code']} | 'CAPA Reference' : {row['CAPA Reference']} \n"
    
    # Update the complaint issue string with IMDRF and CAPA reference
    u2_complaint_issue_with_capa_imdrf += f"'table name': U2 Complaint listing | 'Device': U2 | 'Complaint Issue': {row['Complaint Issue']} | 'IMDRF Code': {row['IMDRF Code']} \n"

# **********************************************************************************************
#                                  U2 hazard ids with mapping of complaint issues
# **********************************************************************************************

# df = pd.read_excel(f"U2_mapping with complaint issues.xlsx",sheet_name="U2 Mapping cleaned")
# u2_complaint_issue_with_hazards = ""
# for i, row in df.iterrows():
#     u2_complaint_issue_with_hazards+= f"'table name': U2 Complaint listing for hazard | 'Complaint Issue': {row['Complaint Issue']} | 'Hazards' : {row['Related HA Line Items\nINX100281795 V9.0']} \n"


# # **********************************************************************************************
# #                                       Abrysvo hazard ids
# # **********************************************************************************************

# df = pd.read_excel(f"{script_dir}\\Hazards all.xlsx",sheet_name = "Abrysvo Kit")
# print(df.columns)
# # print(df['Hazard ID + Hazard'].str.split(",").to_list())
# # df[['Hazard ID','Hazard Name']] = df['Hazard ID + Hazard'].str.split(",").to_list()
# # print(df)
# df= df[['Hazard ID','Hazardous Situation']]
# abrysvo_hazards = ""
# for i, row in df.iterrows():
#     abrysvo_hazards+= f"'table name': Abrysvo Hazards | 'Hazard ID': {row['Hazard ID']} ,'Hazard Situation' : [{row['Hazardous Situation']}] \n"
# Get the script directory
script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, "Hazards all.xlsx")

# Read the Excel file
df = pd.read_excel(file_path, sheet_name="Abrysvo Kit")

# Print the column names to verify them
print(df.columns)

# Select the necessary columns
df = df[['Hazard ID', 'Hazardous Situation']]

# Initialize a string to store hazard information
abrysvo_hazards = ""

# Iterate through the rows of the DataFrame
for i, row in df.iterrows():
    abrysvo_hazards += f"'table name': Abrysvo Hazards | 'Hazard ID': {row['Hazard ID']} , 'Hazard Situation' : [{row['Hazardous Situation']}] \n"

# Optionally print or return the result
print(abrysvo_hazards)
# # **********************************************************************************************
# #                                       U2 hazard ids
# # **********************************************************************************************

# df = pd.read_excel(f"{script_dir}\\Hazards all.xlsx",sheet_name = "Genotropin U2 Pen")
# # print(df['Hazard ID + Hazard'].str.split(",").to_list())
# # df[['Hazard ID','Hazard Name']] = df['Hazard ID + Hazard'].str.split(",").to_list()
# # df= df[['Hazard ID + Hazard','Hazardous Situation']]
# df= df[['Hazard ID','Hazardous Situation']]
# U2_hazards = ""
# for i, row in df.iterrows():
#     U2_hazards+= f"'table name': U2 Hazards | 'Hazard ID + Hazard': {row['Hazard ID']} ,'Hazard Situation' : [{row['Hazardous Situation']}] \n"

# Get the script directory
script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, "Hazards all.xlsx")

# Read the Excel file
df = pd.read_excel(file_path, sheet_name="Genotropin U2 Pen")

# Select the necessary columns
df = df[['Hazard ID', 'Hazardous Situation']]

# Initialize a string to store hazard information
U2_hazards = ""

# Iterate through the rows of the DataFrame
for i, row in df.iterrows():
    U2_hazards += f"'table name': U2 Hazards | 'Hazard ID + Hazard': {row['Hazard ID']} , 'Hazard Situation' : [{row['Hazardous Situation']}] \n"

# Optionally print or return the result
print(U2_hazards)