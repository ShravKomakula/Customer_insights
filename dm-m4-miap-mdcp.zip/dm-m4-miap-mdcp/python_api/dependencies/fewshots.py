fewshots = """

    # ---------------------------------------------------- U2 Black Knob Fell Off----------------------------    

    Example 1:
        Inputs:
            Device : U2
            Complaint Description : Action Code: Product Complaint Exchange, Action Item Date Open: 30-OCT-24, Action Item Date Due: 31-OCT-24, Action Item Description:  Product Complaint Exchange: [Genotropin Pen 12: Mom shared that the pen is broken and itâ€™s the most difficult pen to use.] Initial (PRD 29Oct2024, SRD 29Oct2024);
            Argus Narrative       : Narrative for case number 202400290277: This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                    An 11-year-old male patient received somatropin (GENOTROPIN PEN 12), (Batch/Lot number: unknown) at 1.4 mg. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DEVICE ISSUE (non-serious), described as "the pen's black knob came off"; DEVICE USE ISSUE (non-serious), described as "the pen's black knob came off, she placed it back on the pen"; DEVICE MECHANICAL ISSUE (non-serious), described as "its very hard to turn"; DEVICE DIFFICULT TO USE (non-serious), described as "Mom shared that the pen is broken and it's the most difficult pen to use". The action taken for somatropin was unknown.
                                    Additional Information: Mom stated that the pen's black knob came off, she placed it back on the pen, but now its very hard to turn. Mom shared that the pen is broken and it's the most difficult pen to use. Mom denies dropped/wet pen. Patient has not missed doses.
                                    Product Quality Group provided investigational results on 06Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion noted that no further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Black Knob Fell Off, was reported. An additional Complaint issue of Injection Knob/Dial Issue was reported. This Complaint issue is considered a cascading event. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    The reporter considered "the pen's black knob came off", "the pen's black knob came off, she placed it back on the pen", "its very hard to turn" and "mom shared that the pen is broken and it's the most difficult pen to use" not related to somatropin. Causality for "the pen's black knob came off", "the pen's black knob came off, she placed it back on the pen", "its very hard to turn" and "mom shared that the pen is broken and it's the most difficult pen to use" was determined associated to device constituent of somatropin (malfunction).
                                    Follow-up (06Nov2024): This is a follow-up report received from product quality group providing investigation result.
                                    Follow-up (06Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.
            

        Outputs:
            Complaint Issue : [Black Knob Fell Off]

    Example 2 :
        Inputs:
            Device : U2
            Complaint Description : Action Code: Product Complaint Exchange, Action Item Date Open: 24-OCT-24, Action Item Date Due: 25-OCT-24, Action Item Description:  Product Complaint Exchange: [black knob too hard, and it fell off]. Initial ICSR acceptance (PRD 24Oct2024, SRD 24Oct2024).;
            Argus Narrative       : An 11-year-old male patient received somatropin (GENOTROPIN PEN 5), since Oct2024 (Batch/Lot number: unknown) at 1 mg. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: WRONG TECHNIQUE IN DEVICE USAGE PROCESS (non-serious) with onset 23Oct2024, described as "she turned the black knob too hard, and it fell off"; DEVICE ISSUE (non-serious) with onset 23Oct2024, described as "she turned the black knob too hard, and it fell off/ pen device button was broken". The action taken for somatropin was unknown.
                                    Additional information: Mom stated that last night (23Oct2024) when went to use the last dose in the cartridge, she turned the black knob too hard, and it fell off and she could not find it. Mom denied dropped/wet pen. Patient has not missed doses. Mom stated pen device button was broken.
                                    Product Quality Group provided investigational results on 27Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: Site Investigation (manufacturing site) noted that no further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation noted that this investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Black Knob Fell Off, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    The reporter considered "she turned the black knob too hard, and it fell off" and "she turned the black knob too hard, and it fell off/ pen device button was broken" not related to somatropin. Causality for "she turned the black knob too hard, and it fell off" and "she turned the black knob too hard, and it fell off/ pen device button was broken" was determined associated to device constituent of somatropin (malfunction).
                                    Follow-up (06Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.
                                    Follow-up (27Nov2024): This is a follow-up report received from product quality group providing investigation result

        Outputs:
            Complaint Issue : [Black Knob Fell Off]


    Example 3 :
        Inputs :
            Device : U2
            Complaint Description  : Caller said her son's genotropin pen's end where it is being dialed, the spring pop out and it broke. Caller is asking for a new pen.
            Argus Narrative        : Narrative for case number 202400286781: The initial case was missing the following minimum criteria: No adverse effect. Upon receipt of follow-up information on 24Oct2024, this case now contains all required information to be considered valid.
                                     This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                     A 13-year-old male patient received somatropin (GENOTROPIN PEN 12), first regimen (Batch/Lot number: unknown) at 1.2 mg alternate day (1.2mg alt with 1.4mg injection daily), second regimen (Batch/Lot number: unknown) at 1.4 mg alternate day (1.2mg alt with 1.4mg injection daily) and third regimen (Batch/Lot number: unknown) at 0.6 mg daily, Device Lot Number: L173. The patient's relevant medical history and concomitant medications were not reported. The following information was reported: DRUG DOSE OMISSION BY DEVICE (non-serious), described as "Patient will miss doses until replacement is received."; DEVICE BREAKAGE (non-serious), described as "the spring popped out of Genotropin Pen 12 and plunger broke/Black knob/spring came off pen/Broken knob". The action taken for somatropin was unknown.
                                     Causality for "patient will miss doses until replacement is received." and "the spring popped out of genotropin pen 12 and plunger broke/black knob/spring came off pen/broken knob" was determined associated to device constituent of somatropin (malfunction).
                                     Additional information: Mom reported the spring popped out of Genotropin Pen 12 and plunger broke. On 24Oct2024, the same consumer reported black knob/spring came off pen. Patient would miss doses until replacement was received. On 24Oct2024, the mom reported that her son's genotropin pen's end where it is being dialed, the spring pop out and it broke. Caller is asking for a new pen.
                                     The lot number for the somatropin was not provided and will be requested during follow up.
                                     Follow-up (24Oct2024): This is a spontaneous follow-up report received from product quality group. Updated information included: device information and clinical course information.
                                     Follow-up (29Nov2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.


        Outputs:
            Complaint Issue : [Black Knob Fell Off]

    
    # ---------------------------------------------------- U2 Injection Knob/Dial Issue----------------------------    

    Example 4 :
        Inputs : 
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 18-OCT-24, Action Item Date Due: 19-OCT-24, Action Item Description:  Product Complaint Exchange: [Genotropin Pen 12, During virtual injection training with mother and patient, mother reports that demonstration cartridge smells funny] Initial (PRD 17Oct2024/SRD 17Oct2024) (Li, Xinxiang);
            Argus Narrative        : Narrative for case number 202400280131: The initial case was missing the following minimum criteria: no adverse event. Upon receipt of follow-up information on 30Oct2024 this case now contains all required information to be considered valid.

                                    This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                    
                                    A 15-year-old male patient received somatropin (GENOTROPIN PEN 12), first regimen (Lot number: LD4003), second regimen (Batch/Lot number: unknown) at 1.4 mg daily and third regimen since Oct2024 (Batch/Lot number: unknown) at 2 mg daily. The patient's relevant medical history and concomitant medications were not reported. Past drug history included: Norditropin.
                                    The following information was reported: POOR QUALITY DEVICE USED (non-serious), DEVICE OCCLUSION (non-serious), DEVICE ISSUE (non-serious) all with onset Oct2024 and all described as "Mom administered patient's dose, and didn't hear the click; however, the amount changed in the cartridge. She then attempted injection again, but this time the amount in the cartridge did change"; DEVICE DEFECTIVE (non-serious) with onset Oct2024, described as "pen being defective"; DRUG DOSE OMISSION BY DEVICE (non-serious) with onset 29Oct2024, described as "pen jammed last night, and dose was missed"; DEVICE MECHANICAL ISSUE (non-serious) with onset 29Oct2024, described as "pen jammed last night, and dose was missed/ defective and having to attempt injection twice". The action taken for somatropin was unknown.
                                    
                                    Causality for "pen jammed last night, and dose was missed", "pen jammed last night, and dose was missed/ defective and having to attempt injection twice", "mom administered patient's dose, and didn't hear the click; however, the amount changed in the cartridge. she then attempted injection again, but this time the amount in the cartridge did change" and "pen being defective" was determined associated to device constituent of somatropin (malfunction).
                                    
                                    Additional information: It was initially reported that during virtual injection training with mother and patient, mother reported that demonstration cartridge smells funny. The mother also reported that she administered patient's dose, and didn't hear the click; however, the amount changed in the cartridge. She then attempted injection again, but this time the amount in the cartridge did change. Cartridge amount only changed by 2mg, so patient did not get double dosed. She also stated when she tried injecting medication last night, plunger did not go down, device would not fit in box; tried again this morning plunger did go down but unable to tell if the medication did dispense; did not hear the click. Mom reported pen jammed last night, and dose was missed. Mom stuck patient twice, and was not able to get dose administered. Mom reports she's had several issues with the pen. Replacement requested. Mom stated pen has jammed twice and she wasn't able to administer injection. Mom reported about pen being defective and having to attempt injection twice. Mom reported Norditropin was easier, but Pfizer Bridge has much better customer service.
                                    
                                    Product Quality Group provided investigational results on 19Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: Site Investigation (site): No further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Injection Knob/Dial Issue, was reported. The issue of "mother reported that demonstration cartridge smells funny" is not device related, and it is out of scope for device engineering investigations. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    
                                    Causality for "pen jammed last night, and dose was missed" was determined associated to device constituent of somatropin (malfunction).
                                    
                                    Follow-up (30Oct2024 and 01Nov2024): This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                    
                                    Updated information included: past drug, event information (details of event device mechanical issue updated and added new events poor quality device used, device blockage, noise from device and device defective), and clinical course.
                                    
                                    Follow-up (19Nov2024): This is a follow-up spontaneous report received from product quality group providing investigational results.
                                    Follow-up (12Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.
                                    
        Outputs:
            Complaint Issue : [Injection Knob/Dial Issue]

            
    Example 5 :
        Inputs : 
            Complaint Description  : patient is unable to turn the dial on the pen to inject the fluid and is unable to use it as it has broken off the end aswell.If doses missed, how many- 1.Sample Availability -YesExpress consent given?- No
            Argus Narrative        : Narrative for case number PV202400139534: This is a spontaneous report received from a consumer from product quality group, Program ID: 112151. A 64-year-old female patient received somatropin (GENOTROPIN PEN) solution for injection, (Batch/Lot number: unknown) daily (UNK, daily), subcutaneous for growth hormone. The patient's relevant medical history and concomitant medications were not reported. The following information was reported: DRUG DOSE OMISSION BY DEVICE (non-serious), described as "1 dose missed"; DEVICE MECHANICAL ISSUE (non-serious), described as "patient is unable to turn the dial on the pen to inject the fluid"; and DEVICE BREAKAGE (non-serious), described as "unable to use it as it has broken off the end as well". The action taken for somatropin was unknown.
                                    Causality for "1 dose missed", "patient is unable to turn the dial on the pen to inject the fluid" and "unable to use it as it has broken off the end as well" was determined associated to device constituent of somatropin (malfunction).
                                    Additional information: The patient is unable to turn the dial on the pen to inject the fluid and is unable to use it as it has broken off the end as well.
                                    Product Quality Group provided investigational results on 13Nov2024 for somatropin (device constituent): No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. This investigation is based on the information captured in the Complaint Description and Argus Report. Two distinct Complaint Issues of "Injection Knob/Dial Issue" and "Component Damaged During Prep/Use" were reported. However, these two distinct Complaint issues map to the same Hazard/Hazardous Situation. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    Follow-up (01Nov2024): This is a spontaneous follow-up report received from Product Quality Group.
                                    Updated information included: device information.
                                    Follow-up (13Nov2024): This is a spontaneous follow-up report received from Product Quality Group providing investigation results.

        Outputs:
            Complaint Issue : [Injection Knob/Dial Issue]


    Example 6 :
        Inputs : 
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 28-OCT-24, Action Item Date Due: 29-OCT-24, Action Item Description:  Product Complaint Exchange: [getting really hard to dial up stated the previous pen they had did the same thing];
            Argus Narrative        : Narrative for case number 202400288799: The initial case was missing the following minimum criteria: No adverse event. Upon receipt of follow-up information on 29Oct2024, this case now contains all required information to be considered VALID.
                                    This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                    An 8-year-old male patient received somatropin (GENOTROPIN PEN 5), first regimen (Batch/Lot number: unknown) at 0.9 mg and second regimen (Batch/Lot number: unknown) at 1.1 mg. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DEVICE PHYSICAL PROPERTY ISSUE (non-serious), DEVICE MECHANICAL ISSUE (non-serious), PATIENT-DEVICE INCOMPATIBILITY (non-serious) and all described as "getting really hard to dial up stated the previous pen they had did the same thing/It is very hard to turn the knob to dial the dose; there is resistance and it feels like it's going to break"; DRUG DOSE OMISSION BY DEVICE (non-serious), described as "Patient may potentially miss doses while waiting for a new pen". The action taken for somatropin was unknown.
                                    Additional information: An inbound call (IBC) was received from the patient's mother, who stated that it was getting really hard to dial up and stated that the previous pen they had did the same thing. The patient's mom further reported that it was very hard to turn the knob to dial the dose; there was resistance and it felt like it's going to break. The patient might potentially miss doses while waiting for a new pen. Sample availability was unknown.
                                    Causality for "getting really hard to dial up stated the previous pen they had did the same thing/it is very hard to turn the knob to dial the dose; there is resistance and it feels like it's going to break" and "patient may potentially miss doses while waiting for a new pen" was determined associated to device constituent of somatropin (malfunction).
                                    Product Quality Group provided investigational results on 14Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: Updated (by name withheld) on 14Nov2024: No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. This investigation is based on the information captured in the Complaint Description. The Complaint Issue, Injection Knob/Dial Issue, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented. Investigation Summary Complete Date (GMT): 14Nov2024.
                                    Follow-up (14Nov2024): This is a spontaneous follow-up report from product quality group providing investigation results.
                                    Follow-up (09Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.


        Outputs:
            Complaint Issue : [Injection Knob/Dial Issue]

    # ---------------------------------------------------- U2 Display Not Functioning ----------------------------    

    Example 7 :
        Inputs : INV-315300
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 29-OCT-24, Action Item Date Due: 29-OCT-24, Action Item Description:  Product Complaint Exchange: [ " patient states pen device is dead and will not inject" for Genotropin Pen 12] Initial  PRD 28Oct2024 / SRD 29Oct2024;
            Argus Narrative        : Narrative for case number 202400289940: This case has been considered invalid since only a product complaint without associated adverse events was reported (Other-Info not qualifying for AE reporting-Product complaint).

                                    Patient characteristics:
                                    Sex: Female
                                    
                                    Reaction(s)/Event(s):
                                    Reaction/event as reported by primary source: Pen device issues
                                    Outcome of reaction/event at the time of last observation: Unknown
                                    
                                    Drug(s) Information:
                                    Characterization of drug role: Suspect
                                    Proprietary medicinal product name: Genotropin Pen 12, 12 mg cartridge
                                    Batch/lot number: Unknown
                                    
                                    Narrative case summary and further information:
                                    Case narrative:
                                    
                                    Submitted by (name withheld) Ref: #
                                    Selected Report Type: Initial
                                    Reporter type: Consumer or other non health professional
                                    Specify Consumer or other non health professional: Patient/Consumer (Non-HCP)
                                    Reporter telephone: #
                                    Primary / Prescribing Healthcare Professional Info
                                    HCP name: (name withheld)
                                    HCP postal address: #
                                    HCP telephone: #
                                    Dates for Pen device issues: (From: Unknown To: Unknown)
                                    
                                    Is Genotropin Pen 12, 12 mg cartridge a Pfizer product? Unspecified
                                    Genotropin Pen 12, 12 mg cartridge manufacturer: Unspecified
                                    Dates for Genotropin Pen 12, 12 mg cartridge: (Start: Unknown Stop: Unknown)
                                    Reason for no lot number: of Genotropin Pen 12, 12 mg cartridge: Other: Lot number unavailable at time of reporting.
                                    Expiry Date of Genotropin Pen 12, 12 mg cartridge: Not Supplied
                                    
                                    Additional Context:
                                    Is this report for a CSP?: Yes
                                    CSP Number: 147579
                                    CSP Name: Pfizer bridge
                                    Submitter occupation: non-HCP
                                    Delay in reporting: No
                                    Reporter is prescribing HCP?: No
                                    Patient Name: (name withheld)
                                    Patient date of birth or age is known?: Date of birth
                                    Patient's Gender: Gender Known
                                    Provide additional information about the patient?: No
                                    (Genotropin Pen 12, 12 mg cartridge) Action taken: Unknown
                                    
                                    (Pen device issues) Event Description: patient states pen device is dead and will not inject. Lot number unavailable at time of reporting.
                                    (Pen device issues) Was the adverse event serious?: Not Known

        Outputs:
            Complaint Issue : [Display Not Functioning]

            
    Example 8 :
        Inputs : INV-315565
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 30-OCT-24, Action Item Date Due: 31-OCT-24, Action Item Description:  Product Complaint Exchange: [advised the window has went out on the device however they are able to count the clicks. Pen was sent out in 2022.] Initial ICSR (PRD [29Oct2024], SRD [29Oct2024]) (Li, Yizhuo).;
            Argus Narrative        : Narrative for case number 202400290169: This case has been considered invalid as Info not qualifying for AE reporting - Product complaint and device use error only.

                                    Submitted by bridge_lash_pa Ref: 58754679
                                    Selected Report Type: Initial
                                    Reporter consent to contact given: Yes
                                    Reporter type: Consumer or other non health professional
                                    Specify Consumer or other non health professional: Caregiver/Parent (Non-HCP)
                                    Reporter telephone: (949) 412-4658
                                    
                                    Primary / Prescribing Healthcare Professional Info
                                    HCP name: TIMOTHY FLANNERY
                                    HCP consent to contact: Yes
                                    HCP postal address: 1201 W LA VETA AVE, ORANGE, CA, 92868, United States (the)
                                    HCP telephone: 714-509-8634
                                    
                                    Dates for Pen died: (From: Unknown To: Unknown)
                                    Reporter seriousness for Pen died: Unspecified
                                    
                                    Is Genotropin Pen 12, 12 mg cartridge a Pfizer product? Unspecified
                                    Genotropin Pen 12, 12 mg cartridge manufacturer: Unspecified
                                    Dates for Genotropin Pen 12, 12 mg cartridge: (Start: Unknown Stop: Unknown)
                                    Reason for no lot number: of Genotropin Pen 12, 12 mg cartridge: Other: Lot Number unavailable at time of reporting
                                    Expiry Date of Genotropin Pen 12, 12 mg cartridge: Not Supplied
                                    
                                    
                                    
                                    
                                    Additional Context:
                                    Is this report for a CSP?: Yes
                                    CSP Number: 147579
                                    CSP Name: Pfizer Bridge
                                    Submitter occupation: NON HCP
                                    Delay in reporting: No
                                    Reporter is prescribing HCP?: No
                                    Patient Name: Miles Shevel
                                    Patient date of birth or age is known?: Date of birth
                                    Patient's Gender: Gender Known
                                    Provide additional information about the patient?: No
                                    (Genotropin Pen 12, 12 mg cartridge) Action taken: Unknown
                                    (Pen died) Event Description: Call from patients dad Steve Shevel who advised the window has went out on the device however they are able to count the clicks. Pen was sent out in 2022.
                                    (Pen died) Was the adverse event serious?: Not Known
                                    Follow-up (30Nov2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.

        Outputs:
            Complaint Issue : [Display Not Functioning]


    Example 9 :
        Inputs : INV-315825
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 04-NOV-24, Action Item Date Due: 05-NOV-24, Action Item Description:  Product Complaint Exchange: [Mom reported dead battery and has been counting clicks. ICSR acceptance (PRD 04Nov2024/ SRD 04Nov2024)];
            Argus Narrative        : Narrative for case number 202400293793: This case has been considered invalid since product complaint only.

                                    Selected Report Type: Initial
                                    Reporter consent to contact given: Yes
                                    Reporter type: Consumer or other non health professional
                                    Specify Consumer or other non health professional: Caregiver/Parent (Non-HCP)
                                    
                                    Primary / Prescribing Healthcare Professional Info
                                    
                                    Dates for Product quality Complaint.: (From: Unknown To: Unknown)
                                    Reporter seriousness for Product quality Complaint.: Unspecified
                                    
                                    Is Genotropin pen 12/Genotropin 12mg cartridge a Pfizer product? Unspecified
                                    Genotropin pen 12/Genotropin 12mg cartridge manufacturer: Unspecified
                                    Dates for Genotropin pen 12/Genotropin 12mg cartridge: (Start: Unknown Stop: Unknown)
                                    Reason for no lot number: of Genotropin pen 12/Genotropin 12mg cartridge: Other: Lot Number unavailable at time of reporting.
                                    Expiry Date of Genotropin pen 12/Genotropin 12mg cartridge: Not Supplied
                                    
                                    Additional Context:
                                    Is this report for a CSP?: Yes
                                    CSP Number: 147579
                                    CSP Name: Pfizer Bridge
                                    Submitter occupation: Nurse
                                    Delay in reporting: No
                                    Reporter is prescribing HCP?: No
                                    Provide additional information about the patient?: No
                                    (Genotropin pen 12/Genotropin 12mg cartridge) Action taken: Unknown
                                    (Product quality Complaint.) Event Description: Mom reported dead battery and has been counting clicks.
                                    (Product quality Complaint.) Was the adverse event serious?: Not Known


        Outputs:
            Complaint Issue : [Display Not Functioning]

    # ---------------------------------------------------- U2 Leaking During Prep/Use ----------------------------    

    Example 10 :    
        Inputs : INV-314245
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 24-OCT-24, Action Item Date Due: 25-OCT-24, Action Item Description:  Product Complaint Exchange: [when working with the pen her husband spilled medication. Requesting medication replacement]Follow-up item #03 with PRD 23Oct2024 /SRD 23Oct2024 (Chen, Dongxue);
            Argus Narrative        : Narrative for case number PV202400109127: This is a spontaneous report received from a Physician and a Consumer or other non HCP from product quality group, Program ID: 147579.

                                    A 6-year-old male patient received somatropin (GENOTROPIN PEN 5), (Batch/Lot number: unknown) at 0.8 mg (0.8 mg, 6 days/wk) for hypopituitarism. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: PRODUCT PRESCRIBING ERROR (non-serious), described as "Pen Needle Gauge 32 84mm (dose in increments of 0.1 mg)"; DEVICE DEFECTIVE (non-serious), described as "device was not working properly"; DEVICE LEAKAGE (non-serious), described as "when working with the pen her husband spilled medication". The action taken for somatropin was unknown.
                                    
                                    Causality for "device was not working properly" and "when working with the pen her husband spilled medication" was determined associated to device constituent of somatropin (malfunction).
                                    
                                    Product Quality Group provided investigational results on 30Oct2024 for somatropin (device constituent): This complaint for "Mother stated device was not working properly will try it again tonight (from the time of reporting on 27Sep2024) and call back if issue continues." for GENOTROPIN PEN 5. No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Lead Site investigation Summary: Site Investigation: No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Loss of Function, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis. All complaint investigations are trended. There is no current trend alert documented.
                                    Product Quality Group provided investigational results on 07Nov2024 for somatropin (device constituent): No further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Leaking During Prep/Use, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis. All complaint investigations are trended. There is not a current trend alert documented.
                                    Product Quality Group provided investigational results on 29Nov2024 for somatropin (device constituent): MDCP Investigation Summary and Conclusion: This complaint for "Mother stated device was not working properly will try it again tonight (from the time of reporting on 27Sep2024) and call back if issue continues." for GENOTROPIN PEN 5. No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Lead Site investigation Summary: Site Investigation: No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Loss of Function, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX#100281795, Version # (9.0)). All complaint investigations are trended. There is no current trend alert documented.
                                    
                                    Additional information: Diagnosis was hypopituitarism (includes isolated GHD and panhypopituitarism) (E23.0). Prescription Information: GENOTROPIN Pen 5, Growth Hormone Delivery Device, Pen Needle Gauge 32 84 mm (dose in increments of 0.1 mg). Days Supply 30, Refills 4. On 27Sep2024, mother stated device was not working properly will try it again tonight (from the time of reporting on 27Sep2024) and call back if issue continues. On 23Oct2024, patient's mom reported that when working with the pen her husband spilled medication. Requesting medication replacement. Informed mom that we will need to do troubleshooting with device and husband and provided hours of operation. Mom WAS aware of medication shortage.
                                    
                                    Follow-up (25Sep2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.
                                    
                                    Follow-up (27Sep2024): This is a spontaneous report received from a Consumer or other non HCP, Program ID: 147579. Updated information included: reaction data (new event: "device was not working properly") and clinical course details.
                                    
                                    Follow-up (23Oct2024): This is a spontaneous follow-up report received from a Consumer or other non HCP, Program ID: 147579. Updated information included: new event (device leakage) and clinical course of events.
                                    
                                    Follow-up (07Nov2024): This is a follow-up report from product quality group providing investigation results.
                                    Updated information included: event coding updated from Device malfunction to Device defective, and investigation results added.
                                    
                                    Amendment: This follow-up report is being submitted to amend previous information: to report FU (30Oct2024).
                                    
                                    Follow-up (30Oct2024): This is a follow-up report from product quality group providing investigation results.
                                    
                                    Follow-up (29Nov2024): This is a follow-up report from product quality group providing investigation results.

        Outputs:
            Complaint Issue : [Leaking During Prep/Use]

            
    Example 11 :
        Inputs : INV-314314
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 29-OCT-24, Action Item Date Due: 30-OCT-24, Action Item Description:  Product Complaint Exchange: [she placed a cartridge to pen, but she forgot to lower the plunger all the way and the medication leaked completely out. Mom denies dropped/wet pen. Patient has missed doses when he was sick, MD instructed her to hold the medicine. Mom requested for 1 replacement cartridge] Initial ICSR (PRD 29Oct2024, SRD 29Oct2024);
            Argus Narrative        : Narrative for case number 202400290078: This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 147579.
                                    A 16-year-old male patient received somatropin (GENOTROPIN PEN 12), since Oct2024 (Batch/Lot number: unknown) at 2.4 mg daily. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DEVICE BREAKAGE (non-serious) with onset 2024, outcome "unknown", described as "2 cartridges were broken"; ILLNESS (non-serious) with onset Oct2024, outcome "unknown", described as "Patient has missed doses when he was sick"; WRONG TECHNIQUE IN DEVICE USAGE PROCESS (non-serious), DEVICE LEAKAGE (non-serious) all with onset Oct2024, outcome "unknown" and all described as "she placed a cartridge to pen, but she forgot to lower the plunger all the way and the medication leaked completely out". The action taken for somatropin was unknown.
                                    Additional information: Mom stated that she wanted an In-Home Nurse Training because the pen was so complicated and she does not know what she was doing. Mom stated that her mother is a nurse and helps her with the pen. She placed a cartridge to pen but she forgot to lower the plunger all the way and the medication leaked completely out. Mom denied dropped/wet pen. Mom requested for 1 replacement cartridge. It was also reported that the patient missed doses when he was sick on unspecified date; MD instructed her to hold the medicine. On 07Nov2024, parent stated that 2 cartridges were broken.
                                    Product Quality Group provided investigational results on 27Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: Site Investigation: No further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Leaking During Prep/Use, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    Causality for "she placed a cartridge to pen, but she forgot to lower the plunger all the way and the medication leaked completely out" and "2 cartridges were broken" was determined associated to device constituent of somatropin (malfunction).

                                    The information on the batch/lot number for somatropin will be requested and submitted if and when received.

                                    Follow-up (07Nov2024): This is a spontaneous follow-up report received from a Consumer, Program ID: 147579. Updated information: frequency of suspect provided as daily and new event (Parent stated that 2 cartridges were broken).

                                    Follow-up (27Nov2024): This is a follow-up report received from product quality group providing investigation result.

                                    Batch/lot number is not provided, & it cannot be obtained.
        Outputs:
            Complaint Issue : [Leaking During Prep/Use]


    Example 12 :
        Inputs : INV-314693
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 23-OCT-24, Action Item Date Due: 24-OCT-24, Action Item Description:  Product Complaint Exchange: [Guardian of a patient who used Genotropin indicated that the pen was not working well, they were losing hormone.];
            Argus Narrative        : Narrative for case number PV202400137636: The initial case was missing the following minimum criteria: Product Complaint only. Upon receipt of follow-up information (reportability determination) on 23Oct2024, this case now contains all required information to be considered valid.

                                    This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 002930.
                                    
                                    An 11-year-old male patient received somatropin (GENOTROPIN PEN), (Batch/Lot number: unknown), Device Lot Number: D101. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DEVICE MALFUNCTION (non-serious), DEVICE LEAKAGE (non-serious), outcome "unknown" and all described as "the pen was not working well, they were losing hormone".
                                    
                                    The reporter considered "the pen was not working well, they were losing hormone" not related to somatropin. Causality for "the pen was not working well, they were losing hormone" was determined associated to device constituent of somatropin (malfunction).
                                    
                                    Product Quality Group provided investigational results on 14Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: No further investigation was required as no valid lot number or returned samplewas available. This complaint will continue to be trended. If additionalinformation becomes available, this complaint will be reopened. This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Leaking During Prep/Use, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.
                                    
                                    The information on the batch/lot number for somatropin will be requested and submitted if and when received.
                                    
                                    Follow-up (14Nov2024): This is a follow-up report from product quality group providing investigation results.
                                    Follow-up (12Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.


        Outputs:
            Complaint Issue : [Leaking During Prep/Use]

# ---------------------------------------------------- U2 Loss of Function ----------------------------    

    Example 13 :
        Inputs : INV-314210
            Device : U2
            Complaint Description  : Action Code: Product Complaint Exchange, Action Item Date Open: 28-OCT-24, Action Item Date Due: 29-OCT-24, Action Item Description:  Product Complaint Exchange: Initial PRD 24Oct2024/ SRD 25Oct2024 . Genotropin Pen 12 : Old device broken;
            Argus Narrative        : Narrative for case number PV202400139583: This is a spontaneous report received from a Physician from product quality group, Program ID: 147579.
                                    
                                    An 11-year-old patient received somatropin (GENOTROPIN PEN 12), (Batch/Lot number: unknown). The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DEVICE ISSUE (non-serious), outcome "unknown", described as "old device broken". The action taken for somatropin was unknown.
                                    
                                    Additional information: Prescription received for Genotropin 12 pen device to be use as directed. Old device broken, send new pen device to patient's address.
                                    
                                    Causality for "old device broken" was determined associated to device constituent of somatropin (malfunction).
                                    
                                    Product Quality Group provided investigational results on 14Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: No further investigation was required as no valid lot number or returned sample was available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened. Device Investigation: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Loss of Function, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There no current trend alert documented.
                                    
                                    The information on the batch/lot number for somatropin will be requested and submitted if and when received.
                                    
                                    Amendment: This follow-up report is being submitted to amend previously reported information: patient detail updated.
                                    
                                    Batch/lot number is not provided, and it cannot be obtained.
                                    
                                    Follow-up (14NOV2024): This is a follow-up report from product quality group providing investigation results.
                                    Follow-up (09Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.

        Outputs:
            Complaint Issue : [Loss of Function]

            
    Example 14 :
        Inputs : INV-314250
            Device : U2
            Complaint Description  : Patient's dad advised the nurses that the Pen is not working and nurses requested for a new pen to be sent
            Argus Narrative        : Narrative for case number PV202400137534: This is a spontaneous report received from a Consumer or other non HCP from product quality group, Program ID: 121228.

                                    A 15-year-old male patient received somatropin (GENOTROPIN PEN), (Batch/Lot number: unknown) at 0.6 mg, subcutaneous, Device Lot Number: A127, Device Expiration Date: 31Mar2025. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DRUG DOSE OMISSION BY DEVICE (non-serious), described as "1 missed dose"; DEVICE DEFECTIVE (non-serious), described as "Pen is not working". The action taken for somatropin was unknown.

                                    Causality for "1 missed dose" and "pen is not working" was determined associated to device constituent of somatropin (malfunction).
                                    Additional information: The patient's dad advised the nurses that the pen is not working and the nurses requested for a new pen to be sent. The pen is available for return.

                                    Product Quality Group provided investigational results on 28Nov2024 for somatropin (device constituent): Investigation Summary and Conclusion: This investigation is based on the information captured in the Complaint Description and Argus Report. The Complaint Issue, Loss of Function, was reported. The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX100281795), Version (9.0). All complaint investigations are trended. There is not a current trend alert documented.

                                    Follow-up (28Nov2024): This is a follow-up spontaneous report received from product quality group providing investigational results.

        Outputs:
            Complaint Issue : [Loss of Function]


    Example 15 :
        Inputs : INV-314583
            Device : U2
            Complaint Description  : Added on 30-Oct-2024 by Oana-Mirela Busuioc:This is a sister complaint of COMPLAINT-758388, created for the second Genotropin 12mg pen reported in FUP received on 24-Oct-2024,as per DCHU's request received under Ad Hoc Task (Task-007004): "Please create another complaint record for the additional information received: "PT mum stated that PT has missed his daily dose since the 16/10 due to a faulty device and waiting for replacement. I have just taken a call from the parent of the above patient who advised that the replacement device requested and sent was not correct or not working. No further information provided.". Complaints are cross referenced.Investigating Site was notified via email and confirmed a necessary additional complaint for the second pen with lot unknown, related to COMPLAINT-758388. Email attached under RD tab.No consent confirmed from initial reporter, therefore no further details can be obtained at the moment, no
                                    FURs will be opened by SCMOQ. If additional information is received directly
                                    from Homecare, case will be updated accordingly. Initial response has been provided in original complaint, COMPLAINT-758388.
            Argus Narrative        : Narrative for case number 202400290228: This is a spontaneous report received from a Consumer or other non HCP, Program ID: 147579.

                                    A 17-year-old male patient received somatropin (GENOTROPIN PEN 12), (Batch/Lot number: unknown) at 1.8 mg. The patient's relevant medical history and concomitant medications were not reported.
                                    The following information was reported: DRUG DOSE OMISSION BY DEVICE (non-serious), described as "Patient may potentially miss doses while waiting for a new pen"; DEVICE USE ERROR (non-serious), described as "The pen has been dropped like three times"; DEVICE DEFECTIVE (non-serious), described as "it is not working properly anymore". The action taken for somatropin was unknown.

                                    Additional information: Patient's mom reported that the pen has been dropped like three times, so now it is not working properly anymore. Patient may potentially miss doses while waiting for a new pen. On 05Nov2024, patient's mom stating that she called last week for a new pen, but she has not received it yet.

                                    Causality for "patient may potentially miss doses while waiting for a new pen", "the pen has been dropped like three times" and "it is not working properly anymore" was determined associated to device constituent of somatropin (malfunction).

                                    Follow-up (05Nov2024): This is a spontaneous follow-up report received from a consumer, Program ID: 147579. Updated information included: device course details.

                                    Batch/lot number is not provided, and it cannot be obtained.
                                    Follow-up (04Dec2024): Follow-up attempts are completed. Batch/lot number is not provided, and it cannot be obtained.


        Outputs:
            Complaint Issue : [Loss of Function]


        Example 13 :
        Inputs : INV-324095
            Device : U2
            Complaint Description  : Complaint Description : Action Code: Product Complaint Exchange, Action Item Date Open: 03-DEC-24, Action Item Date Due: 04-DEC-24, Action Item Description: Product Complaint Exchange: [Initial (PRD 02Dec2024, SRD 03Dec2024). Genotropin Pen 12: the patient's pen device had malfunctioned.];
            Argus Narrative        : Narrative for case number 202400316963: The initial case was missing the following minimum criteria: adverse event. Upon receipt of reportability assessment on 02Dec2024, this case now contains all required information to be considered valid.
                                     This is a spontaneous report received from a Nurse from product quality group, Program ID: 147579.
                                     A 15-year-old male patient received somatropin (GENOTROPIN PEN 12), (Batch/Lot number: unknown) at 2.4 mg daily. The patient's relevant medical history and concomitant medications were not reported.
                                     The following information was reported: DEVICE MALFUNCTION (non-serious), outcome "unknown", described as "the patient's pen device had malfunctioned". The action taken for somatropin was unknown.
                                     Additional information: Nurse stated that the patient's pen device had malfunctioned.
                                     Product Quality Group provided investigational results on 02Dec2024 for somatropin (device constituent): Investigation Summary and Conclusion: No further investigation is required as no valid lot number or returned sample is available. This complaint will continue to be trended. If additional information becomes available, this complaint will be reopened.
                                     Causality for "the patient's pen device had malfunctioned" was determined associated to device constituent of somatropin (malfunction).
                                     The information on the batch/lot number for somatropin will be requested and submitted if and when received.

        Outputs:
            (Key catching point to address complaint issue is :- the patient's pen device had malfunctioned)
            Complaint Issue : [Loss of Function]

        

    # ---------------------------------------------------- Abrysvo Leaking During Prep/Use ----------------------------    

    Example 16 :
        Inputs : INV-314201
            Device : Abrysvo
            Complaint Description  : A pharmacist is calling about Abrysvo. When they try to mix it, a little bit of it got expelled and but wasn't a great amount . The caller is asking if they need to discard it or it's still good to use
            Argus Narrative        : ARGUS reference number - AE Ref. Number : [] / Ref. Number : / Complaint ID : MDCP-134771 / Legacy Complaint ID :
                                     The Narrative information is not available in ARGUS for this reference number.

        Outputs:
            Complaint Issue : [Leaking During Prep/Use]

            
    Example 17 :
        Inputs : INV-314218
            Device : Abrysvo
            Complaint Description  : The product has leaked from the adapter during reconstitution. Administration was carried out with another unit without any problems.
            Argus Narrative        : Narrative for case number 202400290608: This case has been considered invalid as no adverse event was reported. Product complaint only.
                                    Call from the Pharmacy for a problem reconstituting the Abrysvo vaccine, she would like to be contacted again
                                    Samples Available?: Sample Availability Unknown

        Outputs:
            Complaint Issue : [Leaking During Prep/Use]


    Example 18 :
        Inputs : INV-314287
            Device : Abrysvo
            Complaint Description  : REQUEST NAME: REQ-1590219 DESCRIPTION OF COMPLAINT: Pharmacist calling after trying to dilute abrysvo and it exploded on the HCP. She went to go get a different one to administer to a patient lot:LG2911 exp: May 2025 consent: yes replacement: McKesson account#: 81612-7009023.PRODUCT BUSINESS UNIT: Vaccines PRODUCT REPORTING NAME: ABRYSVO PRODUCT THERAPEUTIC AREA: Vaccines REQUEST PRODUCT GENERIC DESCRIPTION: Respiratory Syncytial Virus Stabilized Prefusion F Subunit Vaccine
            Argus Narrative        : ARGUS reference number - AE Ref. Number : [] / Ref. Number : / Complaint ID : MDCP-134688 / Legacy Complaint ID :
                                     The Narrative information is not available in ARGUS for this reference number.


        Outputs:
            Complaint Issue : [Leaking During Prep/Use]

    # ---------------------------------------------------- Abrysvo Vial Adapter - Unable/Difficult to Assemble/Use ----------------------------    

    Example 19 :
        Inputs : INV-314208 
            Device : Abrysvo
            Complaint Description  : Concern: Reporter (Pharmacist) stated, "I was just calling about malfunctioning Abrysvo vaccine. I had 2 of them where the punctured did not go correctly. So, I could not use the vaccine."

                                    When paraphrased the concern: Reporter stated, "Yes, so they would not puncture correctly. So, I was unable to use the vaccine."
                                    
                                    Product details:
                                    When probed for the product details (LOT#, Expiration date, UPC# and NDC#): Reporter stated, "So, they were both from the same LOT."
                                    
                                    -Vial details: (Captured in tab)
                                    LOT#: LG9828
                                    Expiration date: 10/2025 (Clarified as October 2025)
                                    UPC#: Reporter stated, "UPC on the box is 300690344058 (UPC# could not be clarifed appropriately, hence not captured in tab)."
                                    NDC#: 0069034405 (NDC# captured as provided)
                                    
                                    -Diluent details:
                                    LOT#: HA3218
                                    Expiration date: 3/2026 (Clarified as March/2026)
                                    NDC#: 0069025001
                                    UPC#: Reporter stated, "There is not UPC on those."
                                    
                                    -Adaptor details:
                                    LOT#: J010
                                    Expiration date: 9/1/2028 (Clarified as September/1/2028)
                                    NDC#: Reporter stated, "I do not see and NDC# on that."
                                    UPC#: Reporter stated, "There is no UPC."
                                    
                                    Purchase details:
                                    Name: McKesson
                                    Mailing address: 2101 12th Avenue South, Clear Lake, IA 50428
                                    Telephone#: 855-625-6285
                                    
                                    Is a sample of the product available to be returned, if requested: Reporter stated, "Yes, I would be able to return the product back to Pfizer, yes. I kept everything."
                                    Packaging sealed and intact: Reporter stated, "The product was received in one piece, yes."
                                    Product strength and count size dispensed: Reporter stated, "2 of the 5 of the boxes were defective."
                                    
                                    Reporter was informed that the product complaint has been filed and informed not to discard the product as this report would be forwarded for review to our Pfizer Quality Department. If it is needed that product is required for further evaluation, then a prepaid FedEx mailer would be sent to you within 3 to 10 business days. 
                                    
                                    Reporter stated, "And then so they will likely follow-up for replacement?"
                                    
                                    Reporter was informed about the replacement process.

            Argus Narrative        : Narrative for case number 202400287099: This case is considered invalid as Other-Info not qualifying for AE reporting - Product Complaint; there is no patient mentioned in this report and no adverse event.

        Outputs:
            Complaint Issue : [Vial Adapter - Unable/Difficult to Assemble/Use]

            
    Example 20 :
        Inputs : INV-314320
            Device : Abrysvo
            Complaint Description  : Call was transferred from Pfizer Connect Inbound by Cokee. (CSP ID: 004756)

                                    Transferring agent stated, "I do have here a Pharmacist on the other line. So, the caller is calling about Abrysvo and he stated that they received five vials and two out of five has no seal on it and then when he tried to mix them then it doesn't have a seal. All the liquid went all over the vial and it did not mix and he is looking for replacement."
                                    
                                    When paraphrased the above concern, reporter stated, "Yes, it's possible."
                                    
                                    Reporter was informed about the role of Pfizer Drug Safety and also informed that safety report and product complaint will be filed.
                                    
                                    Product Details:
                                    When probed if reporter has the product handy, reporter stated, "Yes, I do."
                                    
                                    Abrysvo Vial: (Captured in tab)
                                    LOT#: HN8090
                                    Expiration date: August 2025
                                    NDC#: 00069020701
                                    UPC#: Reporter stated, "No, I don't. I have a 9 digit#. No."
                                    
                                    Abrysvo Syringe: 
                                    LOT#: HG1756
                                    Expiration date: May, 2025
                                    NDC#: 00069025001
                                    UPC#: Reporter stated, "That's not on the either. There is no 12 numbers all I see is a PAA209778. It's not 12, it's 9 numbers."
                                    
                                    Abrysvo Adapter:
                                    LOT#: H983
                                    Expiration date: August 1st, 2028
                                    NDC#: Reporter stated, "It could be two numbers 07290108240078. 28080110 possibly."
                                    UPC#: Reporter stated, "No, I don't have that."
                                    
                                    Abrysvo Diluent:
                                    When probed for (LOT#, Expiration date, NDC#, UPC#) reporter stated, "I thought I gave that you. 07290108240078."
                                    LOT#: Reporter stated, "That's the same as the that's the HG1756 for the diluent."
                                    
                                    Second Abrysvo Vaccine:
                                    When probed if reporter has the Second Abrysvo Vial, reporter stated, "Yes, they both came from the same box. 
                                    
                                    Reporter stated, "The diluent also has the same thing."
                                    When probed to clarify that products details are same for the second Abrysvo Vial, reporter stated, "Yes."
                                    
                                    When probed to clarify that products details are same for the second Abrysvo adapter, reporter stated, "Yes."
                                    
                                    Purchase details: 
                                    Name: We purchased it from American source Bergen.
                                    Mailing address: 5100 Jaindl Boulevard Bethlehem, PA 18017.
                                    
                                    Telephone#: 610-727-7000
                                    
                                    Product strength and count size dispensed: Reporter stated, "We get the five count box and it's just Abrysvo."
                                    
                                    Is a sample of the product available to be returned, if requested: Reporter stated, "Yes."
                                    Packaging sealed and intact: Reporter stated, "Yes, they were sealed."
                                    
                                    When clarified not administered to any patient, reporter stated, "No."
                                    
                                    Reporter was informed not to discard the product as the report will be forwarded for review by our Quality department.Â  If it is determined that the sample is needed for further evaluation, a pre-paid FedEx mailer might be sent within 3 to 10 business days.
                                    
                                    Reporter was advised that with the FedEx mailer there will be a letter that will have the PCOM reference number and the number for replacement department.

                                    
            Argus Narrative        : Narrative for case number 202400286988: This case is considered invalid as Other-Info not qualifying for AE reporting - Product Complaint: there is no patient mentioned in this report and no adverse event.

        Outputs:
            Complaint Issue : [Vial Adapter - Unable/Difficult to Assemble/Use]


    Example 21 :
        Device : Abrysvo
        Inputs : INV-314321
            Complaint Description  : I am a cvs pharmacist. We received a defective Abrysvo â€œneedleâ€ that broke when we tried to use it How could I get a replacement dose?
            Argus Narrative        : Narrative: ARGUS reference number - AE Ref. Number : [] / Ref. Number : / Complaint ID : MDCP-134748 / Legacy Complaint ID :
                                     The Narrative information is not available in ARGUS for this reference number.


        Outputs:
            Complaint Issue : [Vial Adapter - Unable/Difficult to Assemble/Use]

    # ---------------------------------------------------- Abrysvo Luer Lock Detached During Prep/Use ----------------------------    

    Example 22 :
        Device : Abrysvo
        Inputs :  INV-314147
            Complaint Description  : Concern: Reporter (Pharmacist) stated, "I am calling. I have a product issue with a Abrysvo vaccine. When we put the, I guess when we are adding the diluent into the powder, when I went to pull it out the plunger part, the needle just pulled away and so it did not, I could not attach a syringe to it." When paraphrased the above concern, reporter confirmed the same. If vaccine has been administered to any patient: Reporter stated, "No that what the problem is that we could not administer the vaccine. Yes, the syringe kind of failed. So, I do not know what I am trying do is. I am trying to see if you send me another vaccine or do something since, I purchased it?" When probed if the details provided are of vial, syringe or adapter, reporter stated, "It was the syringe. I gave you the LOT and everything of the syringe." Vial details: LOT#: HY1811 Expiration date: October 2025 NDC#, UPC#: That does not have an NDC# or UPC#, it does not have anything. All I have. there is nothing else. Oh, it does have an NDC 0069020701. Purchase details: Name: Reporter stated, "I get it from the Cardinal Health." Mailing address and telephone number#: Reporter stated, "The number is 1800-926-3161." Product strength and count size dispensed: Reporter stated, "I had a problem with one of syringes just one." Packaging sealed and intact: Reporter stated, "Yes." Is a sample of the product available to be returned, if requested (Y/N): Reporter stated, "I can return the syringe. I cannot return the packing." Reporter was informed that a safety report has been filed along with a product complaint. Reporter was informed not to discard the product as this report would be forwarded for review to our Pfizer Quality Department. If it is needed that product is required for further evaluation, then a prepaid FedEx mailer might be sent to you within 3 to 10 business days.
            Argus Narrative        : Narrative for case number 202400289241: This case is considered invalid as Other- Info not qualifying for AE reporting - Product complaint: There is no indication that the consumer experienced an event under Product ABRYSVO.

        Outputs:
            Complaint Issue : [Luer Lock Detached During Prep/Use]

            
    Example 23 :
        Inputs : INV-314220
            Device : Abrysvo
            Complaint Description  : Description of complaint: Reporter calling regarding Abrysvo. The adapter part is defective. 
                    Product strength and count size dispensed: not provided 
                    Additional lot numbers:

                    Abrysvo Carton: Details captured in suspect product details formal field.  
                    Lot number: KC7884
                    Expiration Date: Sep 2025
                    NDC: 0069-0344-01
                    Manufacturer: Pfizer
                    Abrysvo Vial Adapter: 
                    Lot number/Exp Date/NDC: Unknown does not have the vial adapter to provide details. 
                    Manufacturer: Unknown does not have the vial adapter to provide details. She assuming it's the same as everything cause it's all in the same box.  
                    Abrysvo Antigen Vial: 
                    Lot/Exp/NDC/Manufacturer: Unknown, does not have the vial to provide details.  
                    Abrysvo Diluent Syringe: 
                    Lot/Exp/NDC/Manufacturer:  Unknown, does not have the syringe to provide details
                    Is a sample of the product available to be returned, if requested (Y/N): not provided 
                    Packaging sealed and intact? not provided 
                    Consumer, patient, caregiver: n/a
                      Please provide the name and address of the pharmacy/dispenser of the product
                    All Other Customers (e.g., pharmacy): not provided 
                      Please provide the name and address of the supplier/distributor of the product
                    Replacement Request: Informed should receive follow-up letter in the mail. The letter should contain reference number along with number to call for Customer Services Special Programs Team. Provided with report reference number.

            Argus Narrative        : Narrative for case number 202400286797: This case has been considered invalid as [Other-Info not qualifying for AE reporting-Product complaint]. There is no indication that the consumer experienced an event under Abrysvo.

        Outputs:
            Complaint Issue : [Luer Lock Detached During Prep/Use]


    Example 24 :
        Inputs : INV-314474
            Device : Abrysvo
            Complaint Description  : Call was transferred from Pfizer RxPathways by Erica (CEP ID: 005570).

                                Transferring agent stated, "I have a pharmacist on the back line. They are calling for a product quality complaint about Abrysvo. I did not get that information from them, they wanted to report malfunction."

                                When paraphrased the concern: Reporter (pharmacist) stated, "Correct."

                                Reporter further stated, "So, we were able to reconstitute it, but when the, you know, the connector piece on the syringe that allow to connect a needle to it, that actually popped off the actual, the syringe portion once it was reconstituted."

                                Reporter was informed about the role of Pfizer Drug Safety.

                                Product details (Vial):
                                NDC#: 00069034401
                                Expiration date: February 2025
                                LOT#: HR4390
                                UPC#: 300690344010

                                Product details (Syringe):
                                Expiration date: March/2025
                                LOT#: HA3218
                                NDC#: 00069034401
                                UPC#: 300690344010

                                Product details(Adaptor):
                                When probed for the LOT#, NDC#, UPC# and Expiration date of Adaptor details: Reporter stated, "I do not have the one for the adaptor." 

                                Purchase details:
                                Name: McKesson
                                Telephone# and mailing address: Reporter stated, "No, I do not have it on me right now.

                                Product strength and count size dispensed: Reporter stated, "Just one of them. Once package that has all 3 parts in it."

                                Is a sample of the product available to be returned, if requested: Reporter stated, "Yes, the broken one, I guess. I still have the vial and the adaptor and the broken piece and the syringe. I just do not have the plastic that 'they' came in" 

                                Packaging sealed and intact:  Reporter stated, "It was in a closed box so, no."

                                Reporter was informed that Product complaint has been filed and not to discard the product as this report would be forwarded for review to Pfizer quality department, If require product is required for further evaluation, then a prepaid FedEx mailer would be sent within 3 to 10 business days.  

                                Reassurance: Reporter stated, "So, once they review the, I guess the open complaint. Will they send me a replacement product or will I be credited for this product?"

                                Reporter was informed about the replacement procedure.

                                Reporter stated, "So, I have to follow up with it."

                                Reporter was informed about FedEx mailer.
                                
            Argus Narrative        : Narrative for case number 202400289284: This case has been considered invalid as Other-Info not qualifying for AE reporting – Product Complaint.


        Outputs:
            Complaint Issue : [Luer Lock Detached During Prep/Use]


    # ---------------------------------------------------- Abrysvo Component Damaged During Prep/Use ----------------------------    

    Example 25 :
        Inputs : INV-314496
            Device : Abrysvo
            Complaint Description  : Call was transferred from Pfizer Connect Inbound HCP by Jewel (CSP ID: 004756).

                                    Transferring agent stated, "I have a Pharmacist on the other line because they order a lot of Abrysvo before, it used to have a very good product but lately, she noticed it is a bit malfunctioning and the top comes off in the process of mixing it and they lost syringes. So, she wanted to get a replacement for that."

                                    When paraphrased the above concern, reporter (Pharmacist) stated, "Yes, I am looking so basically, we lost two syringes like that when we are trying to reconstitute it and then, when you put like and then the top part comes off. Before it was not like that, this new batch is not good. We have been ordering Abrysvo for like a lot, we administered a lot. We switched ordering Abrysvo for all the patients but I honestly, I am regretting it now because we lost two syringes like that and I have to be very careful with the other ones too. What happens the top comes off and then, we lose the product with this like the product. I just have two empty syringes so, what am I supposed to do with them?"  

                                    Product details (LOT#, Expiration, NDC# and UPC#) of Syringe, vial, adapter and diluent: Reporter stated, " No, I do not have this (Hence, details of the Abrysvo vaccine was captured in tab as provided)."

                                    Purchase details: 
                                    Name: Reporter stated, "No, we got it from Cardinal."
                                    Contact# and mailing address: Reporter stated, "You need the phone# for the rep? The cardinal rep phone# is 603-440-8977."

                                    Product strength and count size dispensed: Reporter stated, "This is Abrysvo that you guys produce it is like, this should be known, it is just like one strength and one syringes of and one syringe should have been administered. I am calling for something that only comes in one dose." 
                                    Packaging sealed and intact: Reporter stated, "Everything look intact." 
                                    Is a sample of the product available to be returned, if requested: Reporter stated, "It is an empty syringe because we lost the medication. When you squeeze it, it squeezed out from all the sides. So, if you want that empty syringe. There is no sample, we have two syringes in the sharp container. If you want me to dig through the sharp container, I can but it is in a sharps, we threw it in a sharps. So, if it is needed, I can go through the sharps if you want it, but I do not know." 

                                    Reporter was informed not to discard the product as the report would be forwarded for review by our Quality department. If determined that the sample needed for further evaluation, a pre-paid FedEx mailer might be sent within 3 to 10 business days and also about the replacement procedure.
            
            Argus Narrative        : Narrative for case number 202400286972: This case is considered invalid as Other-Info not qualifying for AE reporting - Product Complaint: there is no patient mentioned in this report and no adverse event.

        Outputs:
            Complaint Issue : [Component Damaged During Prep/Use]

            
    Example 26 :
        Inputs : INV-314622
            Device : Abrysvo
            Complaint Description  : Call was transferred from Pfizer Connect Inbound HCP by Nikki (CEP ID: 004756).

                                    Transferring agent stated, "I have a caller on other line, and she is Pharmacist, and they were trying to reconstitute the Abrysvo however it broke." 
                                    
                                    When paraphrased the concern, reporter stated, "Right."
                                    
                                    When probed if product was administered to patient, reporter stated, "Yes, I was not able to administer it because some of the diluent leaked out so, I wasn't sure like how the concentration would be have been right."
                                    
                                    Product details: Reporter stated, "I have a LOT number and expiration date it is on the outside of the box, you want that part. That is all I have."
                                    
                                    When probed if reporter have product details for syringe, adaptor and vial, reporter stated, "All I can find is the actual syringe part has like a liquid in it. I got 2 numbers on that if that is going be what you need though. I can see a NDC on it 0069025001."
                                    
                                    Purchase details:
                                    Name: Reporter stated, "Through McKesson."
                                    Mailing address and telephone#: Reporter stated, "I can give you the telephone number like on official website 800-793-9875."
                                    
                                    Product strength and count size dispensed: Reporter stated, "0.5 milliliters."
                                    
                                    Is a sample of the product available to be returned, if requested (Y/N): Reporter stated, "I have the box, but the actual like vial puts in a container. I guess I could save if they needed me to."
                                    
                                    Packaging sealed and intact: Reporter stated, "Yes."
                                    
                                    Reporter was informed that Product complaint has been filed and not to discard the product as this report would be forwarded for review to Pfizer quality department, If require product is required for further evaluation, then a prepaid FedEx mailer would be sent within 3 to 10 business days.  
                                    
                                    Reassurance: Report stated, "That is it. So, I guess my boss has had this happened 2 time before with the same kind of vaccine and before he said that like he was given a credit. So, how does something like that work. It wasn't for the same patient, but it was for the same issue on 2 different(Incomplete sentence)."(Further clarification was not available)."
                                    
                                    Reporter was provided with the number of Trade Special Programs for credit as (866) 485-1359 and timings as 8:00am to 5:30pm EST, Monday through Friday.
            
            Argus Narrative        : Narrative for case number 202400288081: This is a spontaneous report received from a Pharmacist from product quality group, Program ID: 004756.

                                    A 90-year-old female patient should have received rsv vaccine prot.subunit pref 2v (ABRYSVO), as dose 1, 0.5 ml single (Lot number: KC7884, Expiration Date: Sep2025) for immunisation. The patient had no relevant medical history. There were no concomitant medications.
                                    The following information was reported: DEVICE BREAKAGE (non-serious), outcome "unknown", described as "It broke/malfunction"; DEVICE LEAKAGE (non-serious), outcome "unknown", described as "Some of the diluent leaked out".

                                    The reporter considered "it broke/malfunction" and "some of the diluent leaked out" not related to rsv vaccine prot.subunit pref 2v. Causality for "it broke/malfunction" and "some of the diluent leaked out" was determined associated to device constituent of rsv vaccine prot.subunit pref 2v (malfunction).

                                    Additional information: The pharmacist reported that they were trying to reconstitute the Abrysvo vaccine, however they had a Abrysvo vaccine malfunction, it broke. The reporter was not able to administer it, because some of the diluent leaked out, so she/he was not sure like how the concentration would be have been right. The patient did not receive the vaccine.

                                    Causality for "it broke/malfunction" and "some of the diluent leaked out" was determined associated to device constituent of rsv vaccine prot.subunit pref 2v (malfunction).

                                    Follow-up (04Dec2024): Follow-up attempts are completed.

                                    Follow-up (29Nov2024): This is a follow-up report received from product quality group providing device assessment.

        Outputs: 
            Complaint Issue : [Component Damaged During Prep/Use]


    Example 27 :
        Inputs : INV-315863
            Device : Abrysvo
            Complaint Description  : A pharmacist called Quality dept. on 31-Oct-2024 and reported that one ABRYSVO 120mcg PSF 1x0.5ml GVL+SYR lot. LR2101 exp. 06/30/2026 was defective. More specifically, the syringe was not screwed well, the seals were broken and the vaccine was spilled out.
                                
            Argus Narrative        : Narrative for case number 202400291732: This case has been considered invalid as Info not qualifying for AE reporting - Product complaint only.

                                    This is a spontaneous report received from a Pharmacist from product quality group.

                                    Additional information: A pharmacist called Quality dept. on 31Oct2024 and reported that one ABRYSVO 120mcg PSF 1x0.5ml GVL+SYR lot. LR2101 exp. 06/30/2026 was defective. More specifically, the syringe was not screwed well, the washers were broken and the vaccine was spilled out.
                                    Reporter Consent to Contact: Yes
                                    Reported Lot Number: LR2101
                                    Samples Available?: Yes

                                    Product quality complaint group verified that the reporter was a pharmacist (contact details were provided).


        Outputs:
            Complaint Issue : [Component Damaged During Prep/Use]


    # ---------------------------------------------------- Abrysvo Plunger Loose/Detached ----------------------------    

    Example 28 :
        Inputs : INV-314475
            Device : Abrysvo
            Complaint Description  : Description of complaint: Suspect Product; Report 1 of 2; reporting a product quality complaint for Abrysvo that happened today with a malfunction during reconstitution and the caller was reconstituting the powder and the syringe fell apart and liquid expelled over his hands and all over the floor; caller asking for replacement product. Carton/box: lot number KC7884, expiry date Sep2025, NDC 0069034401, manufacturer Pfizer. Caller states he has no lots, expiry dates, NDC numbers or manufacturer names to provide for the vial adaptor, diluent syringe or antigen vial because those components were discarded in their sharps container. Product strength and count size dispensed: one Abrysvo vaccine Additional lot numbers: n/a Is a sample of the product available to be returned, if requested (Y/N): Yes, aware he may receive a prepaid FedEx mailer in 3-10 business days. Packaging sealed and intact? Yes Consumer, patient, caregiver: n/a Please provide the name and address of the pharmacy/dispenser of the product: n/a All Other Customers (e.g., pharmacy): Please provide the name and address of the supplier/distributor of the product: Cardinal; phone 1-800-926-3161; has no mailing address to provide.
            Argus Narrative        : Narrative for case number 202400287887: This case has been considered invalid as Info not qualifying for AE reporting-Product complaint, there is no indication that the consumer experienced an event under Product Abrysvo.

        Outputs:
            Complaint Issue : [Plunger Loose/Detached]

            
    Example 29 :
        Inputs : 
            Device : Abrysvo
            Complaint Description  : REQUEST NAME: REQ-1582730
                                     DESCRIPTION OF COMPLAINT: Warm transfer from Allie H with Pfizer Connect. CEP number was queried but agent did not know what that was. She transferred a HCP who was calling about a product malfunction with Abrysvo which included a leakage in vial. 
                                     
                                     The HCP stated that he is looking for help to get reimbursement for the vaccine.  He stated that he has the Abrysvo kit which includes the vial, adapter, and prefilled syringe. He had connected the adapter to vial and was about to insert the liquid from the syringe, there was an issue with the plunger of the syringe, and that the liquid leaked from the syringe and adapter. He provided the following NDC number for the product that he experienced this issue with: 00069-0344-01. He also stated that the liquid did not come into contact with anyone as he was wearing gloves and that this "was not the first time."
                                     
                                     PQC: E-transmitting potential additional/duplicate PQC. Warm transferred HCP to DSU agent Daylon, NTID: GRUBBD02 with reportum number IP6UKDS5.
                                     PRODUCT BUSINESS UNIT: Vaccines
                                     PRODUCT REPORTING NAME: ABRYSVO
                                     PRODUCT THERAPEUTIC AREA: Vaccines
                                     REQUEST PRODUCT GENERIC DESCRIPTION: Respiratory Syncytial Virus Vaccine

            Argus Narrative        : Narrative: ARGUS reference number - AE Ref. Number : [] / Ref. Number : / Complaint ID : MDCP-134891 / Legacy Complaint ID :
                                     The Narrative information is not available in ARGUS for this reference number.

        Outputs: 
            Complaint Issue : [Plunger Loose/Detached]


    Example 30 :
        Inputs : INV-314927
            Device : Abrysvo
            Complaint Description  :  REQUEST NAME: REQ-1595909
                                      DESCRIPTION OF COMPLAINT: Caller would like to report a damage unusable product. Caller state "When the pull on of the syringe normally does not come all the way out with this one it went all out. The vaccine was being drawn to the syringe when it happen.  It was being mix when it was being drawn the whole thing came out. Not just the diluent but the whole vaccine."
                                      
                                      PQC: E-transmitting potential duplicate and additional report. Warm transferred to DSU agent; NTID: TAYLOS42 Reportum: 6HIX3AJM
                                      
                                      DSU: e-transmitting potential AE. AE noted during transfer of call to DSU therefore limited information available.
                                      PRODUCT BUSINESS UNIT: Vaccines
                                      PRODUCT REPORTING NAME: ABRYSVO
                                      PRODUCT THERAPEUTIC AREA: Vaccines
                                      REQUEST PRODUCT GENERIC DESCRIPTION: Respiratory Syncytial Virus Vaccine                 
            Argus Narrative        : 
                                        Narrative for case number 202400291984: This case has been considered invalid as Info not qualifying for AE reporting - Product complaint.

                                        Reporting Notes: PQC: E-transmitting potential duplicate and additional report. Warm transferred to DSU agent; NTID: TAYLOS42 Reportum: 6HIX3AJM

                                        DSU: e-transmitting potential AE. AE noted during transfer of call to DSU therefore limited information available.
                                        Attachments: 1
                                        Consent to Contact Reporter: N/A
                                        Consent to Contact HCP: N/A
                                        HCP Contact Information Available: No
                                        Reporter Subtype: Other HCP
                                        PQC Present: Yes
                                        AE Present: Yes

                                        PQC Details:


                                        Request Name: REQ-1595909
                                        Product: ABRYSVO
                                        Question: Caller would like to report a damage unusable product. Caller state "When the pull on of the syringe normally does not come all the way out with this one it went all out. The vaccine was being drawn to the syringe when it happen. It was being mix when it was being drawn the whole thing came out. Not just the diluent but the whole vaccine."

                                        PQC: E-transmitting potential duplicate and additional report. Warm transferred to DSU agent; NTID: TAYLOS42 Reportum: 6HIX3AJM

                                        DSU: e-transmitting potential AE. AE noted during transfer of call to DSU therefore limited information available.
                                        Response: Warm transferred to DSU for assistance regarding product complaint.

                                        Submitted by US Call Centre 1 Ref:373468; ININ: 67004473-bae5-4232-b27d-5f89a932ebb8; GRACE: INT-01320718



                                        System Reference: no transfer to USMI required



                                        Is report related to a study or programme? No



                                        Selected Report Type: Initial



                                        Reporter consent to contact given: Yes

                                        Reporter type: Consumer or other non health professional

                                        Specify Consumer or other non health professional: Medical assistant calling on behalf of office

                                        Reporter email: hvfpfront@gmail.com



                                        HCP postal address: United States (the)



                                        Is Abrysvo a Pfizer product? Yes

                                        Abrysvo manufacturer: unspecified

                                        NDC number of Abrysvo: 0069025001

                                        Expiry Date of Abrysvo: Oct 2025



                                        Additional Context: Warm transfer from NTID: GUEVAA24; GRACE: INT-01320718. Caller is reporting an Abrysvo vaccine that was damaged and unusable. Have already mixed the vaccine and went try to pull mixture from the vial, the part of the syringe it went all out.

                                        Confirms contact details upon transfer.

                                        Clarifies that when pulled on syringe, normally it does not fly out of the hub, but with this defective Abrysvo it came completely out with no force, as if it did not have suction like it normally does.

                                        Their office deals with Vaxcare and Vaxcare instructed her to call to report to Pfizer.

                                        Caller is a medical assistant calling on behalf of office.

                                        Confirms no patient involvement with defective Abrysvo.

                                        Abrysvo Carton: does not have available

                                        Lot number: unknown

                                        Expiration Date: unknown

                                        NDC: unknown

                                        Manufacturer: unknown

                                        Abrysvo Vial Adapter: discarded packaging

                                        Lot number: unknown

                                        Expiration Date: unknown

                                        NDC: unknown

                                        Manufacturer: unknown

                                        Abrysvo Antigen Vial, states this is the antigen component

                                        Lot number: KD0161

                                        Expiration Date: Oct 2025

                                        NDC: 0069020701

                                        Manufacturer: Pfizer

                                        Abrysvo Diluent Syringe: (documented in suspect product formal field)

                                        Lot number: HP4001

                                        Expiration Date: Oct 2025

                                        NDC: 0069025001

                                        Manufacturer: Pfizer, states the manufacturer name Pfizer is listed so tiny.

                                        Vaxcare shipped the office more Abrysvo vaccine today.

                                        Confirms it was only one defective Abrysvo vaccine that she is reporting on. Vaxcare states their office needs confirmation that this will be creditable to vaxcare.

                                        PSCC Communication: PC filed. Provided report number. Provided report number. Informed to wait on correspondence from the quality department prior for reference number requested prior to contacting to address credit/replacement.



                                        Is there a product complaint to report? Yes

                                        Description of Product Complaint: Description of complaint: reporting an Abrysvo vaccine that was damaged and unusable. Have already mixed the vaccine and went try to pull mixture from the vial, the part of the syringe it went all out. Clarifies that when pulled on syringe, normally it does not fly out of the hub, but with this defective Abrysvo it came completely out with no force, as if it did not have suction like it normally does.

                                        Product strength and count size dispensed: one defective Abrysvo

                                        Additional lot numbers:

                                        Abrysvo Carton: does not have available

                                        Lot number: unknown

                                        Expiration Date: unknown

                                        NDC: unknown

                                        Manufacturer: unknown

                                        Abrysvo Vial Adapter: discarded packaging

                                        Lot number: unknown

                                        Expiration Date: unknown

                                        NDC: unknown

                                        Manufacturer: unknown

                                        Abrysvo Antigen Vial, states this is the antigen component

                                        Lot number: KD0161

                                        Expiration Date: Oct 2025

                                        NDC: 0069020701

                                        Manufacturer: Pfizer

                                        Abrysvo Diluent Syringe: (documented in suspect product formal field)

                                        Lot number: HP4001

                                        Expiration Date: Oct 2025

                                        NDC: 0069025001

                                        Manufacturer: Pfizer, states the manufacturer name Pfizer is listed so tiny.

                                        Is a sample of the product available to be returned, if requested (Y/N): Nothing left in vial, but still has the antigen vial and diluent syringe. Y, informed of prepaid fedex mailer that may arrive.

                                        Packaging sealed and intact? Y

                                        Consumer, patient, caregiver: N/A

                                        Please provide the name and address of the pharmacy/dispenser of the product

                                        All Other Customers (e.g., pharmacy):

                                        Please provide the name and address of the supplier/distributor of the product

                                        Vaxcare

                                        Address: unknown

                                        Phone: unknown

                                        Vaxcare states they need confirmation that this will be creditable to vaxcare.


        Outputs:
            Complaint Issue : [Plunger Loose/Detached]
"""