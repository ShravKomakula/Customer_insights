instructions ="""
1. In the investigation the following structure should be followed to get exact "Complaint Issue"
    1.1 Complaint Description (Foremostly scan through Complaint Description to get ['Complaint Issue'])
    1.2 Go through parent_additional_information to identify ['Complaint Issue'].
    1.3 Go through Argus Narrative for additional information for 'Complaint Issue'.
2. If Argus narrative contains 'Invalid' then the elements present in json should be 'NA'
3. Use accurate Hazard Id + Hazard name with Hazard Situation as per the Device name. Don't Hallicunate.
4. "Complaint Issue" should be captured very accurately and anyhow i need 3 "Complaint Issue" don't focus only on Few-Shots complaint mentioned, go through each "Complaint Issue" and "Instructions for Use" to answer accurate "Complaint Issue".

"""

# 3. if there is something like this 'adapter that goes on top to put the diluent into, to insert into the bottom portion' for 'Abrysvo' Device then the 'Complaint Issue' should be 'Luer Lock Detached During Prep/Use' rather than giving wrong 'Complaint Issue'.

# 5. if there is a statement of "the patient's pen device had malfunctioned" then the correct "Complaint Issue" would be 'Loss of Function'.


# 