import sqlite3
import os
 
def create_feedback_table():
    folder_path = os.path.join("python_api", "dependencies")
    db_path = os.path.join(folder_path, "chatbox.db")
    
    # Ensure the folder exists
    os.makedirs(folder_path, exist_ok=True)
    
    # Check if the database file already exists
    if os.path.exists(db_path):
        pass
    else:
        print(f"Creating database '{db_path}' and initializing tables.")
        
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
 
    # Create feedback table (for any feedback data, if needed)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        feedback TEXT NOT NULL,
        feedback_status TEXT NOT NULL,
        timestamp TEXT NOT NULL
    )
    ''')
 
    # Create chatboxquerytable for storing user inputs
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS chatboxquerytable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invNumber TEXT NOT NULL,
        product TEXT NOT NULL,
        complaintDescription TEXT NOT NULL,
        argusNarrative TEXT NOT NULL,
        dateEventOccurred TEXT NOT NULL,
        expirationDate TEXT NOT NULL,
        additionalInfo TEXT,
        timestamp TEXT NOT NULL
    )
    ''')
 
    # Create llm_responses table for storing LLM responses with invNumber as foreign key
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS llm_responses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invNumber TEXT NOT NULL,
        llm_response TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (invNumber) REFERENCES chatboxquerytable(invNumber)
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS AccuracyCal (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invNumber TEXT NOT NULL,
        product TEXT NOT NULL,
        feedback_status TEXT NOT NULL,
        conclusion TEXT NOT NULL,
        complaint_issue TEXT NOT NULL,
        hazard_analysis TEXT NOT NULL,
        imdrf_code TEXT NOT NULL,
        capa_reference TEXT NOT NULL,
        actual_failure TEXT NOT NULL,
        accuracy REAL NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

      
    # Commit changes and close the connection
    conn.commit()
    conn.close()
    return conn
 
# # Call the function to create the table when the script is run
# if __name__ == "__main__":
#     create_feedback_table()
 
 
