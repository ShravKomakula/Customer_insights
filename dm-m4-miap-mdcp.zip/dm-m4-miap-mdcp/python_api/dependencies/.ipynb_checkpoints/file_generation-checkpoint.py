import pandas as pd

def file_details():
    df = pd.read_csv("complaint_listing.csv")
    text="""
    below is the data for complaint issues please understant it well..\n
    """

    for index, row in df.drop(columns=['Unnamed: 0']).iterrows():
        text+= f"Complaint Issue: {row['Complaint Issue']} | IMDRF Code: {row['IMDRF Code']} | CAPA Reference :  {row['CAPA Reference']} | Instructions for Use: {row['Instructions for Use']} \n"

    df = pd.read_csv("dei_cleaned.csv")

    text+="""
    -------------------------------------------------------------------------------------------------
    below is the data for dei table please understant it well..\n
    """

    for index, row in df.iterrows():
        text+= f"Hazard ID: {row['Hazard ID']} | Hazardous Situation: {row['Hazardous Situation']}\n"

    df = pd.read_csv("Hazard_cleaned.csv")

    text+="""
    -------------------------------------------------------------------------------------------------
    please understand hazard situtations as listed below.
    """

    for index, row in df.drop(columns=['Unnamed: 0']).iterrows():
        text+= f"Hazard ID: {row['Hazard ID']} | Hazard: {row['Hazard']} |  Hazardous Situation: {row['Hazardous Situation']} \n"
    # print(text)
    return text