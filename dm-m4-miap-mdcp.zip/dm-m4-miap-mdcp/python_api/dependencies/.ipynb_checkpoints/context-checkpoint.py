from file_generation import *
context = f"""
You are medical survyer i have passed a file that contains certain columns which are enlisted below.

Name : Ivestigation number
DEI Lifecycle State : Describe status of investigation 
(Complaint) Description : Description of Complaint
Parent Addtl Information : Additional Information of Complaint
DCHU Additional Comments : Additional description which they get to know from follow ups. (one who has raised the complaint)
Reportability Determination : DCHU Reportability Determination sometimes contains information that can help us identify the complaint issue.  Not always relevant though.
ARGUS Information : Argus will include all adverse events, follow ups and complaint description and reported events. (this will be main document where most of the keywords should be selected. (Argus = Name of assistant , where report is generated and argus is software))
AE Reference Number : The AE Reference Number is going to be key to doing the cross reference to the content of the complaint report contained in the safety system.  We use this to identify the key words and complaint issues.  
Narrative : Description of argus information.
Conclusion : Summary of investigation
Complaint Issue : Short discription of complain issue 
CAPA Reference : An issue number, in case that comes up again that can be used again.
IMDRF Code : International Medical Device Reference Code.  There is one IMDRF Code per Complaint Issue.  The Complaint Issue Listing contains the IMDRF code.  
Batch Expiration Date : this is batch Expiration Date and if this is null then it is not going to expire anytime.
Date Opened : Date on which it was opened device was open.
Hazard ID : This is hazard ID
Hazardous Situation_Ignore :  Detailed description of Harzardous Situation but you can ignore this.
Hazard : This is hazard ID
Hazardous Situation : Detailed description of Harzardous Situation.
CASE_NUM : Case number 
NARRATIVE FULL DESCRIPTION : Narrative full descriptions this is the most important column in the data.
DEI FINAL STATUS : this is the final status which is to be considered for response.
IMDRF Code_y : International Medical Device Reference Code.  There is one IMDRF Code per Complaint Issue.  The Complaint Issue Listing contains the IMDRF code.  
CAPA Reference_y : An issue number, in case that comes up again that can be used again.
Instructions for Use : these are the instructions that are to be used.

please understand this :- 
{file_details()}

now i have some questions what i will give. and please answer them properly.

here Name,DEI Lifecycle State,(Complaint) Description,Parent Addtl Information,DCHU Additional Comments,Reportability Determination,ARGUS Information,	AE Reference Number,Narrative,Batch Expiration Date,Date Opened are the inputs columns.
and output columns are :- Conclusion,Complaint Issue,CAPA Reference,IMDRF Code

and output should be in json format.
```json
{
    "Conclusion": "(summary for the complaint after understanding narratives and all.)",
    "Complaint Issue" : "(Answer for complaint Issue)",
    "CAPA Reference" : "(CAPA Reference answer)",
    "IMDRF Code" : "(IMDRF Code answer)",
    "Actual Failure" : "(Device was actual failure or not i want in YES/NO)."
}
"""