from .config import *
import json
import requests
from .context import *
# from .prompts import prompt_template

def search(prompt_template, token,documentmd5):
# def search(prompt_template, token):
# def search(token):
    try:
        url = SEARCH_URL
        payload = json.dumps({
                    "user_query": prompt_template,
                    "system_message":"",
                    "context": [context],
                    "embedding_engine": "text-embedding-ada-002",
                    # "llm_engine": "gpt-4-32k",
                    "llm_engine": "gpt-4o",
                    # "llm_engine":"anthropic.claude-3-haiku-v1:0",
                    # "llm_engine" : "anthropic.claude-3-sonnet-v1:0",
                    # "llm_engine":"anthropic.claude-v2",
                    "llm_response_flag": False,
                    "temperature": 0.2,
                    "max_tokens": 4096,
                    "max_input_tokens":25000,
                    
                    "metadata": {
                        "documentmd5" :[documentmd5]
                    },
                    "metadata_filter_condition":"and",
                    "filter": "pre",
                    "num_of_citations": 10,
                    "with_score":True,
                    "vector_score_threshold": 0.9,
                    "multi_query_retriever":False,
                    "include_original_query":False,
                    "num_of_queries":3,
                    "compress_rerank_retriever":False,
                    "parent_document_retriever":False,
                    "rerank_model":"ms-marco-MiniLM-L-12-v2",
                    "space_type":"cosineSimilarity",
                    "search_type":"approximate_search"
        })
        headers = {
          'Content-Type': 'application/json',
          'Authorization': f'Bearer {token}'
        }
        response = requests.post(url, headers=headers, data=payload)
        return response.json()
    except Exception as e:
        print(e)