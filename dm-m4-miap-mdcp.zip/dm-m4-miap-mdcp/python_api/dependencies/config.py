#Define credentials and env variables
CLIENT_ID = "28172ae4602449ceaec640cd1845c595"
CLIENT_SECRET = "137866A51ac54F2f83b0777465fBe53a"
PINGFEDERATE_URL = "https://devfederate.pfizer.com/as/token.oauth2?grant_type=client_credentials"
INGEST_URL = "https://mule4api-comm-amer-dev.pfizer.com/vessel-docinsight-api-v1/ingest"
STATUS_URL = "https://mule4api-comm-amer-dev.pfizer.com/vessel-docinsight-api-v1/status"
SEARCH_URL = "https://mule4api-comm-amer-dev.pfizer.com/vessel-docinsight-api-v1/search"
bucket = "pdops-ngmp-mdcp-poc"