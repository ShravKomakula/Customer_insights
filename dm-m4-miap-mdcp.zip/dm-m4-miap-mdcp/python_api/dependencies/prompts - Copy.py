from .get_information_from_tables import final_text

def prompt_template(investigation_number,device_name,complaint_description,argus_narative,contact_date,expiration_date,parent_additional_information):
    # Hazard IDs, Hazard-Hazardous Situation
   prompt_template =f"""
 
   Conclusion: A summary or final assessment based on the given data.
   Complaint Issue: A description of the primary issue or complaint being addressed.
   CAPA Reference: A reference to the Corrective and Preventive Actions (CAPA) related to the issue.
   IMDRF Code: The relevant code from the International Medical Device Regulators Forum (IMDRF).
   Actual Failure: A detailed explanation of the actual failure or issue that occurred."
 
   Given the below Inputs :
 
   INV Name : {investigation_number}
   Short Trade Name : {device_name}
   (Complaint) Description : {complaint_description}
   Argus Narative : {argus_narative}
   Date of contact : {contact_date}
   batch expiration date : {expiration_date}
   Parent(Additional information) : {parent_additional_information}

   Hazard IDs, Hazard-Hazardous Situation
 
  
 
    {{ 
       "Conclusion": "(conclusion must have 4 parts.
                       each thing should be covered in each line. and every point should start in new line.
 
                           Complaint Overview:
                               This investigation is based on the information captured in the Complaint Description and, if applicable, the corresponding Argus Report.
                               The Complaint Issue (enter the Complaint Issue exactly as selected in the Complaint Issue field above) was reported.
                               If necessary, provide further explanation or rationale for why or how the Complaint Issue was selected in this section.
                              
                           Risk Management Review:
                               The Risk Management File was reviewed to confirm that the Hazard(IDs) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX# (enter the INX# of the                     document reviewed), Version # (enter the Version number of the document reviewed)).
                              
                           Trend Analysis:
                               All complaint investigations are trended. There (select one: is/is not) a current trend alert documented.
                          
                           CAPA Reference:
                               (Note: If there is a CAPA associated with the Complaint Issue being investigated, document the associated CAPA ID in the CAPA field. If no CAPA is associated, mark it as "NA.")
      
       "Complaint Issue" : "(Based on the data provided for U2 and Abrysvo, identify the complaint issue accurately.
                          Examples of complaint issues include: "Damaged Component" "Injection Knob/Dial Issue" "Injection Failure/Blocked")",
                            (Get all Complaint Issue whatever is possible)
       Hazard Analysis:
                        Based on the Complaint Issue and Complaint Description, map and identify the hazards along with their associated Hazard IDs and Hazardous Situations. Use "|" as a separator between each piece of information, and format as follows:
                        
                        "H01-01, Sharp Edges"
                        "H01-04, Exposed Needle"
                        Provide the relevant Hazard ID + Hazard for the complaint.
                        (Get all possible Hazard Analysis and its details)
 
       IMDRF Code:
                Determine the appropriate IMDRF Code based on the Complaint Issue for the product. Stick strictly to the provided IMDRF Code data without any assumptions. Return the code that corresponds to the Complaint Issue.
                (Get all possible IMDRF code that is possible)
                For example:
                
                "D1102"
                "D09"
                Provide the relevant IMDRF Code based on the given complaint.
                
 
       CAPA Reference:
                    Based on the IMDRF Code, provide the correct CAPA Reference linked to it. Ensure the IMDRF Code is checked thoroughly. If no CAPA is associated with the IMDRF Code, mark it as "NA." If there is a corresponding CAPA, provide the correct reference.
                    For example:
                    
                    "5237707"
                    "NA"
                    Return the correct CAPA Reference based on the IMDRF Code.
 
 
       Actual Failure:
                    Was the device the actual failure? Provide the answer in YES or NO.
 
       Explanation:
                    Explain why the selected Complaint Issue is being chosen. Provide a brief rationale for your selection.
 
   }}
 
   Understand the below examples and answer the questions accurately:
   Inputs :-
       investigation_number :- INV-274131
       Complaint Description: When attempting to mix, all liquid was pushed in but dry product remained. Unsure if there was insufficient liquid or diluent. Product could not be drawn up, but no leakage occurred.
                           Product Details:
 
                                Manufacturer: Pfizer (Vial Adapter, Antigen Vial, Diluent Syringe)
                                Vial Adapter LOT: H739, EXP: Apr 2028
                                Antigen Vial LOT: HM7644, EXP: Jan 2025, NDC: 0069-0207-01
                                Diluent Syringe LOT: HG1755, EXP: May 2025, NDC: 0069-0250-01
                                Sample available: Yes (possible prepaid FedEx mailer in 3–10 days)
                                Packaging: Sealed and intact
                                Supplier: Amerisource, 7775 W Buckeye Rd, Suite 150, Phoenix, AZ, 85043, Phone: 877-770-4915
                                        The reporter attempted to mix the Abrysvo vaccine, but after pushing all the liquid in, dry product remained. It is unclear whether there was insufficient liquid or diluent. The product could not be                              drawn up, but there was no leakage. The issue occurred with one kit out of a box of five; the other kits were fine. There was no patient involvement with this product.
 
                    Product Details:
                    
                        Abrysvo Carton: LOT HM7644, EXP Jan 2025, NDC 0069-0344-05, Manufacturer: Pfizer
                        Abrysvo Vial Adapter: LOT H739, EXP Apr 2028, NDC Unknown, Manufacturer: West Pharma
                        Abrysvo Antigen Vial: LOT HM7644, EXP Jan 2025, NDC 0069-0207-01, Manufacturer: Pfizer
                        Abrysvo Diluent Syringe: LOT HG1755, EXP May 2025, NDC 0069-0250-01, Manufacturer: Pfizer
                        Additional Information:
                        
                        Sample available for return (Y/N): Yes
                        Packaging: Sealed and intact
                        Supplier: Amerisource, 7775 W Buckeye Rd, Suite 150, Phoenix, AZ 85043, Phone: 877-770-4915                                  
      
       Argus Narrative:
                    When mixing, all liquid was pushed in but dry product remained. It is unclear if there was insufficient liquid or diluent. The product could not be drawn up, but there was no leakage. No patient involvement. The issue occurred with one Abrysvo kit from a box of five; the other kits were fine.
                    AER #: 202400094603, RS: 30APR2024
 
       Contact Date: 1/31/2025
       Expiration Date: 5/1/2024
      
       parent_additional_information :-  
                    04/24/2024 03:06 PM (GMT-4:00) added by Robin Mundie (PID-314284):
                    d.  Reporter states: I attached the images to this email. I am honestly not             ontainer was underfilled. I attached the adapter to the vial and pushed the              vial as I normally do. Then as I was agitating the suspension, I noticed that it           ear liquid as it usually does.
 
                    **************************************************************
                    -4:00) added by Robin Mundie (PID-314284):
                    ing photos of the affected product.  
            
                    **************************************************************
                    -04:00) added by CITI Admin Import (PID-351337):
                    ial
            
                    Product Name: Abrysvo
                    NDC Number: 0069-0344-05
 
  
   Outputs
       conclusion :- This investigation is based on the information captured in the Complaint Description and Argus Report.
       The Complaint Issue, Damaged Component, was reported. It is interpreted that the dilute was under filled.
       An additional Complaint Issues of Unable/
 
       Complaint Issue :- Damaged Component
 
       CAPA Reference  :- NA
      
       IMDRF Code :- 'D04'
 
 
Please go through Instructions below and follow them very carefully.
   Instructions:
        1. Complaint Issue Identification
        Goal: Identify the Complaint Issue precisely from the provided data.
        
        Action:
        
            Complaint Issue should be derived from the ('Instructions for Use','General Guidance') after carefully go through Argus Narrative,Complaint Description and Parent Additional Information provided.
            Focus on exact descriptions related to product malfunctions or failures during use (e.g., device part breakage, failure to dispense, leakage, etc.) there are some general Complaint issue which should be given lower priority than other complaint issues such as ("Damaged Component","Leaking During Prep/Use","Product Used Beyond Expiry").
        Example:
            If the issue is related to the device failing to properly dispense, the Complaint Issue should be "Injection Failure" or "Injection Not Dispensing as Expected."
            If a part of the device breaks, the Complaint Issue could be "Cartridge/Syringe Barrel Broken During Prep/Use."
        
        Clarification: The wording must be precise—avoid using generic terms. Base the Complaint Issue on the data provided and the specific scenario that was described.
        
        2. IMDRF Code and CAPA Reference
        Goal: Derive the IMDRF Code and CAPA Reference based on the identified Complaint Issue.There are seperate tables which has been specified please go through that tables carefully for the device which has been given by user.
        Action:
        
            Link each Complaint Issue to its corresponding IMDRF Code and CAPA Reference.
            Review the Complaint Issue, then use the IMDRF Code table and CAPA Reference to map them accordingly.
            Clarification:
            
            Be careful not to mix general Complaint Issues with specific ones. Specific Complaint Issues should be prioritized.
            For instance, if the issue concerns "Injection Failure," use the IMDRF Code that applies to that specific scenario.
        Example:
        
            Complaint Issue: "Injection Failure"
            IMDRF Code: D09
            CAPA Reference: 5237707
        
        3. Hazardous Situation Identification
        Goal: Identify the Hazard ID + Hazard associated with the Complaint Issue.
        
        Action:
            Study the Complaint Description, Parent Additional Information, and Narrative to identify any hazardous situations.
            Identify the Hazard ID and Hazard by linking it with the Complaint Issue.
            Look for any details that suggest potential harm or risk during use, such as incomplete dosing, difficulty drawing up product, leakage, or underfilled containers.
        Clarification:
            Ensure that only one Hazard ID + Hazard is selected based on the complaint.
            The Hazard ID should align with the specific situation mentioned in the complaint.
        Example:

            Hazard: "Underfilled Container"
            Hazard ID + Hazard: H01-02, Underfilled Container
        
        4. Critical Analysis and Accuracy
        Goal: Ensure that all findings are based on concrete data, avoiding errors in analysis.
        
        Action:
        
            Do not speculate or make assumptions.  Findings on the exact data provided in the Complaint Description, Argus Narrative, and other sources.
            Cross-check all identified Complaint Issues, Hazard IDs, IMDRF Codes, and CAPA References for consistency and correctness.
        Clarification:

        5. Passing data to capture proper CAPA reference,Hazard id + Hazard, Complaint Issue and IMDRF based on device 
           Go through in depth for '(Instructions for Use)' to identify accurate 'Complaint Issue' and based on that 'IMDRF Code','CAPA Reference' and also carefully understanding the 'Hazardous Situation' to fetch all 'Hazard ID + Hazard' 
        \n {final_text}
        
        Example of Final Output Based on Data
 
            {{
            "Complaint Issue": "Injection Failure",
            "IMDRF Code": "D09",
            "CAPA Reference": "5237707",
            "Hazard ID + Hazard": "H01-02, Underfilled Container",
            "Conclusion": 
                    "The complaint issue regarding injection failure was reported. This issue involves the underfill of the product during mixing, leading to incomplete dispensing.",
                    "The Risk Management File was reviewed to confirm that the Hazard H01-02, Underfilled Container, is documented in the Hazard Analysis INX# 12345, Version 3.",
                    "All complaint investigations are trended. There is no current trend alert documented.",
                    "CAPA Reference": "5237707"
            Explanation: "Injection Failure was considered as it was clearly stated initially that injection was failure",
            Actual Failure:"Yes"            
            }}
 
  
   """
 
   return prompt_template