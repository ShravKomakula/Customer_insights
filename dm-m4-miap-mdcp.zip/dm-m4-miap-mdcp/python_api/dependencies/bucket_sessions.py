import boto3
import os
def get_presigned_url(file_name,bucket):
    """
    Uploads a file to an S3 bucket and generates a pre-signed URL for accessing the uploaded file.

    This function uploads the file specified by `file_name` to the provided S3 bucket. After the file 
    is successfully uploaded, it generates a pre-signed URL that allows temporary access to the file 
    without requiring AWS credentials. The URL is valid for 24 hours (86400 seconds) by default.

    Parameters:
    file_name (str): The local path to the file to be uploaded.
    bucket (str): The name of the S3 bucket where the file will be uploaded.

    Returns:
    str: A pre-signed URL that provides temporary access to the uploaded file.

    Example:
    >>> url = get_presigned_url('myfile.txt', 'my-bucket-name')
    >>> print(url)
    """
    
    session = boto3.Session()
    s3_client = session.client('s3')
    object_name = os.path.basename(file_name)
    s3_client.upload_file(file_name, bucket, object_name)
    presigned_url = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket,
                                                            'Key': object_name},
                                                    ExpiresIn=86400)
    return presigned_url