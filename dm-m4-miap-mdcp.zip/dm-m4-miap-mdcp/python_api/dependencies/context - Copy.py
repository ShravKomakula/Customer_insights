from .get_information_from_tables import final_text

context = f"""
You are medical survyer i have passed a file that contains certain columns which are enlisted below.

Name : Ivestigation number
DEI Lifecycle State : Describe status of investigation 
(Complaint) Description : Description of Complaint
Parent Addtl Information : Additional Information of Complaint
DCHU Additional Comments : Additional description which they get to know from follow ups. (one who has raised the complaint)
Reportability Determination : DCHU Reportability Determination sometimes contains information that can help us identify the complaint issue.  Not always relevant though.
ARGUS Information : Argus will include all adverse events, follow ups and complaint description and reported events. (this will be main document where most of the keywords should be selected. (Argus = Name of assistant , where report is generated and argus is software))
AE Reference Number : The AE Reference Number is going to be key to doing the cross reference to the content of the complaint report contained in the safety system.  We use this to identify the key words and complaint issues.  
Narrative : Description of argus information.
Conclusion : Summary of investigation
Complaint Issue : Short discription of complain issue 
CAPA Reference : An issue number, in case that comes up again that can be used again.
IMDRF Code : International Medical Device Reference Code.  There is one IMDRF Code per Complaint Issue.  The Complaint Issue Listing contains the IMDRF code.  
Batch Expiration Date : this is batch Expiration Date and if this is null then it is not going to expire anytime.
Date Opened : Date on which it was opened device was open.
Hazard ID : This is hazard ID
Hazardous Situation_Ignore :  Detailed description of Harzardous Situation but you can ignore this.
Hazard : This is hazard ID
Hazardous Situation : Detailed description of Harzardous Situation.
CASE_NUM : Case number 
NARRATIVE FULL DESCRIPTION : Narrative full descriptions this is the most important column in the data.
DEI FINAL STATUS : this is the final status which is to be considered for response.
IMDRF Code_y : International Medical Device Reference Code.  There is one IMDRF Code per Complaint Issue.  The Complaint Issue Listing contains the IMDRF code.  
CAPA Reference_y : An issue number, in case that comes up again that can be used again.
Instructions for Use : these are the instructions that are to be used.


In complaint issue table for Abrysvo and U2 we have following schema:
    Device               :- device name 
    Complaint Issue	     :- Gives information about complaint issue
    IMDRF Code	         :- International Medical Device Regulators Forum (Linked to Complaint Issue)
    CAPA Reference	     :- CAPA Reference is based on IMDRF Code and should be captured on its own based on IMDRF Code.
    Instructions for Use :- this specifies Instructions how it should be used.

In complaint issue table for U2 Complaint Listing to get hazard id have following schema:
    Device                                        :- U2  (this table is to fetch information for U2 Hazard id only , use appropriate ids.)
    Related HA Line Items INX100281795 V9.0       :- Contains detailed information about hazard id and hazard situtations

    
In HAZARD MAPPING tables contains have the following schema:
    Device               :- device name 
    Hazard ID + Hazard   :- hazard id and hazard name
    Hazardous Situation  :- Describing Hazardous Situation


please understand this :- 
{final_text}
Based on the above tabular data map Hazard Id + Hazard, IMDRF, CAPA Reference, Complaint Issue from the tabular data and give conclusion based on the structure i have mentioned to give.

Here Name,DEI Lifecycle State,(Complaint) Description,Parent Addtl Information,DCHU Additional Comments,Reportability Determination,ARGUS Information,	AE Reference Number,Narrative,Batch Expiration Date,Date Opened are the inputs columns.
and output columns are :- Conclusion,Complaint Issue,CAPA Reference,IMDRF Code,Hazard Analysis (this is a new column)

and output should be in json format.
    ```json
    {{
        "Conclusion": "(conclusion must have 4 parts.
                        each thing should be covered in each line. and every point should start in new line.

                            Complaint Overview:
                                This investigation is based on the information captured in the Complaint Description and, if applicable, the corresponding Argus Report.
                                The Complaint Issue (enter the Complaint Issue exactly as selected in the Complaint Issue field above) was reported.
                                If necessary, provide further explanation or rationale for why or how the Complaint Issue was selected in this section.
                                
                            Risk Management Review:
                                The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX# (enter the INX# of the document reviewed), Version # (enter the Version number of the document reviewed)).
                                
                            Trend Analysis:
                                All complaint investigations are trended. There (select one: is/is not) a current trend alert documented.
                            
                            CAPA Reference:
                                (Note: If there is a CAPA associated with the Complaint Issue being investigated, document the associated CAPA ID in the CAPA field. If no CAPA is associated, mark it as "NA.")
        
        "Complaint Issue" : "(Answer for complaint Issue based on the data provided for U2 and Abrysvo devices and don't go beyond that. this is very critical and get through complaint listing for each product meticulously based on 'Complaint Issue' data provided)",
        "Hazard Analysis" : "(Based on complaint issue identify hazard id and then bring response as (Hazard ID + Hazard Name along with Hazardous Situation, put | as seperator after each content based on 'Hazard ID + Hazard' data provided))
        "IMDRF Code"      : "(Determine the IMDRF Code based on the complaint issues for product and don't halicunate beyond , stick to what is provided return me with proper IMDRF Code with respect to Complaint Issues based on 'IMDRF Code' data provided)",
        "CAPA Reference"  : "(Based on IMDRF Code provide me the correct CAPA Reference linked, check the IMDRF Code properly, if it is not present then make it NA else bring out correct CAPA reference based on 'CAPA Reference' data provided)",
        "Actual Failure"  : "(Device was actual failure or not i want in YES/NO).",
        "Explanation"     : "(Explain why are we selecting the mentioned Complaint Issue. Give a brief explanantion for it)"
    }}






    basically each output respresents :-
    Complaint Issue: (select the identified Complaint Issue, for example: Cannot Set Dose, Injection Failure/Blocked)
    Hazard Analysis: (In this drop down, select the reported Hazard ID(s), Hazard(s), and Hazardous Situation(s).)
    Conclusion: (In this section, enter the following template language and the specifics related to the individual complaint as follows:)
                This investigation is based on the information captured in the Complaint Description and, if applicable, the corresponding Argus Report.
                The Complaint Issue, (enter the Complaint Issue exactly as selected in the Complaint Issue field above), was reported1. (If needed, further explanation/rationale to clarify why/how the Complaint Issue was selected may be entered in this paragraph.)
                The Risk Management File was reviewed to confirm that the Hazard(s) and Hazardous Situation(s) associated with the Complaint Issue are documented in the Hazard Analysis (INX# (enter the INX# of the document reviewed), Version # (enter the Version number of the document reviewed)).
                All complaint investigations are trended. There (select one: is/is not) a current trend alert documented.
               (NOTE: If there is a CAPA associated with the Complaint Issue being investigated, document the associated CAPA ID in the CAPA field.

"""