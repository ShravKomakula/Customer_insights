import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('chatbox.db')
cursor = conn.cursor()

# # Fetch all queries from the chatboxquerytable
# # cursor.execute("SELECT * FROM chatboxquerytable")
# # rows = cursor.fetchall()
# # print("Chatbox Queries:")
# # for row in rows:
# #     print(row)

# Fetch all LLM responses using invNumber
cursor.execute("SELECT * FROM feedback")
rows = cursor.fetchall()
# print("feedback status:")
# for row in rows:
#     print(row)



cursor.execute("SELECT * FROM llm_responses")
rows = cursor.fetchall()
print("AccuracyCal Responses:")
for row in rows:
    print(row)

# # conn.close()
# import sqlite3
# import random
# from datetime import datetime, timedelta

# # Function to generate random data
# def generate_random_data(start_date, end_date):
#     # List of possible products
#     products = ['Abrysvo', 'U2']
#     conclusions = ['true', 'false']
    
#     # Generate 20 records per day between start_date and end_date
#     data = []
#     current_date = start_date
#     while current_date <= end_date:
#         for _ in range(20):  # 20 records per day
#             # Generate random invNumber
#             inv_number = f"INV-{random.randint(314100, 314999)}"
            
#             # Choose a random product
#             product_name = random.choice(products)
            
#             # Randomly choose other columns based on your defined features
#             feedback_status = random.choice(conclusions)
#             conclusion = random.choice(conclusions)
#             complaint_issue = random.choice(conclusions)
#             hazard_analysis = random.choice(conclusions)
#             imdrf_code = random.choice(conclusions)
#             capa_reference = random.choice(conclusions)
#             actual_failure = random.choice(conclusions)
#             accuracy = round(random.uniform(0.5, 1.0), 2)  # Accuracy between 0.5 and 1.0
#             timestamp = current_date.strftime('%d-%m-%Y')

#             # Append the record to the data list (don't specify `id` as it will autoincrement)
#             data.append((
#                 inv_number,
#                 product_name,
#                 feedback_status,  # Corrected to match the number of placeholders
#                 conclusion,
#                 complaint_issue,
#                 hazard_analysis,
#                 imdrf_code,
#                 capa_reference,
#                 actual_failure,
#                 accuracy,
#                 timestamp
#             ))
        
#         # Move to the next day
#         current_date += timedelta(days=1)
    
#     return data

# # Connect to SQLite database
# conn = sqlite3.connect('chatbox.db')
# cursor = conn.cursor()

# # Define start and end dates for data generation
# start_date = datetime(2023, 11, 1)
# end_date = datetime(2023, 12, 13)

# # Generate random data
# data = generate_random_data(start_date, end_date)

# # Insert the generated data into the AccuracyCal table
# cursor.executemany('''
#     INSERT INTO AccuracyCal (
#         invNumber, product, feedback_status, conclusion, complaint_issue, hazard_analysis, 
#         imdrf_code, capa_reference, actual_failure, accuracy, timestamp
#     )
#     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
# ''', data)

# # Commit the transaction
# conn.commit()

# # Fetch and print some records to confirm insertion
# cursor.execute("SELECT * FROM AccuracyCal")
# rows = cursor.fetchall()
# print("Sample Data from AccuracyCal:")
# for row in rows:
#     print(row)

# # Close the database connection
# conn.close()
