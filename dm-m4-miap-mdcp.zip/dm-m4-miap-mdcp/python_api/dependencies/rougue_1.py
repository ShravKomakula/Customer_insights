from rouge_score import rouge_scorer

def compute_rouge1_precision_recall(reference_text, predicted_text):
    """
    Computes the ROUGE-1 precision and recall between a reference text and a predicted text.

    Args:
        reference_text (str): The reference (ground truth) text to compare against.
        predicted_text (str): The predicted text to compare with the reference.

    Returns:
        tuple: A tuple containing ROUGE-1 precision and recall as percentages rounded to 0 decimal places.
            - (rouge1_precision, rouge1_recall)
            - Both precision and recall are returned as percentages (0-100).


    # ['rouge1', 'rougeL']
    """
    # Create a rouge scorer instance for ROUGE-1
    scorer = rouge_scorer.RougeScorer(['rouge1'])
    
    # Compute the ROUGE score
    scores = scorer.score(reference_text, predicted_text)
    
    # Extract ROUGE-1 precision and recall
    rouge1_precision = scores['rouge1'].precision * 100  # Convert to percentage
    rouge1_recall = scores['rouge1'].recall * 100  # Convert to percentage
    
    # Round the results to 0 decimal places and return
    return round(rouge1_precision, 0)#, round(rouge1_recall, 0)
