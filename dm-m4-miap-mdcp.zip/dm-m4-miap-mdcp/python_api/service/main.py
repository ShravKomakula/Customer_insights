

import sys
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import time
import logging

from fastapi.responses import FileResponse
from python_api.dependencies.config import *
from python_api.dependencies.bucket_sessions import get_presigned_url
from python_api.dependencies.generate_token import federate_auth
from python_api.dependencies.chunking_embedding import ingest_document
from python_api.dependencies.check_status import get_status
from python_api.dependencies.get_response import search
from python_api.dependencies.prompts import prompt_template
from pydantic import BaseModel
import json
import sqlite3
from datetime import datetime
from datetime import datetime
from typing import Any, Dict
import logging
from collections import defaultdict
import json
import re
import os
from difflib import SequenceMatcher
from python_api.dependencies.db import create_feedback_table 
# from python_api.dependencies.test import genapi
import re
from typing import Any, Dict, List
import threading







 
token = None
document_md5 = None
lock = threading.Lock()
 
app = FastAPI()


# create_feedback_table()



# data=genapi()

# print("dataa",data)
 
 
class LLMRequest(BaseModel):
    invNumber: str
    product: str
    complaintDescription: str
    argusNarrative: str
    dateEventOccurred: str
    expirationDate: str = "NA"
    additionalInfo: str = "NA"
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows the frontend to connect
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)


# Setup logging
logging.basicConfig(level=logging.INFO)
base_dir = os.path.dirname(__file__)
file_name = os.path.join(base_dir, "Complaint Issue Mapped with Hazards.xlsx")
print("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",file_name)
file_path = os.path.join(base_dir, file_name)
print("********************************************************************",file_path)

presigned_url = get_presigned_url(file_name, bucket)
 


# token = federate_auth()
# ingest_document_response = ingest_document(presigned_url, token)
# request_id = ingest_document_response["requestID"]

# logging.info("Waiting for ingestion to complete...")
# while get_status(request_id, token)['status']!= 'Completed':
#     ingestion_status = get_status(request_id, token)
#     time.sleep(1)
# document_md5 = ingestion_status['document_md5']

def generate_token():
    global token, document_md5
    try:
        with lock:  # Prevent race conditions
            logging.info("Generating a new token...")
            token = federate_auth()
            ingest_document_response = ingest_document(presigned_url, token)
            request_id = ingest_document_response["requestID"]

            logging.info("Waiting for ingestion to complete...")
            while get_status(request_id, token)['status']!= 'Completed':
                ingestion_status = get_status(request_id, token)
                time.sleep(1)
            document_md5 = ingestion_status['document_md5']
            logging.info("Token generated successfully.")
    except Exception as e:
        logging.error(f"Error generating token: {e}")
        raise HTTPException(status_code=500, detail="Error generating token.")


generate_token()

# def token_refresh_scheduler():
#     while True:
#         time.sleep(1200)  # 20 minutes
#         ()

# Start the Token Refresh Scheduler
# threading.Thread(target=token_refresh_scheduler, daemon=True).start()


def convert_to_snake_case(data: Any) -> Any:
    """Convert keys of a dictionary or list of dictionaries to snake_case recursively."""
    def to_snake_case(key: str) -> str:
        key = re.sub(r'[^a-zA-Z0-9]', '_', key)  # Replace non-alphanumeric characters with underscores
        key = re.sub(r'_+', '_', key)  # Replace multiple underscores with a single underscore
        key = key.strip('_')  # Remove leading/trailing underscores
        key = key.lower()  # Convert to lowercase
        return key

    if isinstance(data, dict):
        return {
            to_snake_case(key): convert_to_snake_case(value) for key, value in data.items()
        }
    elif isinstance(data, list):
        return [convert_to_snake_case(item) for item in data]
    else:
        return data


def format_hazard_analysis(text):
    # Split into parts by the first comma
    parts = text.split(",", 1)
    if len(parts) == 2:
        first_part = parts[0].upper()  # Fully capitalize the first part
        second_part = " ".join(
            word.capitalize() for word in parts[1].strip().split()
        )  # Capitalize the first letter of each word in the second part
        return f"{first_part}, {second_part}"
    return text.capitalize()  # If there's no comma, capitalize the first letter of the text



# Function to process data
def process_data(data):
    for entry in data:
        # Update complaint_issue: Capitalize first letter of each word
        entry["complaint_issue"] = " ".join(
            word.capitalize() for word in entry["complaint_issue"].strip("[]").split()
        )

        # Update hazard_analysis: Apply the custom formatting function
        entry["hazard_analysis"] = format_hazard_analysis(entry["hazard_id_hazard_situation"])

        # Update imdrf_code: Convert to uppercase if alphanumeric
        entry["imdrf_code"] = entry["imdrf_code"].upper()

        # Update capa_reference: Convert 'na' to 'N/A'
        entry["capa_reference"] = (
            entry["capa_reference"].upper() if entry["capa_reference"] != "na" else "N/A"
        )

    return data

def process_ingestion():
    try:
        logging.info("Ingesting document...")
        ingest_document_response = ingest_document(presigned_url, token)
        request_id = ingest_document_response["requestID"]
       
        logging.info("Waiting for ingestion to complete...")
        while True:
            ingestion_status = get_status(request_id, token)
            if ingestion_status['status'] == 'Completed':
                logging.info("Ingestion completed.")
                return ingestion_status['document_md5']
            time.sleep(1)
       
    except Exception as e:
        logging.error(f"Error during ingestion process: {e}")
        raise HTTPException(status_code=500, detail="Error during ingestion process")
   
@app.post("/get_llm_response")
def read_llm_response(request: LLMRequest):
    try:
        invNumber = getattr(request, 'invNumber', "NA")
        product = getattr(request, 'product', "NA")
        complaintDescription = getattr(request, 'complaintDescription', "NA")
        argusNarrative = getattr(request, 'argusNarrative', "NA")
        dateEventOccurred = getattr(request, 'dateEventOccurred', "NA")
        expirationDate = getattr(request, 'expirationDate', "NA")
        additionalInfo = getattr(request, 'additionalInfo', "NA")

        save_to_chatbox_query_table(request.dict())
        logging.info(f"Received data: {request.dict()} ")

        # print("expirationDate",expirationDate)
        
              # Validate and process expiration date
        today_date = datetime.now().date()  # Automatically gets today's date
        if expirationDate != "NA":
            try:
                exp_date = datetime.strptime(expirationDate, '%Y-%m-%d').date()
                if exp_date < today_date:
                    logging.warning(f"Expiration date {expirationDate} has already passed.")
                elif exp_date == today_date:
                    logging.info(f"Expiration date {expirationDate} is today.")
                else:
                    logging.info(f"Expiration date {expirationDate} is valid and in the future.")
            except ValueError:
                logging.error(f"Invalid format for expiration date: {expirationDate}")
                expirationDate = "Invalid Format"
        else:
            logging.info("Expiration date not provided.")


        # print("expirationDate      ",expirationDate)
        
        data=generate_token()
        prompt = prompt_template(product, complaintDescription, argusNarrative,additionalInfo, dateEventOccurred, expirationDate)
        search_response = search(prompt, token, document_md5)
        # print("search_response['llm_response'] \n\n",search_response['llm_response'])
        # if ((search_response['llm_response']!= False) or (search_response['llm_response'].str.contains('sorry')) or (search_response['llm_response'].str.contains('no information'))):
        #     print("please wait, trying again.....")
        #     time.sleep(10)
        #     prompt = prompt_template(invNumber, product, complaintDescription, argusNarrative, dateEventOccurred, expirationDate, additionalInfo)
        #     search_response = search(prompt, token, document_md5)
        # else:
        #     pass
        # print("search_response",search_response)
        if 'llm_response' in search_response:
            llm_response = search_response['llm_response']
            if (
                llm_response
                and not any(keyword in llm_response for keyword in ['sorry', 'no information'])
            ):
                # Proceed with the valid 'llm_response'
                print("Valid LLM response:", llm_response)
            else:
                # Retry logic if the response contains unwanted keywords
                # print("please wait, trying again.....")
                time.sleep(10)
                # Replace with your function to regenerate the prompt and reattempt the search
                prompt = prompt_template(
                    invNumber, product, complaintDescription, argusNarrative, 
                    dateEventOccurred, expirationDate, additionalInfo
                )
                search_response = search(prompt, token, document_md5)
        else:
            # Handle cases where 'llm_response' is not in the response
            print("'llm_response' is not present in the search response.")
            raise HTTPException(status_code=500, detail="LLM response is empty or not valid.")
        llm_response_raw = search_response.get('llm_response')
        print("******************************  final llm_response_raw *************************************\n\n",llm_response_raw)
        if not llm_response_raw:
            raise ValueError("LLM response not found in the search response.")
        try:
            # print("\n\n\n\n")
            # print("llm_response_rawllm_response_rawllm_response_raw \n\n\n",llm_response_raw)
            # print("\n\n\n\n")
            llm_response = json.loads(llm_response_raw.strip("```json\n").strip("\n```"))
            print("11111111111111111111111111111111111111111111111 \n\n\n",llm_response)
            # print("llm_responsellm_responsellm_responsellm_response \n\n\n\n",llm_response)
            llm_response_snake_case = convert_to_snake_case(llm_response)
            print("2222222222222222222222222222222222222222222222222 \n\n\n",llm_response_snake_case)
            save_llm_response_to_db(invNumber, llm_response_snake_case)
            save_accuracy_cal_to_db(invNumber,product)
            sorted_data = sorted(llm_response_snake_case, key=get_accuracy, reverse=True)
            processed_data = process_data(sorted_data)
            # print("processed_data",processed_data)
            output_data = format_conclusion_data(processed_data)
            # print("final data",output_data)
            # for entry in processed_data:
            #     print("\n\n\n\n\n\n\n\n\n\n",entry['conclusion'])
            #     if 'conclusion' in entry:
            #         entry['conclusion'] = format_conclusion_data(entry['conclusion'])
        except json.JSONDecodeError as e:
            # generate_token()
            logging.error(f" we got 500 error code so weagain gen new token json.JSONDecodeError")
            logging.error(f"Error parsing LLM response JSON: {e}")
            raise HTTPException(status_code=500, detail="Error parsing LLM response JSON.")
        return {"llm_response": output_data}
    except Exception as e:
        # generate_token()
        logging.error(f" we got 500 error code so weagain gen new token json.JSONDecodeError")
        logging.error(f"Error in processing LLM response: {e}")
        raise HTTPException(status_code=500, detail=" Error in processing LLM Model response")

def format_conclusion_data(data):
    import re

    def capitalize_after_period(text):
        """Ensure the first letter after each period is capitalized."""
        # Split text by periods followed by spaces
        sentences = text.split('. ')
        # Capitalize the first letter of each sentence and rejoin them
        return '. '.join([sentence.strip().capitalize() for sentence in sentences])
    

    def capitalize_first_letter_of_lines(text):
        """Capitalize the first letter of each new line."""
        lines = text.split('\n\n')
        return '\n\n'.join([line.capitalize() for line in lines])
    
    def capitalize_after_slash(text):
        """Capitalize the first letter of each word after a slash or space."""
        # Capitalize words after '/' or space
        text = re.sub(r'(/|\s)(\w)', lambda m: m.group(1) + m.group(2).upper(), text)
        return text

    def update_version(text, new_version):
        # Define the pattern to match 'Version X.X' where X is a number
        pattern = r'version\d+\.\d+'
        
        # Replace the old version with the new version
        updated_text = re.sub(pattern, f'{new_version}', text)
        
        return updated_text

    def custom_format(text):
        """Apply custom formatting rules."""
        # List of phrases to capitalize first letter of each word
        phrases_to_format = [
            "Complaint Description",
            "Argus Report",
            "complaint issue",
            "The Risk Management File",
            "Hazard(s)",
            "Hazardous Situation(s)",
            "Complaint Issue",
            "Hazard Analysis INX100281795, Version 9.0",
            "hazard analysis",
        ]

        # Capitalize first letter of each phrase
        for phrase in phrases_to_format:
            text = text.replace(
                phrase.lower(), 
                ' '.join(word.capitalize() for word in phrase.split())
            )

         # Capitalize mixed letter-number patterns (e.g., inx100281795 -> INX100281795)
        text = re.sub(r'\b([a-zA-Z]+)(\d+)', lambda m: m.group(1).upper() + m.group(2), text)

        # Fix the "Hazard Analysis" formatting using a more robust regex
        # Change "Hazard Analysis (INX100281795, version 9.0)" to "Hazard Analysis #INX100281795, Version # 9.0"
        text = re.sub(
            r'(Hazard Analysis)\s?\(\s?(INX\d+),\s?version\s?(\d+\.\d+)\)', 
            r'\1 #\2, Version # \3',
            text,
            flags=re.IGNORECASE
        )

        # Capitalize first letter in the dynamic phrase after "Complaint Issue"
        text = re.sub(
            r'(complaint issue,\s)(.*?)(, was reported)',
            lambda m: m.group(1) + ' "' + ' '.join(word.capitalize() for word in m.group(2).split()) + '"' + m.group(3)[1:],  # Adding quotes and removing comma
            text,
            flags=re.IGNORECASE
        )

        # Fix the issue with "the Complaint Issue" capitalization
        text = re.sub(r'(\bwith\s)(Complaint\sIssue)', r'\1the\2Complaint Issue', text)

        return text

    formatted_data = []

    for record in data:
        conclusion = record['conclusion']
        print("conclusion",conclusion)
        # Apply transformations
        conclusion=update_version(conclusion, 'Version')
        print("2222222222222222222222",conclusion)
        
        conclusion = capitalize_first_letter_of_lines(conclusion)
        conclusion = capitalize_after_slash(conclusion)
        conclusion = capitalize_after_period(conclusion)  # Capitalize first letter after each period
        conclusion = custom_format(conclusion)
        record['conclusion'] = conclusion

        formatted_data.append(record)
        

    return formatted_data


def get_accuracy(complaint):
                return int(complaint["accuracy"].replace("%", ""))  


def strike_not(text):
    return re.sub(r'\bnot\b', f"\u0336n\u0336o\u0336t", text)


def save_accuracy_cal_to_db(inv_number, product):
    conn =  get_db_connection()
    cursor = conn.cursor()
    print("conn",conn)
    print("cursor",cursor)

    # Get the current timestamp in the desired format
    current_date = datetime.now()
    timestamp = current_date.strftime('%d-%m-%Y')

    # Execute the insert query
    cursor.execute('''
    INSERT INTO AccuracyCal (
        invNumber,
        product,
        conclusion,
        feedback_status,
        complaint_issue,
        hazard_analysis,
        imdrf_code,
        capa_reference,
        actual_failure,
        accuracy,
        timestamp
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        inv_number,
        product,
        'true',
        'true',
        'true',
        'true',
        'true',
        'true',
        'true',
        'true',
        timestamp
    ))

    conn.commit()
    conn.close()



class Feedback(BaseModel):
    feedback: str
    invNumber: str
    timestamp: str
    type_status:str


def get_db_connection():
    folder_path = os.path.join("python_api", "dependencies")
    db_path = os.path.join(folder_path, "chatbox.db")
    
    # Ensure the folder exists
    os.makedirs(folder_path, exist_ok=True)
    
    # Check if the database file already exists
    if os.path.exists(db_path):
        pass
    else:
        print(f"Creating database '{db_path}' and initializing tables.")
    print("00000000000000000000000000000000000000000000000000000000000000000",db_path)
    # Create or connect to the database
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # To access columns by name
    return conn
  
 
 
def save_to_chatbox_query_table(request_data: dict):
    timestamp = datetime.now().isoformat()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO chatboxquerytable (invNumber, product, complaintDescription, argusNarrative,
                                   dateEventOccurred, expirationDate, additionalInfo, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (request_data['invNumber'], request_data['product'], request_data['complaintDescription'],
          request_data['argusNarrative'], request_data['dateEventOccurred'], request_data['expirationDate'],
          request_data['additionalInfo'], timestamp))
    conn.commit()
    conn.close()
 
# Save the LLM response to llm_responses
def save_llm_response_to_db(invNumber: str, llm_response: dict):
    timestamp = datetime.now().isoformat()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO llm_responses (invNumber, llm_response, timestamp)
    VALUES (?, ?, ?)
    ''', (invNumber, json.dumps(llm_response), timestamp))
    conn.commit()
    conn.close()
 
# @app.post("/feedback")
# async def submit_feedback(feedback: Feedback):
#     try:
#         timestamp = datetime.now().strftime('%d-%m-%Y')

#         conn = get_db_connection()
#         cursor = conn.cursor()

#         cursor.execute("PRAGMA table_info(AccuracyCal)")
#         columns = [col[1] for col in cursor.fetchall()]

#         matched_column = None
#         feedback_words = feedback.feedback.split() 

#         for word in feedback_words:
#             for column in columns:
#                 if word.lower() in column.lower():  
#                     matched_column = column
#                     break
#             if matched_column:
#                 break
#         if matched_column:
#             cursor.execute(f'''
#                 UPDATE AccuracyCal
#                 SET {matched_column} = 'false', timestamp = ?
#                 WHERE invNumber = ?
#             ''', (timestamp, feedback.invNumber))

#             conn.commit()
            
#             if cursor.rowcount == 0:
#                 raise HTTPException(status_code=404, detail="invNumber not found.")

#             return {"message": f"Column '{matched_column}' updated successfully.", "timestamp": timestamp}
#         else:
#             raise HTTPException(status_code=400, detail="No column matches the feedback.")

#     except sqlite3.Error as e:
#         raise HTTPException(status_code=500, detail=f"Database error: {e}")
#     finally:
#         conn.close()

@app.post("/feedback")
async def submit_feedback(feedback: Feedback):
    try:
        timestamp = datetime.now().strftime('%d-%m-%Y')
        conn = get_db_connection()
        cursor = conn.cursor()

        feedback_lower = feedback.type_status.lower()
        print("ffffffffffffffffffffffffffffffff",feedback_lower)
        
        if feedback_lower == 'like':
            print("******************************************",feedback_lower)
            cursor.execute('''
                INSERT INTO feedback (feedback, feedback_status, timestamp)
                VALUES (?, ?, ?)
            ''', (feedback.feedback, feedback_lower, timestamp))
            
            conn.commit()
            return {"message": "Feedback saved successfully.", "status": "like", "timestamp": timestamp}
        
        elif feedback_lower == "dislike" :
            print("******************************************",feedback_lower)
            
            # Update the AccuracyCal table
            cursor.execute("PRAGMA table_info(AccuracyCal)")
            columns = [col[1] for col in cursor.fetchall()]
            matched_column = None
            feedback_words = feedback.feedback.split()

            # Identify the matched column based on feedback words
            for word in feedback_words:
                for column in columns:
                    if word.lower() in column.lower():
                        matched_column = column
                        print("matched_column matched_column ",matched_column)
                        break
                if matched_column:
                    break

            if matched_column:
                # Update the matched column and feedback_status in the AccuracyCal table
                cursor.execute(f'''
                    UPDATE AccuracyCal
                    SET {matched_column} = 'false', feedback_status = 'false', timestamp = ?
                    WHERE invNumber = ?
                ''', (timestamp, feedback.invNumber))
                conn.commit()
                
                
                

                if cursor.rowcount == 0:
                    raise HTTPException(status_code=404, detail="invNumber not found.")
                
                
                cursor.execute('''
                    INSERT INTO feedback (feedback, feedback_status, timestamp)
                    VALUES (?, ?, ?)
                ''', (feedback.feedback, feedback_lower, timestamp))
                
                conn.commit()

                return {
                    "message": f"Column '{matched_column}' and 'feedback_status' updated successfully.",
                    "status": "dislike",
                    "timestamp": timestamp
                }
            else:
                raise HTTPException(status_code=400, detail="No column matches the feedback.")
            
        else:
            raise HTTPException(status_code=400, detail="Feedback must include 'like' or 'dislike'.")
    
    except sqlite3.Error as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    finally:
        conn.close()



@app.get("/get_llm_response_by_inv")
def get_llm_response_by_inv(invNumber: str):
    try:
        conn = get_db_connection()
        
        cursor = conn.cursor()
        cursor.execute('''
        SELECT c.invNumber, c.product, c.complaintDescription, c.argusNarrative, c.dateEventOccurred,
               c.expirationDate, c.additionalInfo, c.timestamp AS query_timestamp,
               l.llm_response, l.timestamp AS llm_timestamp
        FROM chatboxquerytable c
        LEFT JOIN llm_responses l ON c.invNumber = l.invNumber
        WHERE c.invNumber = ?
        ''', (invNumber,))
        
        row = cursor.fetchone()

        if row is None:
            raise HTTPException(status_code=404, detail="Data not found for the provided invNumber")

        llm_response = json.loads(row['llm_response']) if row['llm_response'] else None

        response_data = {
            "invNumber": row["invNumber"],
            "product": row["product"],
            "complaintDescription": row["complaintDescription"],
            "argusNarrative": row["argusNarrative"],
            "dateEventOccurred": row["dateEventOccurred"],
            "expirationDate": row["expirationDate"],
            "additionalInfo": row["additionalInfo"],
            "query_timestamp": row["query_timestamp"],
            "llm_response": llm_response,
            "llm_timestamp": row["llm_timestamp"]
        }

        return response_data
    
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()



@app.get("/get_llm_response_history")
def get_all_llm_responses():
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row 
        
        cursor = conn.cursor()
        cursor.execute('''SELECT * FROM llm_responses''')
        
        rows = cursor.fetchall()

        if not rows:
            raise HTTPException(status_code=404, detail="No LLM responses found")

        llm_responses = []
        for row in rows:
            llm_response = json.loads(row['llm_response'])
            llm_responses.append({
                "invNumber": row['invNumber'],
                "llm_response": llm_response,
                "timestamp": row['timestamp']
            })

        return {"llm_responses": llm_responses}
    
    except Exception as e:
        logging.error(f"Error fetching LLM responses: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    finally:
        conn.close()

@app.get("/get_accuracy_by_date_range_complaint_issue")
def get_complaint_issue_ratio_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute(''' 
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? 
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute(''' 
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? AND product = ? 
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        # If no data is found, return 0% for all days
        if not rows:
            return {day: "0.00%,0" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_complaint_true_count = defaultdict(int)
        day_complaint_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[4]  # timestamp column index in your query
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')  # Adjust format to match the database
                day_of_week = timestamp_obj.strftime('%a')  # Get abbreviated day name (Mon, Tue, etc.)
                
                if row[2].lower() == 'true':
                    day_complaint_true_count[day_of_week] += 1
                day_complaint_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_complaints = day_complaint_total_count[day]
            if total_complaints > 0:
                complaint_issue_ratio = (day_complaint_true_count[day] / total_complaints) * 100
                result[day] = f"{complaint_issue_ratio:.2f}% ,{total_complaints}"
            else:
                result[day] = "0.00% ,0"  # Return 0% if no data for the day

        return result
    
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()

@app.get("/get_conclusion_accuracy_by_date_range")
def get_conclusion_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            return {day: "0.00% ,0" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_conclusion_true_count = defaultdict(int)
        day_conclusion_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[5]  
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a') 
                
                if row[1].lower() == 'true':  
                    day_conclusion_true_count[day_of_week] += 1
                day_conclusion_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_conclusions = day_conclusion_total_count[day]
            if total_conclusions > 0:
                conclusion_accuracy_ratio = (day_conclusion_true_count[day] / total_conclusions) * 100
                result[day] = f"{conclusion_accuracy_ratio:.2f}%,{total_conclusions}"
            else:
                result[day] = "0.00% ,0 "

        return result

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()


@app.get("/get_hazard_mapping_accuracy_by_date_range")
def get_hazard_mapping_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            return {day: "0.00% ,0" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_hazard_true_count = defaultdict(int)
        day_hazard_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[5] 
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a') 
                
                if row[3].lower() == 'true':  
                    day_hazard_true_count[day_of_week] += 1
                day_hazard_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_hazard = day_hazard_total_count[day]
            if total_hazard > 0:
                hazard_accuracy_ratio = (day_hazard_true_count[day] / total_hazard) * 100
                result[day] = f"{hazard_accuracy_ratio:.2f}%,{total_hazard}"
            else:
                result[day] = "0.00%,0"

        return result

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()

 
@app.get("/get_overall_accuracy_by_date_range")
def get_overall_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        # if product == "all":
        #     cursor.execute('''
        #     SELECT invNumber, conclusion, feedback_status, hazard_analysis, accuracy, timestamp, product
        #     FROM AccuracyCal
        #     WHERE timestamp BETWEEN ? AND ?
        #     ''', (start_date_str, end_date_str))
        # else:
        #     cursor.execute('''
        #     SELECT invNumber, conclusion, feedback_status, hazard_analysis, accuracy, timestamp, product
        #     FROM AccuracyCal
        #     WHERE timestamp BETWEEN ? AND ? AND product = ?
        #     ''', (start_date_str, end_date_str, product))
            
            
        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, feedback_status, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, feedback_status, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))
 
        rows = cursor.fetchall()
 
        if not rows:
            return {day: "0.00%,0" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
       
        logging.debug(f"Fetched rows: {rows}")
 
        day_hazard_true_count = defaultdict(int)
        day_hazard_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
 
        for row in rows:
            timestamp = row[5]
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a')
               
                if row[3].lower() == 'true':  
                    day_hazard_true_count[day_of_week] += 1
                day_hazard_total_count[day_of_week] += 1
 
            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")
 
        result = {}
        for day in all_days:
            total_hazard = day_hazard_total_count[day]
            if total_hazard > 0:
                hazard_accuracy_ratio = (day_hazard_true_count[day] / total_hazard) * 100
                result[day] = f"{hazard_accuracy_ratio:.2f}% ,{total_hazard}"
            else:
                result[day] = "0.00% ,0"
 
        return result
 
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()
         
@app.get("/get_accuracy_metrics")
def get_accuracy_metrics(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute('''
            SELECT feedback_status, complaint_issue, hazard_analysis, conclusion, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
            print("8888888888888888888888888888888")
        else:
            cursor.execute('''
            SELECT feedback_status, complaint_issue, hazard_analysis, conclusion, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            metrics = [
                {'title': 'Overall Prediction Accuracy', 'value': '0%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Overall accuracy based on Complaint issues, Hazard Mapping, and Conclusion Accuracy factors'},
                {'title': 'Overall Complaint Issue Accuracy', 'value': '0%', 'change': '+18% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Complaint Issue based accuracy performance'},
                {'title': 'Overall Hazard Mapping Accuracy', 'value': '0%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Hazard Mapping based accuracy performance'},
                {'title': 'Overall Conclusion Accuracy', 'value': '0%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Overall Conclusion accuracy'},
            ]
            return metrics

        total_count = len(rows)
        feedback_status_sum = sum(1 for row in rows if row[0] == 'true')
        complaint_issue_sum = sum(1 for row in rows if row[1] == 'true')
        hazard_analysis_sum = sum(1 for row in rows if row[2] == 'true')
        conclusion_sum = sum(1 for row in rows if row[3] == 'true')

        overall_accuracy = (feedback_status_sum / total_count) * 100 if total_count > 0 else 0
        complaint_issue_accuracy = (complaint_issue_sum / total_count) * 100 if total_count > 0 else 0
        hazard_mapping_accuracy = (hazard_analysis_sum / total_count) * 100 if total_count > 0 else 0
        conclusion_accuracy = (conclusion_sum / total_count) * 100 if total_count > 0 else 0
        print("overall_accuracy",overall_accuracy)
        print("complaint_issue_accuracy",complaint_issue_accuracy)
        print("hazard_mapping_accuracy",hazard_mapping_accuracy)
        print("conclusion_accuracy",conclusion_accuracy)
        
        metrics = [
            {'title': 'Overall Prediction Accuracy', 'value': f'{overall_accuracy:.2f}%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Overall accuracy based on Complaint issues, Hazard Mapping and Conclusion Accuracy factors'},
            {'title': 'Overall Complaint Issue Accuracy', 'value': f'{complaint_issue_accuracy:.2f}%', 'change': '+18% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Complaint Issue based accuracy performance'},
            {'title': 'Overall Hazard Mapping Accuracy', 'value': f'{hazard_mapping_accuracy:.2f}%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Hazard Mapping based accuracy performance'},
            {'title': 'Overall Conclusion Accuracy', 'value': f'{conclusion_accuracy:.2f}%', 'change': '+21% increased since last week', 'changeClass': 'text-success text-start', 'icon': 'target', 'tooltip': 'Weekly Overall Conclusion accuracy'},
        ]

        return metrics

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

    finally:
        conn.close()


@app.get("/download")
async def download_file():
    # Define the path of the file
    folder_path = os.path.join("python_api", "dependencies")
    db_path = os.path.join(folder_path, "chatbox.db")

    # Check if the file exists
    if os.path.exists(db_path):
        return FileResponse(db_path, media_type='application/octet-stream', filename="chatbox.db")
    else:
        return {"error": "File not found"}