

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import time
import logging
import os
import sys
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dependencies.config import *
from dependencies.bucket_sessions import get_presigned_url
from dependencies.generate_token import federate_auth
from dependencies.chunking_embedding import ingest_document
from dependencies.check_status import get_status
from dependencies.get_response import search
from dependencies.prompts import prompt_template
from pydantic import BaseModel
import json
import sqlite3
from datetime import datetime
from datetime import datetime
from typing import Any, Dict
import logging
from collections import defaultdict
import json
import re
import os
from difflib import SequenceMatcher
from dependencies.db import * 
import re
from typing import Any, Dict, List

create_feedback_table()
 
 
app = FastAPI()
 
 
class LLMRequest(BaseModel):
    invNumber: str
    product: str
    complaintDescription: str
    argusNarrative: str
    dateEventOccurred: str
    expirationDate: str = "NA"
    additionalInfo: str = "NA"
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows the frontend to connect
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)


# Setup logging
logging.basicConfig(level=logging.INFO)


base_dir = os.path.dirname(__file__)
file_name = os.path.join(base_dir, "New_Master_Data_MDCP.csv")
print("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",file_name)
file_path = os.path.join(base_dir, file_name)
print("********************************************************************",file_path)

presigned_url = get_presigned_url(file_name, bucket)
 
token = federate_auth()



ingest_document_response = ingest_document(presigned_url, token)
request_id = ingest_document_response["requestID"]

logging.info("Waiting for ingestion to complete...")
while get_status(request_id, token)['status']!= 'Completed':
    ingestion_status = get_status(request_id, token)
    time.sleep(1)

document_md5 = ingestion_status['document_md5']

def convert_to_snake_case(data: Any) -> Any:
    """Convert keys of a dictionary or list of dictionaries to snake_case recursively."""
    def to_snake_case(key: str) -> str:
        key = re.sub(r'[^a-zA-Z0-9]', '_', key)  # Replace non-alphanumeric characters with underscores
        key = re.sub(r'_+', '_', key)  # Replace multiple underscores with a single underscore
        key = key.strip('_')  # Remove leading/trailing underscores
        key = key.lower()  # Convert to lowercase
        return key

    if isinstance(data, dict):
        return {
            to_snake_case(key): convert_to_snake_case(value) for key, value in data.items()
        }
    elif isinstance(data, list):
        return [convert_to_snake_case(item) for item in data]
    else:
        return data


def process_ingestion():
    try:
        logging.info("Ingesting document...")
        ingest_document_response = ingest_document(presigned_url, token)
        request_id = ingest_document_response["requestID"]
       
        logging.info("Waiting for ingestion to complete...")
        while True:
            ingestion_status = get_status(request_id, token)
            if ingestion_status['status'] == 'Completed':
                logging.info("Ingestion completed.")
                return ingestion_status['document_md5']
            time.sleep(1)
       
    except Exception as e:
        logging.error(f"Error during ingestion process: {e}")
        raise HTTPException(status_code=500, detail="Error during ingestion process")
   
 
@app.post("/get_llm_response")
def read_llm_response(request: LLMRequest):
    try:
        invNumber = getattr(request, 'invNumber', "NA")
        product = getattr(request, 'product', "NA")
        complaintDescription = getattr(request, 'complaintDescription', "NA")
        argusNarrative = getattr(request, 'argusNarrative', "NA")
        dateEventOccurred = getattr(request, 'dateEventOccurred', "NA")
        expirationDate = getattr(request, 'expirationDate', "NA")
        additionalInfo = getattr(request, 'additionalInfo', "NA")

        save_to_chatbox_query_table(request.dict())
        logging.info(f"Received data: {request.dict()} ")


        
              # Validate and process expiration date
        today_date = datetime.now().date()  # Automatically gets today's date
        if expirationDate != "NA":
            try:
                exp_date = datetime.strptime(expirationDate, '%Y-%m-%d').date()
                if exp_date < today_date:
                    logging.warning(f"Expiration date {expirationDate} has already passed.")
                elif exp_date == today_date:
                    logging.info(f"Expiration date {expirationDate} is today.")
                else:
                    logging.info(f"Expiration date {expirationDate} is valid and in the future.")
            except ValueError:
                logging.error(f"Invalid format for expiration date: {expirationDate}")
                expirationDate = "Invalid Format"
        else:
            logging.info("Expiration date not provided.")


        print("expirationDate      ",expirationDate)
        

        prompt = prompt_template(invNumber, product, complaintDescription, argusNarrative, dateEventOccurred, expirationDate, additionalInfo)
        
        # document_md5 = process_ingestion()  # Ensure this function is working
        search_response = search(prompt, token, document_md5)
        llm_response_raw = search_response.get('llm_response')
        if not llm_response_raw:
            raise ValueError("LLM response not found in the search response.")
        try:
            print("\n\n\n\n")
            print("llm_response_rawllm_response_rawllm_response_raw \n\n\n",llm_response_raw)
            print("\n\n\n\n")
            llm_response = json.loads(llm_response_raw.strip("```json\n").strip("\n```"))
            print("llm_responsellm_responsellm_response \n\n\n",llm_response)
            print("llm_responsellm_responsellm_responsellm_response \n\n\n\n",llm_response)
            llm_response_snake_case = convert_to_snake_case(llm_response)
            print("llm_response_snake_casellm_response_snake_casellm_response_snake_casellm_response_snake_casellm_response_snake_case \n\n\n",llm_response_snake_case)
            save_llm_response_to_db(invNumber, llm_response_snake_case)
            save_accuracy_cal_to_db(invNumber,product)
        except json.JSONDecodeError as e:
            logging.error(f"Error parsing LLM response JSON: {e}")
            raise HTTPException(status_code=500, detail="Error parsing LLM response JSON.")
        return {"llm_response": llm_response_snake_case}
    except Exception as e:
        logging.error(f"Error in processing LLM response: {e}")
        raise HTTPException(status_code=500, detail="Error in processing LLM response")



def save_accuracy_cal_to_db(inv_number,product):
    conn = sqlite3.connect('chatbox.db')
    cursor = conn.cursor()

    cursor.execute('''
    INSERT INTO AccuracyCal (
        invNumber,
        product,
        conclusion,
        complaint_issue,
        hazard_analysis,
        imdrf_code,
        capa_reference,
        actual_failure,
        accuracy,
        timestamp
    ) VALUES (?, ?,?, ?, ?, ?, ?, ?, ?, strftime('%d-%m-%Y', 'now'))
    ''', (
        inv_number,
        product,
        'true',
        'true',
        'true',
        'true',
        'true',
        'true',
        'true',
    ))

    conn.commit()
    conn.close()


class Feedback(BaseModel):
    feedback: str
    invNumber: str
    timestamp: str


def get_db_connection():
    conn = sqlite3.connect('chatbox.db')
    conn.row_factory = sqlite3.Row 
    return conn
 
 
 
 
def save_to_chatbox_query_table(request_data: dict):
    timestamp = datetime.now().isoformat()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO chatboxquerytable (invNumber, product, complaintDescription, argusNarrative,
                                   dateEventOccurred, expirationDate, additionalInfo, timestamp)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (request_data['invNumber'], request_data['product'], request_data['complaintDescription'],
          request_data['argusNarrative'], request_data['dateEventOccurred'], request_data['expirationDate'],
          request_data['additionalInfo'], timestamp))
    conn.commit()
    conn.close()
 
# Save the LLM response to llm_responses
def save_llm_response_to_db(invNumber: str, llm_response: dict):
    timestamp = datetime.now().isoformat()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO llm_responses (invNumber, llm_response, timestamp)
    VALUES (?, ?, ?)
    ''', (invNumber, json.dumps(llm_response), timestamp))
    conn.commit()
    conn.close()
 
@app.post("/feedback")
async def submit_feedback(feedback: Feedback):
    try:
        timestamp = datetime.now().strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("PRAGMA table_info(AccuracyCal)")
        columns = [col[1] for col in cursor.fetchall()]

        matched_column = None
        feedback_words = feedback.feedback.split() 

        for word in feedback_words:
            for column in columns:
                if word.lower() in column.lower():  
                    matched_column = column
                    break
            if matched_column:
                break
        if matched_column:
            cursor.execute(f'''
                UPDATE AccuracyCal
                SET {matched_column} = 'false', timestamp = ?
                WHERE invNumber = ?
            ''', (timestamp, feedback.invNumber))

            conn.commit()
            
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="invNumber not found.")

            return {"message": f"Column '{matched_column}' updated successfully.", "timestamp": timestamp}
        else:
            raise HTTPException(status_code=400, detail="No column matches the feedback.")

    except sqlite3.Error as e:
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    finally:
        conn.close()
@app.get("/get_llm_response_by_inv")
def get_llm_response_by_inv(invNumber: str):
    try:
        conn = get_db_connection()
        
        cursor = conn.cursor()
        cursor.execute('''
        SELECT c.invNumber, c.product, c.complaintDescription, c.argusNarrative, c.dateEventOccurred,
               c.expirationDate, c.additionalInfo, c.timestamp AS query_timestamp,
               l.llm_response, l.timestamp AS llm_timestamp
        FROM chatboxquerytable c
        LEFT JOIN llm_responses l ON c.invNumber = l.invNumber
        WHERE c.invNumber = ?
        ''', (invNumber,))
        
        row = cursor.fetchone()

        if row is None:
            raise HTTPException(status_code=404, detail="Data not found for the provided invNumber")

        llm_response = json.loads(row['llm_response']) if row['llm_response'] else None

        response_data = {
            "invNumber": row["invNumber"],
            "product": row["product"],
            "complaintDescription": row["complaintDescription"],
            "argusNarrative": row["argusNarrative"],
            "dateEventOccurred": row["dateEventOccurred"],
            "expirationDate": row["expirationDate"],
            "additionalInfo": row["additionalInfo"],
            "query_timestamp": row["query_timestamp"],
            "llm_response": llm_response,
            "llm_timestamp": row["llm_timestamp"]
        }

        return response_data
    
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()



@app.get("/get_llm_response_history")
def get_all_llm_responses():
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row 
        
        cursor = conn.cursor()
        cursor.execute('''SELECT * FROM llm_responses''')
        
        rows = cursor.fetchall()

        if not rows:
            raise HTTPException(status_code=404, detail="No LLM responses found")

        llm_responses = []
        for row in rows:
            llm_response = json.loads(row['llm_response'])
            llm_responses.append({
                "invNumber": row['invNumber'],
                "llm_response": llm_response,
                "timestamp": row['timestamp']
            })

        return {"llm_responses": llm_responses}
    
    except Exception as e:
        logging.error(f"Error fetching LLM responses: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    finally:
        conn.close()

@app.get("/get_accuracy_by_date_range_complaint_issue")
def get_complaint_issue_ratio_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute(''' 
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? 
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute(''' 
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? AND product = ? 
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        # If no data is found, return 0% for all days
        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_complaint_true_count = defaultdict(int)
        day_complaint_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[4]  # timestamp column index in your query
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')  # Adjust format to match the database
                day_of_week = timestamp_obj.strftime('%a')  # Get abbreviated day name (Mon, Tue, etc.)
                
                if row[2].lower() == 'true':
                    day_complaint_true_count[day_of_week] += 1
                day_complaint_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_complaints = day_complaint_total_count[day]
            if total_complaints > 0:
                complaint_issue_ratio = (day_complaint_true_count[day] / total_complaints) * 100
                result[day] = f"{complaint_issue_ratio:.2f}%"
            else:
                result[day] = "0.00%"  # Return 0% if no data for the day

        return result
    
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()

@app.get("/get_conclusion_accuracy_by_date_range")
def get_conclusion_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_conclusion_true_count = defaultdict(int)
        day_conclusion_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[5]  
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a') 
                
                if row[1].lower() == 'true':  
                    day_conclusion_true_count[day_of_week] += 1
                day_conclusion_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_conclusions = day_conclusion_total_count[day]
            if total_conclusions > 0:
                conclusion_accuracy_ratio = (day_conclusion_true_count[day] / total_conclusions) * 100
                result[day] = f"{conclusion_accuracy_ratio:.2f}%"
            else:
                result[day] = "0.00%"

        return result

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()


@app.get("/get_hazard_mapping_accuracy_by_date_range")
def get_hazard_mapping_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
        
        logging.debug(f"Fetched rows: {rows}")

        day_hazard_true_count = defaultdict(int)
        day_hazard_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            timestamp = row[5] 
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a') 
                
                if row[3].lower() == 'true':  
                    day_hazard_true_count[day_of_week] += 1
                day_hazard_total_count[day_of_week] += 1

            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_hazard = day_hazard_total_count[day]
            if total_hazard > 0:
                hazard_accuracy_ratio = (day_hazard_true_count[day] / total_hazard) * 100
                result[day] = f"{hazard_accuracy_ratio:.2f}%"
            else:
                result[day] = "0.00%"

        return result

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()



@app.get("/get_overall_accuracy_by_date_range")
def get_overall_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        if product == "all":
            cursor.execute(''' 
            SELECT accuracy, timestamp, complaint_issue 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? 
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT accuracy, timestamp, complaint_issue 
            FROM AccuracyCal 
            WHERE timestamp BETWEEN ? AND ? AND product = ? 
            ''', (start_date_str, end_date_str, product))

        rows = cursor.fetchall()

        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}

        day_true_sum = defaultdict(int)
        day_total_sum = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        for row in rows:
            try:
                accuracy_str = row[0]
                try:
                    accuracy = float(accuracy_str) 
                except ValueError:
                    logging.error(f"Invalid accuracy value: {accuracy_str}. Skipping this row.")
                    continue  
                
                timestamp = row[1]
                complaint_issue = row[2].strip().lower()

                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a')

                true_value = 1 if complaint_issue == 'true' else 0
                total_value = 1 

                day_true_sum[day_of_week] += true_value
                day_total_sum[day_of_week] += total_value

            except ValueError as e:
                logging.error(f"Error processing row: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")

        result = {}
        for day in all_days:
            total_count = day_total_sum[day]
            true_count = day_true_sum[day]

            if total_count > 0:
                complaint_issue_ratio = (true_count / total_count) * 100
                result[day] = f"{complaint_issue_ratio:.2f}%"
            else:
                result[day] = "0.00%"  

        return result

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()



@app.get("/get_accuracy_metrics")
def get_accuracy_metrics(start_date: str, end_date: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')

        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(''' 
        SELECT accuracy, complaint_issue, hazard_analysis, conclusion, timestamp 
        FROM AccuracyCal 
        WHERE timestamp BETWEEN ? AND ? 
        ''', (start_date_str, end_date_str))

        rows = cursor.fetchall()

        if not rows:
            raise HTTPException(status_code=404, detail="No data found for the given parameters.")
        
        total_accuracy_sum = 0
        complaint_issue_sum = 0
        hazard_analysis_sum = 0
        conclusion_sum = 0
        total_count = len(rows)

        for row in rows:
            accuracy = row[0]

            # Check if accuracy is a string and contains '%'
            if isinstance(accuracy, str):
                try:
                    accuracy_value = float(accuracy.replace('%', '').strip())
                except ValueError:
                    accuracy_value = 0
            else:
                accuracy_value = float(accuracy)  # If it's already a float, just convert it

            complaint_issue = row[1] == 'true'
            hazard_analysis = row[2] == 'true'
            conclusion = row[3] == 'true'

            total_accuracy_sum += accuracy_value
            complaint_issue_sum += int(complaint_issue)  # Ensure it's an integer
            hazard_analysis_sum += int(hazard_analysis)  # Ensure it's an integer
            conclusion_sum += int(conclusion)  # Ensure it's an integer
        
        overall_accuracy = (total_accuracy_sum / total_count) if total_count > 0 else 0
        complaint_issue_accuracy = (complaint_issue_sum / total_count) * 100 if total_count > 0 else 0
        hazard_mapping_accuracy = (hazard_analysis_sum / total_count) * 100 if total_count > 0 else 0
        conclusion_accuracy = (conclusion_sum / total_count) * 100 if total_count > 0 else 0

        metrics = [
            {
                'title': 'Overall Prediction Accuracy',
                'value': f'{overall_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Overall accuracy based on Complaint issues, Hazard Mapping and Conclusion Accuracy factors'
            },
            {
                'title': 'Overall Complaint Issue Accuracy',
                'value': f'{complaint_issue_accuracy:.2f}%',
                'change': '+18% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Complaint Issue based accuracy performance'
            },
            {
                'title': 'Overall Hazard Mapping Accuracy',
                'value': f'{hazard_mapping_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Hazard Mapping based accuracy performance'
            },
            {
                'title': 'Overall Conclusion Accuracy',
                'value': f'{conclusion_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Overall Conclusion accuracy'
            },
        ]

        return metrics

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
    
    finally:
        conn.close()
 
@app.get("/get_accuracy_by_date_range_complaint_issue")
def get_complaint_issue_ratio_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))
 
        rows = cursor.fetchall()
 
        # If no data is found, return 0% for all days
        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
       
        logging.debug(f"Fetched rows: {rows}")
 
        day_complaint_true_count = defaultdict(int)
        day_complaint_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
 
        for row in rows:
            timestamp = row[4]  # timestamp column index in your query
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')  # Adjust format to match the database
                day_of_week = timestamp_obj.strftime('%a')  # Get abbreviated day name (Mon, Tue, etc.)
               
                if row[2].lower() == 'true':
                    day_complaint_true_count[day_of_week] += 1
                day_complaint_total_count[day_of_week] += 1
 
            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")
 
        result = {}
        for day in all_days:
            total_complaints = day_complaint_total_count[day]
            if total_complaints > 0:
                complaint_issue_ratio = (day_complaint_true_count[day] / total_complaints) * 100
                result[day] = f"{complaint_issue_ratio:.2f}%"
            else:
                result[day] = "0.00%"  # Return 0% if no data for the day
 
        return result
   
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()
 
@app.get("/get_conclusion_accuracy_by_date_range")
def get_conclusion_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))
 
        rows = cursor.fetchall()
 
        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
       
        logging.debug(f"Fetched rows: {rows}")
 
        day_conclusion_true_count = defaultdict(int)
        day_conclusion_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
 
        for row in rows:
            timestamp = row[5]  
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a')
               
                if row[1].lower() == 'true':  
                    day_conclusion_true_count[day_of_week] += 1
                day_conclusion_total_count[day_of_week] += 1
 
            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")
 
        result = {}
        for day in all_days:
            total_conclusions = day_conclusion_total_count[day]
            if total_conclusions > 0:
                conclusion_accuracy_ratio = (day_conclusion_true_count[day] / total_conclusions) * 100
                result[day] = f"{conclusion_accuracy_ratio:.2f}%"
            else:
                result[day] = "0.00%"
 
        return result
 
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()
 
 
@app.get("/get_hazard_mapping_accuracy_by_date_range")
def get_hazard_mapping_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        if product == "all":
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT invNumber, conclusion, complaint_issue, hazard_analysis, accuracy, timestamp, product
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))
 
        rows = cursor.fetchall()
 
        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
       
        logging.debug(f"Fetched rows: {rows}")
 
        day_hazard_true_count = defaultdict(int)
        day_hazard_total_count = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
 
        for row in rows:
            timestamp = row[5]
            try:
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a')
               
                if row[3].lower() == 'true':  
                    day_hazard_true_count[day_of_week] += 1
                day_hazard_total_count[day_of_week] += 1
 
            except Exception as e:
                logging.error(f"Error parsing timestamp {timestamp}: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")
 
        result = {}
        for day in all_days:
            total_hazard = day_hazard_total_count[day]
            if total_hazard > 0:
                hazard_accuracy_ratio = (day_hazard_true_count[day] / total_hazard) * 100
                result[day] = f"{hazard_accuracy_ratio:.2f}%"
            else:
                result[day] = "0.00%"
 
        return result
 
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()
 
 
 
@app.get("/get_overall_accuracy_by_date_range")
def get_overall_accuracy_by_date_range(start_date: str, end_date: str, product: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        if product == "all":
            cursor.execute('''
            SELECT accuracy, timestamp, complaint_issue
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ?
            ''', (start_date_str, end_date_str))
        else:
            cursor.execute('''
            SELECT accuracy, timestamp, complaint_issue
            FROM AccuracyCal
            WHERE timestamp BETWEEN ? AND ? AND product = ?
            ''', (start_date_str, end_date_str, product))
 
        rows = cursor.fetchall()
 
        if not rows:
            return {day: "0.00%" for day in ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']}
 
        day_true_sum = defaultdict(int)
        day_total_sum = defaultdict(int)
        all_days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
 
        for row in rows:
            try:
                accuracy_str = row[0]
                try:
                    accuracy = float(accuracy_str)
                except ValueError:
                    logging.error(f"Invalid accuracy value: {accuracy_str}. Skipping this row.")
                    continue  
               
                timestamp = row[1]
                complaint_issue = row[2].strip().lower()
 
                timestamp_obj = datetime.strptime(timestamp, '%d-%m-%Y')
                day_of_week = timestamp_obj.strftime('%a')
 
                true_value = 1 if complaint_issue == 'true' else 0
                total_value = 1
 
                day_true_sum[day_of_week] += true_value
                day_total_sum[day_of_week] += total_value
 
            except ValueError as e:
                logging.error(f"Error processing row: {e}")
                raise HTTPException(status_code=500, detail="Internal Server Error")
 
        result = {}
        for day in all_days:
            total_count = day_total_sum[day]
            true_count = day_true_sum[day]
 
            if total_count > 0:
                complaint_issue_ratio = (true_count / total_count) * 100
                result[day] = f"{complaint_issue_ratio:.2f}%"
            else:
                result[day] = "0.00%"  
 
        return result
 
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()
 
 
 
@app.get("/get_accuracy_metrics")
def get_accuracy_metrics(start_date: str, end_date: str):
    try:
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
 
        start_date_str = start_date_obj.strftime('%d-%m-%Y')
        end_date_str = end_date_obj.strftime('%d-%m-%Y')
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        cursor.execute('''
        SELECT accuracy, complaint_issue, hazard_analysis, conclusion, timestamp
        FROM AccuracyCal
        WHERE timestamp BETWEEN ? AND ?
        ''', (start_date_str, end_date_str))
 
        rows = cursor.fetchall()
 
        if not rows:
            raise HTTPException(status_code=404, detail="No data found for the given parameters.")
       
        total_accuracy_sum = 0
        complaint_issue_sum = 0
        hazard_analysis_sum = 0
        conclusion_sum = 0
        total_count = len(rows)
 
        for row in rows:
            accuracy = row[0]
 
            # Check if accuracy is a string and contains '%'
            if isinstance(accuracy, str):
                try:
                    accuracy_value = float(accuracy.replace('%', '').strip())
                except ValueError:
                    accuracy_value = 0
            else:
                accuracy_value = float(accuracy)  # If it's already a float, just convert it
 
            complaint_issue = row[1] == 'true'
            hazard_analysis = row[2] == 'true'
            conclusion = row[3] == 'true'
 
            total_accuracy_sum += accuracy_value
            complaint_issue_sum += int(complaint_issue)  # Ensure it's an integer
            hazard_analysis_sum += int(hazard_analysis)  # Ensure it's an integer
            conclusion_sum += int(conclusion)  # Ensure it's an integer
       
        overall_accuracy = (total_accuracy_sum / total_count) if total_count > 0 else 0
        complaint_issue_accuracy = (complaint_issue_sum / total_count) * 100 if total_count > 0 else 0
        hazard_mapping_accuracy = (hazard_analysis_sum / total_count) * 100 if total_count > 0 else 0
        conclusion_accuracy = (conclusion_sum / total_count) * 100 if total_count > 0 else 0
 
        metrics = [
            {
                'title': 'Overall Prediction Accuracy',
                'value': f'{overall_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Overall accuracy based on Complaint issues, Hazard Mapping and Conclusion Accuracy factors'
            },
            {
                'title': 'Overall Complaint Issue Accuracy',
                'value': f'{complaint_issue_accuracy:.2f}%',
                'change': '+18% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Complaint Issue based accuracy performance'
            },
            {
                'title': 'Overall Hazard Mapping Accuracy',
                'value': f'{hazard_mapping_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Hazard Mapping based accuracy performance'
            },
            {
                'title': 'Overall Conclusion Accuracy',
                'value': f'{conclusion_accuracy:.2f}%',
                'change': '+21% increased since last week',
                'changeClass': 'text-success text-start',
                'icon': 'target',
                'tooltip': 'Weekly Overall Conclusion accuracy'
            },
        ]
 
        return metrics
 
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
   
    finally:
        conn.close()