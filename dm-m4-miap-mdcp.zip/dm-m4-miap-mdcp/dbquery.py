import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('chatbox.db')
cursor = conn.cursor()

# # Fetch all queries from the chatboxquerytable
# # cursor.execute("SELECT * FROM chatboxquerytable")
# # rows = cursor.fetchall()
# # print("Chatbox Queries:")
# # for row in rows:
# #     print(row)

# Fetch all LLM responses using invNumber
# cursor.execute("SELECT * FROM feedback")
# rows = cursor.fetchall()
# print("feedback status:")
# for row in rows:
#     print(row)



cursor.execute("SELECT * FROM AccuracyCal")
rows = cursor.fetchall()
print("AccuracyCal Responses:")
for row in rows:
    print(row)

# conn.close()