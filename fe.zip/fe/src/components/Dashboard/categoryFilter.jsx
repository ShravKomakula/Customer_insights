import React, { useState, memo, useRef, useEffect } from 'react';
import Select, { components } from 'react-select';
import './FilterBar.css'; // Import custom styles here
import axios from 'axios';
const FilterBar = memo(({
  selectedCountry,
  onCountryChange,
  specialtyOptions = [],
  cityOptions = [],
  hcpSegmentOptions = [],
  onSearch,
  cities,
  specialities,
  segments,
  loading
}) => {
  const countryOptions = [
    { value: 'MX', label: 'Mexico' },
    { value: 'BR', label: 'Brazil' },
  ];
  const [specialtyLoading, setSpecialtyLoading] = useState(false);
  const [cityLoading, setCityLoading] = useState(false);
  const [segmentLoading, setSegmentLoading] = useState(false);
  const [specialtyCount, setspecialtyCount] = useState(specialities.length);
  const [cityCount, setCityCount] = useState(cities.length);
  const [segmentCount, setSegmentCount] = useState(segments.length);
  const [selectedSpecialities, setSelectedSpecialities] = useState(
    specialities.map((s) => ({ value: s, label: s })) || []
  );
  const [selectedCities, setSelectedCities] = useState(
    cities.map((c) => ({ value: c, label: c })) || []
  );
  const [selectedSegments, setSelectedSegments] = useState(
    segments.map((seg) => ({ value: seg || 'Others', label: seg || 'Others' })) || []
  );
  const [hcpSegments, setHcpSegments] = useState([]);
  const [specialties, setSpecialties] = useState([]);
  const [city, setCitys] = useState([]);
  const [showClicked, setShowClicked] = useState(false);
  const [menuIsOpen, setMenuIsOpen] = useState({
    specialty: false,
    city: false,
    segment: false,
  });

  const [disabledDropdowns, setDisabledDropdowns] = useState({
    specialty: false,
    city: false,
    segment: false,
  });

  const filterBarRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (filterBarRef.current && !filterBarRef.current.contains(event.target)) {
        setMenuIsOpen({ specialty: false, city: false, segment: false });
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, []);

  const countryCodes = {
    Mexico: 'MX',
    Brazil: 'BR',
  };

  const fetchIncrementalSearchData = async () => {
    const countryCode = countryCodes[selectedCountry?.value] || selectedCountry?.value;
    const cityInfo =
      cities.length > 0 && selectedCities.length === 0
        ? cities
        : selectedCities.map((c) => c.value);
    const payload = {
      country: countryCode,
      city: cityInfo,
      specialty: selectedSpecialities.map((s) => s.value),
      segment: selectedSegments.map((s) => s.value),
    };

    try {
      setSpecialtyLoading(true);
      const response = await axios.post('https://emcustomerinsights.pfizer.com/backend/service/incremental_search/', payload);
      const { specialties: fetchedSpecialties, cities: fetchedCities, segments: fetchedSegments } = response.data;

      setSpecialties(fetchedSpecialties.map((s) => ({ value: s, label: s })));
      setCitys(fetchedCities.map((c) => ({ value: c, label: c })));
      setHcpSegments(fetchedSegments.map((seg) => ({ value: seg || 'Others', label: seg || 'Others' })));
    } catch (error) {
      console.error('Error fetching incremental search data:', error);
    } finally {
      setSpecialtyLoading(false);
    }
  };

  const fetchIncrementalCitySearchData = async () => {
    const countryCode = countryCodes[selectedCountry?.value] || selectedCountry?.value;
    const specialityInfo =
      specialities.length > 0 && selectedSpecialities.length === 0
        ? specialities
        : selectedSpecialities.map((s) => s.value);

    const payload = {
      country: countryCode,
      city: selectedCities.map((c) => c.value),
      specialty: specialityInfo,
      segment: selectedSegments.map((s) => s.value),
    };

    try {
      setCityLoading(true);
      const response = await axios.post('https://emcustomerinsights.pfizer.com/backend/service/incremental_search/', payload);
      const { specialties: fetchedSpecialties, cities: fetchedCities, segments: fetchedSegments } = response.data;

      setSpecialties(fetchedSpecialties.map((s) => ({ value: s, label: s })));
      setCitys(fetchedCities.map((c) => ({ value: c, label: c })));
      setHcpSegments(fetchedSegments.map((seg) => ({ value: seg || 'Others', label: seg || 'Others' })));
    } catch (error) {
      console.error('Error fetching incremental search data:', error);
    } finally {
      setCityLoading(false);
    }
  };

  const fetchIncrementalSegmentSearchData = async () => {
    const countryCode = countryCodes[selectedCountry?.value] || selectedCountry?.value;
    const payload = {
      country: countryCode,
      city: selectedCities.map((c) => c.value),
      specialty: selectedSpecialities.map((s) => s.value),
      segment: selectedSegments.map((s) => s.value),
    };
  
    try {
      setSegmentLoading(true);
      const response = await axios.post('https://emcustomerinsights.pfizer.com/backend/service/incremental_search/', payload);
      const { specialties: fetchedSpecialties, cities: fetchedCities, segments: fetchedSegments } = response.data;
  
      // Filter segments to show only 'A' and 'B' if they exist
      const filteredSegments = fetchedSegments.filter((seg) => seg === 'A' || seg === 'B');
  
      setSpecialties(fetchedSpecialties.map((s) => ({ value: s, label: s })));
      setCitys(fetchedCities.map((c) => ({ value: c, label: c })));
      setHcpSegments(filteredSegments.map((seg) => ({ value: seg, label: seg })));
    } catch (error) {
      console.error('Error fetching incremental search data:', error);
    } finally {
      setSegmentLoading(false);
    }
  };
  

  const dropdownHcpSegmentOptions = hcpSegmentOptions
    .filter(segment => segment === 'A' || segment === 'B')
    .map(segment => ({ value: segment, label: segment }));

  const handleDropdownSelect = (type) => {
    // Disable other dropdowns when one is selected
    setDisabledDropdowns({
      specialty: type !== 'specialty',
      city: type !== 'city',
      segment: type !== 'segment',
    });
  };

  const handleShowClick = async (type, event) => {
    if (event) event.preventDefault();
    setMenuIsOpen((prev) => ({ ...prev, [type]: false }));

    setShowClicked(true);

    // Re-enable all dropdowns after clicking Show
    setDisabledDropdowns({ specialty: false, city: false, segment: false });

    const specialityInfo =
      specialities.length > 0 && selectedSpecialities.length === 0
        ? specialities
        : selectedSpecialities.map((s) => s.value);
    const cityInfo =
      cities.length > 0 && selectedCities.length === 0
        ? cities
        : selectedCities.map((c) => c.value);
        const segmentInfo =
        segments.length > 0 && selectedSegments.length === 0
          ? segments
          : selectedSegments.map((c) => c.value);

    const payload = {
      country: selectedCountry?.value?.toUpperCase() || '',
      specialty: specialityInfo,
      city: cityInfo,
      segment: segmentInfo,
    };

    try {
      await onSearch(payload);
      setCityCount(payload.city.length);
      setspecialtyCount(payload.specialty.length);
      setSegmentCount(payload.segment.length);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Failed to fetch data. Please try again.');
    }
  };

  const handleClearSelection = async (type, info) => {
    let updatedPayload = {};

    if (type === "specialty") {
      setSelectedSpecialities([]);
      setspecialtyCount(0);
      updatedPayload = {
        country: selectedCountry?.value?.toUpperCase() || "",
        specialty: [],
        city: selectedCities.map((c) => c.value),
        segment: selectedSegments.map((s) => s.value),
      };
    } else if (type === "city") {
      setSelectedCities([]);
      setCityCount(0);
      updatedPayload = {
        country: selectedCountry?.value?.toUpperCase() || "",
        specialty: selectedSpecialities.map((s) => s.value),
        city: [],
        segment: selectedSegments.map((s) => s.value),
      };
    } else if (type === "segment") {
      setSelectedSegments([]);
      setSegmentCount(0);
      updatedPayload = {
        country: selectedCountry?.value?.toUpperCase() || "",
        specialty: selectedSpecialities.map((s) => s.value),
        city: selectedCities.map((c) => c.value),
        segment: [],
      };
    }

    // Immediately call the API after clearing the dropdown
    try {
      await onSearch(updatedPayload);
    } catch (error) {
      console.error(`Error fetching data after clearing ${type}:`, error);
    }
  };

  const CustomValueContainer = ({ children, ...props }) => {
    const currentValues = props.getValue();
    const firstValue = currentValues[0]?.label || '';
    const remainingCount = currentValues.length - 1;

    return (
      <components.ValueContainer {...props}>
        {currentValues.length > 0 ? (
          <div>
            {firstValue}
            {remainingCount > 0 && `, ${remainingCount} more...`}
          </div>
        ) : (
          children
        )}
      </components.ValueContainer>
    );
  };

  const CustomMenuList = (props) => {
    const type = props.selectProps.name;
    return (
      <div>
        <components.MenuList {...props}>
          {props.children}
        </components.MenuList>
        <div
          className="dropdown-footer"
          style={{
            textAlign: 'center',
            padding: '10px',
            background: 'linear-gradient(to right, #4c6ef5, #3b5bdb)',
            color: '#fff',
            cursor: 'pointer',
          }}
          onClick={() => handleShowClick(type)}
        >
          Show {props.selectProps.value.length} selected
        </div>
      </div>
    );
  };

  const CustomCheckboxOption = (props) => {
    const { data, isSelected, innerRef, innerProps } = props;
  
    const handleCheckboxChange = (e) => {
      e.stopPropagation(); // Prevent default dropdown behavior
      const selectedOption = { value: data.value, label: data.label };
      if (isSelected) {
        // If already selected, remove it
        props.selectProps.onChange(
          props.selectProps.value.filter((option) => option.value !== data.value)
        );
      } else {
        // If not selected, add it
        props.selectProps.onChange([...props.selectProps.value, selectedOption]);
      }
    };
  
    return (
      <div
        ref={innerRef}
        {...innerProps}
        style={{
          display: 'flex',
          alignItems: 'center',
          padding: '5px',
          cursor: 'pointer',
        }}
      >
        <input
          type="checkbox"
          checked={isSelected}
          onChange={handleCheckboxChange}
          style={{ marginRight: '10px' }}
        />
        <label style={{ margin: 0 }}>{data.label}</label>
      </div>
    );
  };
  const CustomOption = (props) => {
    const { isSelected, data } = props;
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}}
            style={{
              marginRight: "8px",
              accentColor: isSelected ? "#007bff" : "inherit",
            }}
          />
          <label>{data.label}</label>
        </div>
      </components.Option>
    );
  };

  const CustomCityOption = (props) => {
    const { isSelected, data } = props;
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}}
            style={{
              marginRight: "8px",
              accentColor: isSelected ? "#007bff" : "inherit",
            }}
          />
          <label>{data.label}</label>
        </div>
      </components.Option>
    );
  };

  const CustomSegmentOption = (props) => {
    const { isSelected, data } = props;
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}}
            style={{
              marginRight: "8px",
              accentColor: isSelected ? "#007bff" : "inherit",
            }}
          />
          <label>{data.label || ""}</label>
        </div>
      </components.Option>
    );
  };

  return (
    <div className="filter-bar" ref={filterBarRef}>
      <Select
        options={countryOptions}
        value={selectedCountry}
        onChange={(option) => {
          onCountryChange(option);
          setSelectedSpecialities([]);
          setSelectedCities([]);
          setSelectedSegments([]);
        }}
        placeholder="Country"
        styles={customStyles}
        isClearable={false}
        isDisabled
      />

      <Select
        name="city"
        options={city}
        value={selectedCities}
        placeholder="Select City"
        isDisabled={disabledDropdowns.city}
        menuIsOpen={menuIsOpen.city}
        onMenuOpen={async () => {
          if (!disabledDropdowns.city) {
            setMenuIsOpen((prev) => ({ ...prev, city: true }));
            await fetchIncrementalCitySearchData();
          }
        }}
        components={{
          Option: CustomCityOption,
          MenuList: CustomMenuList,
          ValueContainer: CustomValueContainer,
        }}
        styles={customStyles}
        isMulti
        isClearable
        closeMenuOnSelect={false}
        hideSelectedOptions={false}
        onChange={async (selected, action) => {
          if (action.action === "clear") {
            await handleClearSelection("city", selected);
          } else {
            setSelectedCities(selected || []);
            handleDropdownSelect("city");
          }
        }}
      />

      <Select
        name="specialty"
        options={specialties}
        value={selectedSpecialities}
        placeholder="Select Specialty"
        isDisabled={disabledDropdowns.specialty}
        menuIsOpen={menuIsOpen.specialty}
        onMenuOpen={async () => {
          if (!disabledDropdowns.specialty) {
            setMenuIsOpen((prev) => ({ ...prev, specialty: true }));
            await fetchIncrementalSearchData();
          }
        }}
        components={{
          Option: CustomOption,
          MenuList: CustomMenuList,
          ValueContainer: CustomValueContainer,
        }}
        styles={customStyles}
        isMulti
        isClearable
        closeMenuOnSelect={false}
        hideSelectedOptions={false}
        onChange={async (selected, action) => {
          if (action.action === "clear") {
            await handleClearSelection("specialty", selected);
          } else {
            setSelectedSpecialities(selected || []);
            handleDropdownSelect("specialty");
          }
        }}
      />

      <Select
        name="segment"
        options={hcpSegments}
        value={selectedSegments}
        placeholder="HCP Segment"
        isDisabled={disabledDropdowns.segment}
        menuIsOpen={menuIsOpen.segment}
        onMenuOpen={async () => {
          if (!disabledDropdowns.segment) {
            setMenuIsOpen((prev) => ({ ...prev, segment: true }));
            await fetchIncrementalSegmentSearchData();
          }
        }}
        components={{
          Option: CustomSegmentOption,
          MenuList: CustomMenuList,
          ValueContainer: CustomValueContainer,
        }}
        styles={customStyles}
        isMulti
        isClearable
        closeMenuOnSelect={false}
        hideSelectedOptions={false}
        onChange={async (selected, action) => {
          if (action.action === "clear") {
            await handleClearSelection("segment");
          } else {
            setSelectedSegments(selected || []);
            handleDropdownSelect("segment");
          }
        }}
      />
    </div>
  );
});

export default FilterBar;

const customStyles = {
  control: (provided) => ({
    ...provided,
    height: '30px',
    borderRadius: '6px',
  }),
  menu: (provided) => ({
    ...provided,
    zIndex: 5,
  }),
  option: (provided, state) => ({
    ...provided,
    display: 'flex',
    alignItems: 'center',
    backgroundColor: state.isFocused
      ? 'transparent'
      : state.isSelected
      ? 'transparent'
      : 'white',
    color: state.isSelected ? 'black' : 'inherit',
    cursor: 'pointer',
  }),
  multiValue: (provided) => ({
    ...provided,
    backgroundColor: '#f0f0f0',
    borderRadius: '4px',
  }),
};
