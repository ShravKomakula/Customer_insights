import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './HCPSegments.css';
import hcp from '../LandingPageNew/svgIcons/HCPIcon.svg'
ChartJS.register(ArcElement, Tooltip, Legend);

const HCPSegments = ({ segmentCounts,isSubthemeClicked }) => {
  const totalSegments = segmentCounts ? Object.values(segmentCounts).reduce((acc, val) => acc + val, 0) : 0;

  const segments = {
    A: segmentCounts?.A || 0,
    B: segmentCounts?.B || 0,
    Others: Object.entries(segmentCounts)
      .filter(([key]) => key !== 'A' && key !== 'B' && key !== 'null')
      .reduce((acc, [, value]) => acc + value, 0) + (segmentCounts?.null || 0),
  };

  const data = {
    labels: ['Segment A', 'Segment B', 'Others'],
    datasets: [
      {
        data: [segments.A, segments.B, segments.Others],
        backgroundColor: ['#0000b2', '#3b82f6', '#93c5fd'],
        hoverBackgroundColor: ['#0000b2', '#3b82f6', '#93c5fd'],
        borderWidth: 0,
        rotation: -90, // Start angle of the chart
        circumference: 180, // Only show the top half of the chart
      },
    ],
  };

  const options = {
    cutout: '80%', // Adjust thickness of the chart
    plugins: {
      legend: { display: false }, // Disable the default legend
      tooltip: {
        callbacks: {
          label: (context) => `${context.label}: ${context.raw} (${((context.raw / totalSegments) * 100).toFixed(1)}%)`,
        },
      },
    },
  };

  return (
    <div className={`hcp-segments-container ${isSubthemeClicked ? 'with-border' : ''}`}>
      <h4 className="hcp-segments-title">   <img src={hcp} className='icon-doc'/>HCP Segments</h4>
      <div className="hcp-segments-chart">
        <Doughnut data={data} options={options} />
        <div className="hcp-segments-total">
          <span className="hcp-segments-total-value">{totalSegments}</span><br/>
          <span className="hcp-segments-total-label">Total HCP</span>
        </div>
      </div>
      <div className="hcp-segments-legend">
        <div className="legend-item">
          <span className="legend-color" style={{ backgroundColor: '#0000b2' }}></span>
          <span className="legend-label">Segment A</span>
          <span className="legend-count">{segments.A}</span>
        </div>
        <div className="legend-item">
          <span className="legend-color" style={{ backgroundColor: '#3b82f6' }}></span>
          <span className="legend-label">Segment B</span>
          <span className="legend-count">{segments.B}</span>
        </div>
        <div className="legend-item">
          <span className="legend-color" style={{ backgroundColor: '#93c5fd' }}></span>
          <span className="legend-label">Others</span>
          <span className="legend-count">{segments.Others}</span>
        </div>
      </div>
    </div>
  );
};

export default HCPSegments;
