// SentimentDistribution.js
import React from 'react';
import './SentimentDistribution.css';
import docIcon from '../LandingPageNew/svgIcons/filledDocIcon.svg'
const SentimentDistribution = ({ data }) => {
  return (
    <div className="sentiment-container">
    <h6 className="sentiment-title">
      <img src={docIcon} className="icon-doc" alt="Document Icon" />
      Sentiment Distribution of Comments
    </h6>
    {data.map((item, index) => (
      <div key={index} className="sentiment-item">
        {/* Value above the bar */}
        <div className="sentiment-value">
          {item.value} / {item.total}
        </div>
        <div className="sentiment-bar-container">
          {/* Bar */}
          <div className="sentiment-bar">
            <div
              className="bar-fill"
              style={{
                width: `${(item.value / item.total) * 100}%`,
                backgroundColor: item.color,
              }}
            ></div>
          </div>
        </div>
        {/* Label and percentage below the bar */}
        <div className="sentiment-label-container">
          <span className="sentiment-label" style={{ color: item.color }}>
            {item.label}
          </span>
          <span className="sentiment-percentage">
            {((item.value / item.total) * 100).toFixed(1)}%
          </span>
        </div>
      </div>
    ))}
  </div>
  
  );
};

export default SentimentDistribution;
