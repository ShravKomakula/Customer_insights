import React, { useState, useEffect } from 'react';
import './Summary.css';
import summaryIcon from '../LandingPageNew/svgIcons/summaryIcon.svg';
const Summary = ({
  summary,
  positiveInsights,
  neutralInsights,
  negativeInsights,
  isSubthemeClicked,
}) => {
  const [activeTabState, setActiveTabState] = useState('summary'); // Default to 'summary'

  useEffect(() => {
    if (!isSubthemeClicked) {
      setActiveTabState('summary'); // Reset to Summary tab
    }
  }, [isSubthemeClicked]);

  const renderContent = () => {
    //console.log('Summary:', summary);
    if (activeTabState === 'summary') {
      return summary ? (
        <div className="scrollable-content">{summary}</div>
      ) : (
        <p className="no-data">No summary data available.</p>
      );
    }
    // Dynamically decide which insights to show
    const insightsData =
      activeTabState === 'positive'
        ? positiveInsights
        : activeTabState === 'neutral'
        ? neutralInsights
        : activeTabState === 'negative'
        ? negativeInsights
        : [];

    // Assign color classes dynamically
    const tabClass =
      activeTabState === 'positive'
        ? 'positive'
        : activeTabState === 'neutral'
        ? 'neutral'
        : activeTabState === 'negative'
        ? 'negative'
        : '';

    return (
      <div className="insights-container">
        {insightsData && insightsData.length > 0 ? (
          insightsData.map((item, index) => (
            <span key={index} className={`insight-item ${tabClass}`}>
              {item}
            </span>
          ))
        ) : (
          <p className="no-data">No {activeTabState} insights available.</p>
        )}
      </div>
    );
  };

  return (
    <div className={`summary-container ${isSubthemeClicked ? 'with-border' : ''}`}>
      <div className="summary-header">
      <div className="summary-tabs">
  <span
    className={`tab ${activeTabState === 'summary' ? 'active' : 'inactive'}`}
    onClick={() => setActiveTabState('summary')}
  >
  <img src={summaryIcon} className='icon-summary'/>  Summary
  </span>
  {isSubthemeClicked && (
    <>
      <span
        className={`tab ${activeTabState === 'positive' ? 'active-positive' : 'inactive'}`}
        onClick={() => setActiveTabState('positive')}
      >
        <span className="bullet positive-bullet"></span> Positive
      </span>
      <span
        className={`tab ${activeTabState === 'neutral' ? 'active-neutral' : 'inactive'}`}
        onClick={() => setActiveTabState('neutral')}
      >
        <span className="bullet neutral-bullet"></span> Neutral
      </span>
      <span
        className={`tab ${activeTabState === 'negative' ? 'active-negative' : 'inactive'}`}
        onClick={() => setActiveTabState('negative')}
      >
        <span className="bullet negative-bullet"></span> Negative
      </span>
    </>
  )}
</div>


      </div>
      <div className="summary-content">{renderContent()}</div>
    </div>
  );
};

export default Summary;
