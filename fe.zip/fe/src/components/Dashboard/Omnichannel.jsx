// Omnichannel.js
import React from 'react';
import './Omnichannel.css';
import omni from '../LandingPageNew/svgIcons/omnichannelIcon.svg'
const Omnichannel = ({ channels }) => {
  return (
    <div className="omnichannel-container">
      <h5><img src={omni} className='icon-doc'/> Omnichannel Profile</h5>
      <div className="channels-grid">
        {channels.map((channel, index) => (
          <div
            key={index}
            className="channel-box"
            style={{ backgroundColor: channel.color }}
          >
            <div className="channel-label">{channel.label}</div>
            <div className="channel-value">{channel.value}</div>
            <div className="channel-percentage">{channel.percentage}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Omnichannel;
