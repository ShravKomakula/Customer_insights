// Dashboard.js
import React, { useState, useEffect } from 'react';
import FilterBar from './FilterBar';
import CommentsDistribution from './CommentsDistribution';
import SentimentDistribution from './SentimentDistribution';
import HCPProfile from './HCPProfile';
import KeyInsights from './KeyInsights';
import Specialities from './Specialities';
import Omnichannel from './Omnichannel';
import Header from '../LandingPageNew/Header';
import axios from 'axios';
import './Dashboard.css';
const Dashboard = () => {
  const [apiData, setApiData] = useState(null);
  const [selectedCountry, setSelectedCountry] = useState({ value: 'MX', label: 'Mexico' });
  const [keyInsightsData, setKeyInsightsData] = useState(''); // Add state for Key Insights
  const [selectedSpecialities, setSelectedSpecialities] = useState([]);
  const [selectedCities, setSelectedCities] = useState([]);
  const [selectedSegments, setSelectedSegments] = useState([]);
  const [themeTotalCount, setThemeTotalCounts] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Loader state
  const [isOmnichannelLoading, setIsOmnichannelLoading] = useState(true); // Loader state
 
    useEffect(() => {
      const fetchData = async () => {
        setIsOmnichannelLoading(true);
  
        // Cache key based on selected filters
        const cacheKey = `dashboard-data-${selectedCountry?.value}-${JSON.stringify(
          selectedSpecialities
        )}-${JSON.stringify(selectedCities)}-${JSON.stringify(selectedSegments)}`;
  
        // Check if data exists in localStorage
        const cachedData = localStorage.getItem(cacheKey);
        if (cachedData) {
          //console.log("Loading data from cache...");
          setApiData(JSON.parse(cachedData));
          setIsOmnichannelLoading(false);
          return;
        }
  
        try {
          // Prepare the payload for the API
          const payload = {
            country: selectedCountry?.value?.toUpperCase() || "",
            specialty: selectedSpecialities?.length
              ? selectedSpecialities.map((spec) => spec.value)
              : [],
            city: selectedCities?.length
              ? selectedCities.map((city) => city.value)
              : [],
            segment: selectedSegments?.length
              ? selectedSegments.map((segment) => segment.value)
              : [],
          };
  
          //console.log("Payload:", payload); // Debug log to verify payload structure
          setIsLoading(true); // Start the loader
  
          // Make the API request
          const response = await axios.post(
            "https://emcustomerinsights.pfizer.com/backend/service/incremental_search/",
            payload
          );
  
          // Update state and cache the response
          setApiData(response.data);
          localStorage.setItem(cacheKey, JSON.stringify(response.data));
          //console.log("Data cached successfully.");
        } catch (error) {
          console.error("Error fetching data:", error);
        } finally {
          setTimeout(() => setIsOmnichannelLoading(false), 6000);
          setIsLoading(false); // Stop the loader
        }
      };
  
      fetchData();
    }, [selectedCountry, selectedSpecialities, selectedCities, selectedSegments]);

  
  const [updatedPayload, setUpdatedPayload] = useState({
    country: selectedCountry?.value?.toUpperCase() || '',
    specialty: [],
    city: [],
    segment: [],
  });
  useEffect(() => {
    /* console.log('API Data:', apiData); // Ensure the API response contains theme_counts
    console.log('theme_counts:', apiData?.theme_counts); // Check if theme_counts exists */
  }, [apiData]);
  
  const handleSearch = async (newPayload) => {
    setIsLoading(true); // Show loader
    try {
      // Create a fresh payload instead of merging with accumulatedPayload
      const updatedPayload = {
        country: newPayload.country || updatedPayload.country || '',
        specialty: newPayload.specialty || [],
        city: newPayload.city || [],
        segment: newPayload.segment || [],
      };
  
      setUpdatedPayload(updatedPayload); // Update the accumulated payload
      //console.log('Updated Payload:', updatedPayload.specialty); // Debug log
  
      // Make the API call
      const response = await axios.post(
        'https://emcustomerinsights.pfizer.com/backend/service/incremental_search/',
        updatedPayload
      );
  
      setApiData(response.data); // Update state with API data
      setTimeout(() => setIsLoading(false), 1000); // Simulate component-specific loading time
    } catch (error) {
      console.error('Error during search:', error);
    }
  };
  
  // Define the order of sentiments explicitly
  const orderedSentiments = ['Positive', 'Neutral', 'Negative'];

  // Calculate sentiment distribution with only Positive, Neutral, and Negative in the specified order
  const sentimentData = apiData?.sentiment_counts
    ? orderedSentiments.map(label => {
        const value = apiData.sentiment_counts[label] || 0;
        const total = Object.values(apiData.sentiment_counts).reduce((sum, count) => sum + count, 0);
        const percentage = ((value / total) * 100).toFixed(1) + '%';
        const color = label === 'Positive' ? '#4caf50' : label === 'Neutral' ? '#ff9800' : '#f44336';
        return { label, value, total, color, percentage };
      })
    : [];


  // Process segment data to get Segment A, Segment B, and Others
  const segmentData = apiData?.segment_counts
  ? {
      A: apiData.segment_counts.A || 0,
      B: apiData.segment_counts.B || 0,
      others: Object.entries(apiData.segment_counts)
        .filter(([key]) => key !== 'A' && key !== 'B')
        .reduce((sum, [, value]) => sum + value, 0),
    }
  : { A: 0, B: 0, others: 0 };

const totalHCP = segmentData.A + segmentData.B + segmentData.others;
useEffect(() => {
  const fetchKeyInsights = async () => {
    setIsLoading(true); // Start the loader for key insights
    try {
      const payload = { country: selectedCountry.value.toUpperCase() };
      const response = await axios.post(
        'https://emcustomerinsights.pfizer.com/backend/service/key_insights/',
        payload
      );
      
      setKeyInsightsData(response.data.summary); // Store comments summary in state
    } catch (error) {
      console.error('Error fetching key insights:', error);
    } finally {
      setIsLoading(false); // Stop the loader
    }
  };

  fetchKeyInsights();
}, [selectedCountry]);

const hcpData = [
  { name: 'Segment A', value: segmentData.A, color: '#1E3A8A' },
  { name: 'Segment B', value: segmentData.B, color: '#3B82F6' },
  { name: 'Others', value: segmentData.others, color: '#93C5FD' },
];
//omnichanner
const omnichannelData = apiData?.omnichannel_profile_counts
? Object.entries(apiData.omnichannel_profile_counts)
    .filter(([key]) => key !== 'null') // Exclude null values
    .map(([label, value]) => {
      const total = Object.values(apiData.omnichannel_profile_counts)
        .filter((_, k) => k !== 'null') // Exclude null from total calculation
        .reduce((sum, count) => sum + count, 0);
      const percentage = ((value / total) * 100).toFixed(1) + '%';
      const color = getColorForLabel(label); // Assign color based on label
      return { label, value, percentage, color };
    })
: [];
//specialities
// Specialities - Select six specialties for radar chart
const radarSpecialities = apiData?.specialty_counts
  ? Object.entries(apiData.specialty_counts)
      .sort((a, b) => b[1] - a[1]) // Sort by value in descending order
      .slice(0, 6)
      .map(([label, value]) => ({ label, value }))
  : [];
 
  const spinnerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  };
// Prepare all specialties for the scrollable list (sorted in descending order as well)
const allSpecialities = apiData?.specialty_counts
  ? Object.entries(apiData.specialty_counts)
      .sort((a, b) => b[1] - a[1]) // Sort by value in descending order
      .map(([label, value]) => ({ label, value }))
  : [];
  return (
    <div className="dashboard-container">
      {isLoading && (
        <div className="loader-container">
          <div className="spinner"></div>
        </div>
      )}
      <Header />
      <div className="filter-bar-container">
        <FilterBar
          selectedCountry={selectedCountry}
          onCountryChange={setSelectedCountry}
          specialtyOptions={apiData?.specialties || []}
          cityOptions={apiData?.cities || []}
          hcpSegmentOptions={apiData?.segments || []}
          onSearch={handleSearch} // Pass the search handler
        />
      </div>
      {!isLoading && (
        <div className="dashboard">
          <div className="row first-row">
            <div className="comments-distribution col-6">
            <CommentsDistribution
    data={apiData?.theme_counts}
    themes={apiData?.themes || []}
    selectedCountry={selectedCountry.label}
    onCountryChange={setSelectedCountry}
    specialtyOptions={apiData?.specialties || []}
    cityOptions={apiData?.cities || []}
    hcpSegmentOptions={apiData?.segments || []}
    theme_counts={apiData?.theme_counts || {}}
    totalHCP={totalHCP}
    totaldata={apiData}
    handleSearch={handleSearch}
selectedCities={selectedCities}
updatedPayload={updatedPayload}
/>

            </div>
            <div className="sentiment-distribution col-3">
              <SentimentDistribution
                data={sentimentData}
                selectedCountry={selectedCountry.label}
              />
            </div>
            <div className="hcp-profile col-3">
              <HCPProfile
                data={hcpData}
                totalHCP={totalHCP}
                selectedCountry={selectedCountry.label}
              />
            </div>
          </div>
          <div className="row second-row" style={{ marginTop: '20px',textAlign:'left' }}>
            <div className="key-insights col-4">
              <KeyInsights commentsSummary={keyInsightsData} />
            </div>
            <div className="specialities col-5">
              <Specialities
                radarSpecialities={radarSpecialities}
                allSpecialities={allSpecialities}
                selectedCountry={selectedCountry.label}
              />
            </div>
            <div className="omnichannel col-3">
              <Omnichannel
                channels={omnichannelData}
                selectedCountry={selectedCountry.label}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
  
};
// Function to assign colors based on the label
const getColorForLabel = (label) => {
  switch (label) {
    case 'Digital Enthusiast':
      return '#2E3EBB';
    case 'F2F Hybrid Adopter':
      return '#3A4EBC';
    case 'Omnichannel Pro':
      return '#8E5AD7';
    case 'Traditionalist':
      return '#24A7A7';
    default:
      return '#ccc';
  }
};
export default Dashboard;
