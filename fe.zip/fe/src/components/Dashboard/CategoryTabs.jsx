// CategoryTabs.js
import React, { useEffect } from 'react';
import './CategoryTabs.css';

const CategoryTabs = ({ themes = [], activeTab, setActiveTab }) => {
  useEffect(() => {
    //console.log("Received themes:", themes); // Log themes to verify
  }, [themes]);

  const handleTabClick = (theme) => {
    setActiveTab(theme); // Set the clicked tab as active without navigation
  };

  return (
    <div className="category-tabs">
      {themes.map((theme) => (
        <div
          key={theme}
          className={`tab-item ${activeTab === theme ? 'active' : ''}`} // Apply active class dynamically
          onClick={() => handleTabClick(theme)}
        >
          {theme}
        </div>
      ))}
    </div>
  );
};

export default CategoryTabs;
