import axios from 'axios';

const BASE_URL = 'https://emcustomerinsights.pfizer.com/backend/service/';
export const fetchSearchByTheme = async (theme, country, specialty = [], city = [], segment = []) => {
    try {
      const countryCodeMap = {
        Brazil: "BR",
        Mexico: "MX",
        // Add more country mappings as needed
      };
 
      const countryCode = countryCodeMap[country] || country; // Use short code or fallback to the input
  
      // Prepare the payload with dynamic values
      const payload = {
        theme,
        country: countryCode,
        specialty,
        city,
        segment
      };
  
      const response = await axios.post(`${BASE_URL}search_by_theme/`, payload);
  
      if (response.data) {
        const segmentCounts = response.data.segment_counts || {};
        const sentimentCounts = response.data.sentiment_counts || {};
        const totalComments = Object.values(segmentCounts).reduce((sum, count) => sum + count, 0);
        const othersCount =
          (segmentCounts['C'] || 0) + (segmentCounts['D'] || 0) + (segmentCounts['null'] || 0);
  
        // Assuming the response has specialties and cities
        const specialties = response.data.specialties || [];
        const cities = response.data.cities || [];
  const themes=response.data.themes||[];
        return {
          segmentCounts: {
            A: segmentCounts['A'] || 0,
            B: segmentCounts['B'] || 0,
            Others: othersCount,
            Total: totalComments,
          },
          sentiments: sentimentCounts,
          specialties,
          cities
        };
      }
      return null;
    } catch (error) {
      console.error('Error fetching search by theme:', error);
      return null;
    }
  };
  

export const fetchMainThemeSummary = async (theme, country) => {
  try {
    const response = await axios.post(`${BASE_URL}main_theme_summary/`, { theme, country });
    return response.data;
  } catch (error) {
    console.error('Error fetching main theme summary:', error);
    throw error;
  }
};

export const fetchSubThemeData = async (subTheme, country) => {
  try {
    const response = await axios.post(`${BASE_URL}sub_theme/`, { sub_theme: subTheme, country });
    return response.data;
  } catch (error) {
    console.error('Error fetching sub theme data:', error);
    throw error;
  }
};

export const fetchSubThemeSummary = async (mainTheme, subTheme, country) => {
  try {
    const response = await axios.post(`${BASE_URL}subtheme_summary/`, { main_theme: mainTheme, sub_theme: subTheme, country });
    return response.data;
  } catch (error) {
    console.error('Error fetching sub theme summary:', error);
    throw error;
  }
};
