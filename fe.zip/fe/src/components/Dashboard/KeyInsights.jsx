/*
  const insights = commentsSummary
    ? commentsSummary.split('\n').map((item, index) => {
        // Check if the line starts with a number followed by a period (e.g., "1. ", "2. ")
        if (/^\d+\.\s/.test(item)) {
          return item; // Keep it as is
        }
        // Otherwise, replace "- " with "index+1."
        return `${index + 1}. ${item.replace('- ', '')}`;
      })
    : [];

 */
import React from 'react';
import './KeyInsights.css';

const KeyInsights = ({ commentsSummary }) => {
  // Process comments summary to handle plain paragraphs
  const insights = commentsSummary
    ? commentsSummary.split('.').filter(Boolean).map(sentence => {
        const trimmed = sentence.trim();
        return trimmed ? `• ${trimmed}.` : null; // Add bullet and retain period
      }).filter(Boolean) // Remove any null or empty values
    : [];


  return (
    <div className="key-insights-container">
      <h5 className="key-insights-title">Key Insights</h5>
      <div className="insights-list">
        {insights.map((insight, index) => (
          <li key={index} className="insight-item">
            {insight}
          </li>
        ))}
      </div>
    </div>
  );
};

export default KeyInsights;
