import React ,{useState}from 'react';
import { useNavigate } from 'react-router-dom';
import './CommentsDistribution.css';
import commentsIcon from '../LandingPageNew/svgIcons/commentsIcon.svg';
import { fetchSearchByTheme } from './apiUtils';

const CommentsDistribution = ({
  data,
  themes,updatedPayload,
  onThemeClick,
  totalHCP,
  selectedCountry,totaldata,
  onCountryChange,selectedCities,selectedSpecialities,selectedSegments,
  specialtyOptions = [],
  cityOptions = [],
  hcpSegmentOptions = [],
  theme_counts = {},
  selected
}) => {
  const navigate = useNavigate();
  const [hoveredBar, setHoveredBar] = useState(null);
  const [hoveredBarPosition, setHoveredBarPosition] = useState(null);
  const [barDetails, setBarDetails] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const cities=updatedPayload.city;
  const segments=updatedPayload.segment;
   const specialities=updatedPayload.specialty
//console.log(updatedPayload,"updated paylaod in commnet")

  const totalValue = data ? Object.values(data).reduce((sum, value) => sum + value, 0) : 0;

  // Prepare and sort barData in descending order of percentage
  const barData = data
    ? Object.keys(data)
        .map((key) => ({
          label: key,
          value: data[key],
          percentage: totalValue > 0 ? ((data[key] / totalValue) * 100).toFixed(1) : 0,
          color: '#000093',
        }))
        .sort((a, b) => b.percentage - a.percentage) // Sort descending by percentage
    : [];
    const handleMouseEnter = async (bar, event) => {
      const barElement = event.currentTarget.getBoundingClientRect();
      setHoveredBar(bar);
      setHoveredBarPosition({
        top: barElement.top + window.scrollY,
        left: barElement.right + 10,
      });
    
      if (barDetails[bar.label]) return; // Use cached data if available
    
      setLoading(true);
      setError(null);
    
      try {
        const theme = bar.label; // Use bar.label as the theme
        const country = selectedCountry; // Pass selectedCountry
     ;
      
        //console.log("Payload:", { theme,country,specialities,cities,selectedSegments});
  
        const fetchedDetails = await fetchSearchByTheme(theme,country,specialities,cities,segments);
        setBarDetails((prevDetails) => ({
          ...prevDetails,
          [bar.label]: fetchedDetails,
        }));
      } catch (err) {
        console.error('Error fetching bar details:', err);
        setError('Failed to load details.');
      } finally {
        setLoading(false);
      }
    };
    const handleMouseLeave = () => {
      setHoveredBar(null);
      setHoveredBarPosition(null);
      setError(null);
    };
  const handleBarClick = (label) => {
    const selectedCount = data[label] || 0;
    const selectedPercentage = totalValue > 0 ? ((selectedCount / totalValue) * 100).toFixed(1) : 0;

    navigate(`/category/${label}`, {
      state: {
        country: selectedCountry,
        city: cityOptions,
        specialty: specialtyOptions,
        hcpSegment: hcpSegmentOptions,
        themes,
        data,cities,specialities,segments,
        totalValue,
        totalHCP,totaldata,
        theme_counts,
        selectedTheme: {
          name: label,
          count: selectedCount,
          percentage: selectedPercentage,
        },
      },
    });
  };

  return (
    <div className="comments-distribution-container">
      <h5 className="chart-title">
        <img src={commentsIcon} className="icon-doc" alt="Comments Icon" /> Comments Distribution Across Key Categories
        of {selectedCountry}
      </h5>
      <div className="scrollable-bar-chart">
        <div className="bar-chart">
          {barData.map((data, index) => (
           <div
           key={index}
           className="bar-container"
           onClick={() => handleBarClick(data.label)}
           onMouseEnter={(event) => handleMouseEnter(data, event)}
           onMouseLeave={handleMouseLeave}
         >
           <p className="bar-percentage">{data.percentage}%</p>
           <div className="bar-wrapper">
             <div
               className="bar-fill"
               style={{
                 height: `${data.percentage}%`,
                 backgroundColor: data.color,
               }}
             ></div>
           </div>
           <span className="bar-label">{data.label}</span>
         </div>
         
          ))}
        </div>
        {hoveredBar && hoveredBarPosition && (
          <div
            className="hover-info"
            style={{
              top: `${hoveredBarPosition.top}px`,
              left: `${hoveredBarPosition.left}px`,
            }}
          >
            <h5 className="hover-title">
              {hoveredBar.label} - {hoveredBar.percentage}%
            </h5>
            <div className="hover-line"></div>
            {loading && <p>Loading...</p>}
            {error && <p className="error">{error}</p>}
            {!loading && !error && barDetails[hoveredBar.label] && (
              <>
                <div className="hover-content">
                  <div className="hover-item">
                    <span className="hover-label">HCP Segment A:</span>
                    <span className="hover-value">{barDetails[hoveredBar.label].segmentCounts.A || 0}</span>
                  </div>
                  <div className="hover-item">
                    <span className="hover-label">HCP Segment B:</span>
                    <span className="hover-value">{barDetails[hoveredBar.label].segmentCounts.B || 0}</span>
                  </div>
                  <div className="hover-item">
                    <span className="hover-label">Others:</span>
                    <span className="hover-value">{barDetails[hoveredBar.label].segmentCounts.Others || 0}</span>
                  </div>
                  <div className="hover-item">
                    <span className="hover-label">Cities:</span>
                    <span className="hover-value">{barDetails[hoveredBar.label].cities.length || 0}</span>
                  </div>
                  <div className="hover-item">
                    <span className="hover-label">Specialities:</span>
                   
                    <span className="hover-value">{barDetails[hoveredBar.label].specialties.length || 0}</span>
                  </div>
                  <div className="hover-item">
                    <span className="hover-label">Total Comments:</span>
                    <span className="hover-value">{barDetails[hoveredBar.label].segmentCounts.Total || 0}</span>
                  </div>
                </div>
                <div className="hover-line"></div>
                <div className="sentiment1-section">
                  <div className="sentiment1-item positive">
                    <span className="dot positive-dot"></span>
                  
                    <span className="hover-value">{barDetails[hoveredBar.label].sentiments.Positive || 0}</span>
                  </div>
                  <div className="sentiment1-item neutral">
                    <span className="dot neutral-dot"></span>
                 
                    <span className="hover-value">{barDetails[hoveredBar.label].sentiments.Neutral || 0}</span>
                  </div>
                  <div className="sentiment1-item negative">
                    <span className="dot negative-dot"></span>
                  
                    <span className="hover-value">{barDetails[hoveredBar.label].sentiments.Negative || 0}</span>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CommentsDistribution;
