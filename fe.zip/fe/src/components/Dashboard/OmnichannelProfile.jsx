import React from 'react';
import './OmnichannelProfile.css';
import omni from '../LandingPageNew/svgIcons/omnichannelIcon.svg'
const OmnichannelProfile = ({ profileCounts,isSubthemeClicked }) => {
  const totalProfiles = profileCounts ? Object.values(profileCounts).reduce((acc, val) => acc + val, 0) : 0;

  // Define specific colors for each label
  const colorMapping = {
    "Digital Enthusiast": "#0909BC",
    "Omnichannel Pro": "#6541B4",
    "Traditionalist": "#3957E8",
    "F2F Hybrid Adapter": "#008AEC",
  };

  // Map profile data, excluding 'null', and assign colors from the colorMapping
  const profiles = profileCounts
    ? Object.keys(profileCounts)
        .filter(key => key !== 'null')
        .map(key => ({
          label: key,
          count: profileCounts[key],
          percentage: ((profileCounts[key] / totalProfiles) * 100).toFixed(1),
          color: colorMapping[key] || "#008AEC", // Fallback color if label isn't in colorMapping
        }))
    : [];

  // Determine dynamic height based on the number of profiles
  const containerHeight = profiles.length === 2 ? '150px' : profiles.length === 3 ? '200px' : '250px';

  return (
    <div className={`omnichannel-profile-container ${isSubthemeClicked ? 'with-border' : ''}`}>
      <h4 className="omnichannel-profile-title">
        <img src={omni} className='icon' />Omnichannel Profile</h4>
      <div className="profile-grid">
        {profiles.map((profile, index) => (
          <div
            key={index}
            className="profile-box"
            style={{ backgroundColor: profile.color }}
          >
            <div className="profile-label">
              <span style={{ color: "#fff" }}>{profile.label}</span>
            </div>
            <div className="profile-count" style={{ color: "#fff" }}>{profile.count}</div>
            <div className="profile-percentage" style={{ color: "#fff" }}>{profile.percentage}%</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OmnichannelProfile;
