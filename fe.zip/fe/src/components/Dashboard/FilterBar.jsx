import React, { useState, memo, useRef, useEffect } from 'react';
import Select, { components } from 'react-select';
import './FilterBar.css'; // Import custom styles here

const FilterBar = memo(({
  selectedCountry,
  onCountryChange,
  specialtyOptions = [],
  cityOptions = [],
  hcpSegmentOptions = [],
  onSearch,
}) => {
  const countryOptions = [
    { value: 'MX', label: 'Mexico' },
    { value: 'BR', label: 'Brazil' },
  ];

  const [specialtyCount, setspecialtyCount] = useState(0);
  const [cityCount, setCityCount] = useState(0);
  const [segmentCount, setSegmentCount] = useState(0);
  const [selectedSpecialities, setSelectedSpecialities] = useState([]);
  const [selectedCities, setSelectedCities] = useState([]);
  const [selectedSegments, setSelectedSegments] = useState([]);
  const [menuIsOpen, setMenuIsOpen] = useState({
    specialty: false,
    city: false,
    segment: false,
  });

  const filterBarRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (filterBarRef.current && !filterBarRef.current.contains(event.target)) {
        setMenuIsOpen({ specialty: false, city: false, segment: false }); // Close all dropdowns
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, []);

  const dropdownHcpSegmentOptions = hcpSegmentOptions
    .filter(segment => segment === 'A' || segment === 'B')
    .map(segment => ({ value: segment, label: segment }));
    const [disabledDropdowns, setDisabledDropdowns] = useState({
      specialty: false,
      city: false,
      segment: false,
    });
    
    const handleDropdownSelect = (type) => {
      // Disable other dropdowns when one is selected
      setDisabledDropdowns((prev) => ({
        specialty: type !== 'specialty',
        city: type !== 'city',
        segment: type !== 'segment',
      }));
    };
    
    const handleShowClick = async (type, event) => {
      if (event) event.preventDefault();
      setMenuIsOpen((prev) => ({ ...prev, [type]: false })); // Close the dropdown
    
      // Re-enable all dropdowns after clicking Show
      setDisabledDropdowns({ specialty: false, city: false, segment: false });
    
      const payload = {
        country: selectedCountry?.value?.toUpperCase() || '',
        specialty: selectedSpecialities.map((s) => s.value),
        city: selectedCities.map((c) => c.value),
        segment: selectedSegments.map((s) => s.value),
      };
    
      try {
        const response = await onSearch(payload);
    
        setCityCount(payload.city.length);
        setspecialtyCount(payload.specialty.length);
        setSegmentCount(payload.segment.length);
      } catch (error) {
        console.error('Error fetching data:', error);
        alert('Failed to fetch data. Please try again.');
      }
    };
    
   
    
    const handleClearSelection = async (type) => {
      // Build the payload based on the type of field being cleared
      const updatedPayload = {
        country: selectedCountry?.value?.toUpperCase() || '',
        specialty: type === 'specialty' ? [] : selectedSpecialities.map((s) => s.value),
        city: type === 'city' ? [] : selectedCities.map((c) => c.value),
        segment: type === 'segment' ? [] : selectedSegments.map((s) => s.value),
      };
    
      // Update the state for the cleared field
      if (type === 'specialty') {
        setSelectedSpecialities([]);
        setspecialtyCount(0);
      } else if (type === 'city') {
        setSelectedCities([]);
        setCityCount(0);
      } else if (type === 'segment') {
        setSelectedSegments([]);
        setSegmentCount(0);
      }
    
      // Trigger the API with the updated payload
      try {
        await onSearch(updatedPayload);
      } catch (error) {
        console.error('Error fetching data after clearing input:', error);
      }
    };
    

    

  const CustomValueContainer = ({ children, ...props }) => {
    const currentValues = props.getValue(); // Get selected values
    const firstValue = currentValues[0]?.label || ''; // First selected city
    const remainingCount = currentValues.length - 1; // Number of additional items

    return (
      <components.ValueContainer {...props}>
        {currentValues.length > 0 ? (
          <div>
            {firstValue}
            {remainingCount > 0 && `, ${remainingCount} more...`} {/* Show count */}
          </div>
        ) : (
          children
        )}
      </components.ValueContainer>
    );
  };

  const CustomMenuList = (props) => {
    const type = props.selectProps.name;

    return (
      <div>
        <components.MenuList {...props}>
          {props.children}
        </components.MenuList>
        <div
          className="dropdown-footer"
          style={{
            textAlign: 'center',
            padding: '10px',
            background: 'linear-gradient(to right, #4c6ef5, #3b5bdb)',
            color: '#fff',
            cursor: 'pointer',
          }}
          onClick={() => handleShowClick(type)}
        >
          Show {props.selectProps.value.length} selected {props.selectProps.placeholder}'s
        </div>
      </div>
    );
  };
 
  
  
  const CustomCheckboxOption = (props) => {
    const { data, isSelected, innerRef, innerProps } = props;
  
    const handleCheckboxChange = (e) => {
      e.stopPropagation(); // Prevent default dropdown behavior
      const selectedOption = { value: data.value, label: data.label };
      if (isSelected) {
        // If already selected, remove it
        props.selectProps.onChange(
          props.selectProps.value.filter((option) => option.value !== data.value)
        );
      } else {
        // If not selected, add it
        props.selectProps.onChange([...props.selectProps.value, selectedOption]);
      }
    };
  
    return (
      <div
        ref={innerRef}
        {...innerProps}
        style={{
          display: 'flex',
          alignItems: 'center',
          padding: '5px',
          cursor: 'pointer',
        }}
      >
        <input
          type="checkbox"
          checked={isSelected}
          onChange={handleCheckboxChange}
          style={{ marginRight: '10px' }}
        />
        <label style={{ margin: 0 }}>{data.label}</label>
      </div>
    );
  };
  // added new starts from here 
  const CustomOption = (props) => {
    const { isSelected, data } = props;
  
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}} 
           style={{
            marginRight: "8px",
            accentColor: isSelected ? "#007bff" : "inherit", // Blue color for selected
          }}
          />
          <label>{data.label}</label>
        </div>
      </components.Option>
    );
  };
 
  

  const CustomCityOption = (props) => {
    const { isSelected, data } = props;
  
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}} 
            style={{
              marginRight: "8px",
              accentColor: isSelected ? "#007bff" : "inherit", // Blue color for selected
            }}
          />
          <label>{data.label}</label>
        </div>
      </components.Option>
    );
  };

  const CustomSegmentOption = (props) => {
    const { isSelected, data } = props;
  
    return (
      <components.Option {...props}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}} // Prevent default checkbox behavior
           style={{
            marginRight: "8px",
            accentColor: isSelected ? "#007bff" : "inherit", // Blue color for selected
          }}
          />
          <label>{data.label || ""}</label> {/* Ensure `label` is valid */}
        </div>
      </components.Option>
    );
  };

  // added new ends here
  //console.log(specialtyOptions,'coming01checkingthe file')

  return (
    <div className="filter-bar" ref={filterBarRef}>
      <Select
        options={countryOptions}
        value={selectedCountry}
        onChange={(option) => {
          onCountryChange(option);
          setSelectedSpecialities([]);
          setSelectedCities([]);
          setSelectedSegments([]);
        }}
        placeholder="Country"
        styles={customStyles}
        isClearable={false}
      />

<Select
  name="city"
  options={cityOptions.map((city) => ({ value: city, label: city }))}
  value={selectedCities}
  placeholder="City"
  isDisabled={disabledDropdowns.city} // Disable based on state
  menuIsOpen={menuIsOpen.city}
  onMenuOpen={() => {
    if (!disabledDropdowns.city) {
      setMenuIsOpen((prev) => ({ ...prev, city: true }));
    }
  }}
  components={{
    Option: CustomCityOption,
    MenuList: CustomMenuList,
    ValueContainer: CustomValueContainer,
  }}
  styles={customStyles}
  isMulti
  isClearable
  closeMenuOnSelect={false}
  hideSelectedOptions={false}
  onChange={async (selected, action) => {
    if (action.action === "clear") {
      await handleClearSelection("city");
    } else {
      setSelectedCities(selected || []);
      {console.log('selected',selected)}
      handleDropdownSelect("city"); // Disable other dropdowns
    }
  }}
/>
<Select
  name="specialty"
  options={specialtyOptions.map((spec) => ({ value: spec, label: spec }))}
  value={selectedSpecialities}
  placeholder="specialty"
  isDisabled={disabledDropdowns.specialty} // Disable based on state
  menuIsOpen={menuIsOpen.specialty}
  onMenuOpen={() => {
    if (!disabledDropdowns.specialty) {
      setMenuIsOpen((prev) => ({ ...prev, specialty: true }));
    }
  }}
  components={{
    Option: CustomOption,
    MenuList: CustomMenuList,
    ValueContainer: CustomValueContainer,
  }}
  styles={customStyles}
  isMulti
  isClearable
  closeMenuOnSelect={false}
  hideSelectedOptions={false}
  onChange={async (selected, action) => {
    if (action.action === "clear") {
      await handleClearSelection("specialty");
    } else {
      setSelectedSpecialities(selected || []);
      handleDropdownSelect("specialty"); // Disable other dropdowns
    }
  }}
/>
<Select
  name="segment"
  options={dropdownHcpSegmentOptions}
  value={selectedSegments}
  placeholder="HCP Segment"
  isDisabled={disabledDropdowns.segment} // Disable based on state
  menuIsOpen={menuIsOpen.segment}
  onMenuOpen={() => {
    if (!disabledDropdowns.segment) {
      setMenuIsOpen((prev) => ({ ...prev, segment: true }));
    }
  }}
  components={{
    Option: CustomSegmentOption,
    MenuList: CustomMenuList,
    ValueContainer: CustomValueContainer,
  }}
  styles={customStyles}
  isMulti
  isClearable
  closeMenuOnSelect={false}
  hideSelectedOptions={false}
  onChange={async (selected, action) => {
    if (action.action === "clear") {
      await handleClearSelection("segment");
    } else {
      setSelectedSegments(selected || []);
      handleDropdownSelect("segment"); // Disable other dropdowns
    }
  }}
/>



    </div>
  );
});

export default FilterBar;

const customStyles = {
  control: (provided) => ({
    ...provided,
    height: '30px',
    borderRadius: '6px',
  }),
  menu: (provided) => ({
    ...provided,
    zIndex: 5,
  }),
  option: (provided, state) => ({
    ...provided,
    display: 'flex',
    alignItems: 'center',
    backgroundColor: state.isFocused
      ? 'transparent' // Remove background for hover
      : state.isSelected
      ? 'transparent' // Remove background for selected
      : 'white', // Default background
    color: state.isSelected ? 'black' : 'inherit', // Keep text color black when selected
    cursor: 'pointer',
  }),
  multiValue: (provided) => ({
    ...provided,
    backgroundColor: '#f0f0f0', // Light background for multi-selected items
    borderRadius: '4px',
  }),
};

