import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import axios from 'axios';
import FilterBar from './categoryFilter';
import Header from '../LandingPageNew/Header';
import './CategoryDetails.css';
import TotalComments from './TotalComments';
import OmnichannelProfile from './OmnichannelProfile';
import Summary from './Summary';
import HCPSegments from './HCPSegments';
import DistributionChart from './DistributionChart';
import CategoryTabs from './CategoryTabs';

const CategoryDetails = () => {
  const { category } = useParams();
  const location = useLocation();
  const {
    country,
    city,
    specialty,
    totalValue,
    hcpSegment,
    totalHCP,
   themes,
    data,totaldata,
    selectedTheme,
    theme_counts,cities,segments,specialities,
  } = location.state || {};
  const [apiData, setApiData] = useState(null);
  const [cityOptions, setCityOptions] = useState([]);
  const [specialtyOptions, setspecialtyOptions] = useState([]);
  const [segmentOptions, setSegmentOptions] = useState([]);
  const[themeOptions,setThemeOptions]=useState([]);
  const [selectedSubTheme, setSelectedSubTheme] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [categoryData, setCategoryData] = useState(null);
  const [selectedCountry, setSelectedCountry] = useState({ value: country, label: country });
  const [activeTab, setActiveTab] = useState(category || (themes && themes[0]) || '');
  const [isSearchTriggered, setIsSearchTriggered] = useState(false);

  const [currentTheme, setCurrentTheme] = useState(selectedTheme);

  const [omnichannelData, setOmnichannelData] = useState({});
  const [hcpSegments, setHcpSegments] = useState({});
  const [sentimentCounts, setSentimentCounts] = useState({});
  const [themeSummary, setThemeSummary] = useState('');
  const [positiveInsights, setPositiveInsights] = useState([]);
  const [negativeInsights, setNegativeInsights] = useState([]);
  const [neutralInsights, setNeutralInsights] = useState([]);
  const [isSubthemeClicked, setIsSubthemeClicked] = useState(false);
  const countryCodes = {
    Mexico: 'MX',
    Brazil: 'BR',
    // Add other countries as needed
  };
  
  const [updatedPayload, setUpdatedPayload] = useState({
    country: countryCodes[selectedCountry?.value?.toUpperCase() ]|| '',
    specialty: [],
    city: [],
    segment: [],
  });
  const fetchData = async (payload) => {
    setIsLoading(true);
    try {
      const countryCode = countryCodes[selectedCountry?.value] || selectedCountry?.value;
      const finalPayload = payload || {
        theme: activeTab,
        country: countryCode,
        city: cities,
        segment:segments || [],
        specialty: specialities,
      };
  
      console.log('Payload for Search By Theme:', finalPayload);
   
      const [themeResponse, summaryResponse] = await Promise.all([
        axios.post('https://emcustomerinsights.pfizer.com/backend/service/search_by_theme/', finalPayload),
        axios.post('https://emcustomerinsights.pfizer.com/backend/service/main_theme_summary/', finalPayload),
      ]);
  
      if (themeResponse.data) {
     /*    console.log('Search by Theme Response:', themeResponse.data); */
        setCategoryData(themeResponse.data);
        setSentimentCounts(themeResponse.data.sentiment_counts || {});
        setOmnichannelData(themeResponse.data.omnichannel_profile_counts || {});
        setHcpSegments(themeResponse.data.segment_counts || {});
      }
  
      if (summaryResponse.data) {
        //console.log('Main Theme Summary Response:', summaryResponse.data);
        setThemeSummary(summaryResponse.data.summary || 'Currently we are working on it');
      }
    } catch (error) {
      console.error('Error in fetchData:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSearch = async (newPayload) => {
    setIsSearchTriggered(true);
    setIsLoading(true); // Show loader
    try {
      const countryCode = countryCodes[selectedCountry?.value] || selectedCountry?.value;
  
      // Merge newPayload with the existing state
      const updatedPayload = {
        ...newPayload,
        theme: activeTab, // Include the current active theme in the payload
        country: countryCode,
      };
  
      console.log('Payload for Incremental Search:', updatedPayload);
  
      // Make the API call
      const response = await axios.post(
        'https://emcustomerinsights.pfizer.com/backend/service/incremental_search/',
        updatedPayload
      );
  
      // Check if the response contains "No records found"
      if (response.data?.detail === "No records found") {
        alert("No records available");
        return; // Stop further execution
      }
  
      // Update state with API response
      setCityOptions(response.data.cities || []);
      setspecialtyOptions(response.data.specialities || []);
      setSegmentOptions(response.data.segments || []);
      setThemeOptions(response.data.themes || []);
  
      // Determine the active tab
      const isThemeAvailable = response.data.themes?.includes(activeTab);
      const firstTheme = response.data.themes?.[0] || null;
      const newActiveTab = isThemeAvailable ? activeTab : firstTheme;
  
      setActiveTab(newActiveTab); // Update the activeTab based on response
  
      // Consolidate the payload to include the correct active theme
      const finalPayload = {
        ...updatedPayload,
        theme: newActiveTab, // Ensure the payload uses the updated active theme
      };
  
      console.log('Final Payload for fetchData:', finalPayload);
  
      // Update the global payload
      setUpdatedPayload(finalPayload);
  
      // Fetch data using the final payload
      fetchData(finalPayload);
    } catch (error) {
      console.error('Error in incremental search API:', error);
    } finally {
      setIsLoading(false);
    }
  };
  


  
  
const [lastClickTime, setLastClickTime] = useState(0);


useEffect(() => {
  // Re-trigger data fetch when filters are updated
  if (isSearchTriggered) {
    fetchData(updatedPayload);
  } else {
    fetchData(); // Default fetch without filters if no search is triggered
  }
}, [updatedPayload]); // Ensure this is triggered when updatedPayload changes


const handleTabClick = async (theme) => {
  setActiveTab(theme); // Update active tab
  setSelectedSubTheme(null); // Deselect any selected sub-theme

  // Consolidate the payload to ensure consistent structure
  const newPayload = {
    ...updatedPayload,
    theme: theme, // Ensure the selected theme is included in the payload
    country: countryCodes[selectedCountry?.value] || selectedCountry?.value, // Include country
  };

  console.log('Triggering API call with updated payload:', newPayload);

  // Update the state with the new payload
  setUpdatedPayload(newPayload);

  // Call the API with the updated payload
  setIsLoading(true);  // Start the loader
  try {
    await fetchData(newPayload); // Trigger the data fetch with the updated payload

  } catch (error) {
    console.error('Error in fetchData on tab click:', error);
  } finally {
    setIsLoading(false); // Hide the loader once the data is fetched
  }
};
const onSubThemeClick = async (selectedSubTheme) => {
  setIsSubthemeClicked(true); // Mark sub-theme as clicked
  setSelectedSubTheme(selectedSubTheme); // Set the selected sub-theme

  // Construct payloads for both cases
  const searchTriggeredPayload = {
    ...updatedPayload,
    theme: activeTab,
    sub_theme: selectedSubTheme,
    country: countryCodes[selectedCountry?.value] || selectedCountry?.value,
  };

  const defaultPayload = {
    theme: activeTab,
    sub_theme: selectedSubTheme,
    country: countryCodes[selectedCountry?.value] || selectedCountry?.value,
    city: cities || [],
    segment: segments || [],
    specialty: specialities || [],
  };

  // Determine which payload to use
  const payloadToUse = isSearchTriggered ? searchTriggeredPayload : defaultPayload;

  console.log("Payload for Sub-theme Click:", payloadToUse);

  try {
    // Call the sub-theme API and summary API with the selected payload
    const [subThemeResponse, subThemeSummaryResponse] = await Promise.all([
      axios.post('https://emcustomerinsights.pfizer.com/backend/service/sub_theme/', payloadToUse),
      axios.post('https://emcustomerinsights.pfizer.com/backend/service/subtheme_summary/', {
        country: payloadToUse.country,
        main_theme: payloadToUse.theme,
        sub_theme: payloadToUse.sub_theme,
      }),
    ]);

    // Handle sub-theme response
    if (subThemeResponse.data) {
      setSentimentCounts(subThemeResponse.data.sentiment_counts || {});
      setHcpSegments(subThemeResponse.data.segment_counts || {});
      setOmnichannelData(subThemeResponse.data.omnichannel_profile_counts || {});
    } else {
      console.error("Sub-theme API response is empty or invalid");
    }

    // Handle sub-theme summary response
    if (subThemeSummaryResponse.data) {
      setThemeSummary(subThemeSummaryResponse.data.summary || '');

      // Parse insights if available
      const parseInsights = (insights) => {
        try {
          return typeof insights === 'string' ? JSON.parse(insights.replace(/'/g, '"')) : [];
        } catch (error) {
          console.error('Error parsing insights:', error);
          return [];
        }
      };

      setPositiveInsights(parseInsights(subThemeSummaryResponse.data.positive));
      setNegativeInsights(parseInsights(subThemeSummaryResponse.data.negative));
      setNeutralInsights(parseInsights(subThemeSummaryResponse.data.neutral));
    } else {
      console.error("Sub-theme summary API response is empty or invalid");
    }
  }catch (error) {
    console.error("Error in subtheme click:", error);
  }
  
};

  
  const handleLabelClick = (label) => {
    const currentTime = Date.now();
    const timeDifference = currentTime - lastClickTime;
  
    if (timeDifference < 300) { // Double-click detected (300ms threshold)
      setIsSubthemeClicked(false); // Reset the subtheme click state
      setSelectedSubTheme(null); // Deselect the subtheme
      // Ensure it triggers with `null` to deselect
    } else { // Single-click behavior
      setIsSubthemeClicked(true);
      setSelectedSubTheme(label); // Set the selected subtheme
      onSubThemeClick(label); // Trigger the sub-theme click action
    }
  
    setLastClickTime(currentTime); // Update last click time
  };
  
  const themeTotal = theme_counts
    ? Object.values(theme_counts).reduce((sum, count) => sum + count, 0)
    : 0;

  return (
    <div className="dashboard-container">
      {isLoading && (
        <div className="loader-container">
          <div className="spinner"></div>
        </div>
      )}
        <>
          <Header />
          <div className="filter-bar-container">
            <FilterBar
            maindata={totaldata}
              selectedCountry={selectedCountry}
             
              specialtyOptions={specialty || []}
              cityOptions={[]}
              hcpSegmentOptions={hcpSegment || []}
           onSearch={handleSearch}
           loading={(ele)=>{
            setIsLoading(ele)
           }}
           specialities={specialities}
           cities={cities}
           segments={segments}
            />
          </div>
          {!isLoading && (
          <div className="category-page">
            <h2 className="category-title">Total Distribution for {country}</h2>
            <div className="body-category">
            <CategoryTabs
    themes={themeOptions.length > 0 ? themeOptions : themes} // Display updated themes or fallback to initial themes
    activeTab={activeTab}
    setActiveTab={handleTabClick}
    themecountTotal={themeTotal}
    totalHCP={totalHCP}
/>

              <div className="content-section">
                <div className="main-chart">
                  <DistributionChart
                    subThemeCounts={categoryData.sub_theme_counts}
                    totalComments={Object.values(categoryData.sub_theme_counts || {}).reduce(
                      (acc, count) => acc + count,
                      0
                    )}
                    onSubThemeClick={handleLabelClick}
                    activeTab={activeTab}
                    selectedTheme={currentTheme}
                    selectedSubTheme={selectedSubTheme}
                    isSubthemeClicked={isSubthemeClicked}
                    themecountTotal={themeTotal}
                    totalcountvalue={totalValue}
                    totalHCP={totalHCP}
                  
                  />
                </div>
                <div className="grid-section">
                  <div className="tall-component">
                    <TotalComments sentimentCounts={sentimentCounts} isSubthemeClicked={isSubthemeClicked} />
                  </div>
                  <div className="tall-component">
                    <OmnichannelProfile profileCounts={omnichannelData} isSubthemeClicked={isSubthemeClicked} />
                  </div>
                  <div className="tall-component">
                    <HCPSegments segmentCounts={hcpSegments} isSubthemeClicked={isSubthemeClicked} />
                  </div>
                  <div className="tall-component">
                  <Summary
  summary={themeSummary}
  positiveInsights={positiveInsights}
  neutralInsights={neutralInsights}
  negativeInsights={negativeInsights}
  isSubthemeClicked={isSubthemeClicked}
  selectedSubTheme={selectedSubTheme}
  activeTab={activeTab}
  selectedCountry={selectedCountry}
/>

                  </div>
                </div>
              </div>
            </div>
          </div>
          )}
        </>
      
    </div>
  );
};

export default CategoryDetails;