
import React from 'react';
import { Radar } from 'react-chartjs-2';
import './Specialities.css';
import specialty from '../LandingPageNew/svgIcons/specialityIcon.svg';
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend } from 'chart.js';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

const Specialities = ({ radarSpecialities, allSpecialities }) => {
  // Sort specialties by value in descending order
  const sortedSpecialities = [...allSpecialities].sort((a, b) => b.value - a.value);

  // Exclude "Others" from the top 5 specialties
  const top5Specialities = sortedSpecialities
    .filter(item => item.label !== 'Others') // Remove any pre-existing "Others"
    .slice(0, 5); // Take the top 5 specialties excluding "Others"

  // Calculate the total value for "Others" by combining:
  // - Values of all specialties beyond the top 5
  // - Value of the original "Others" category if it exists
  const othersValue = sortedSpecialities
    .slice(5) // All remaining specialties beyond the top 5
    .reduce((acc, item) => acc + item.value, 0) +
    (sortedSpecialities.find(item => item.label === 'Others')?.value || 0); // Add value of original "Others" if present

  // Prepare radar chart data (top 5 + combined "Others")
  const radarData = [
    ...top5Specialities, // Top 5 specialties excluding "Others"
    { label: 'Others', value: othersValue }, // Combined "Others" category
  ];

  // Calculate the total value of radar data
  const total = radarData.reduce((acc, item) => acc + item.value, 0);

  // Radar chart data with percentages
  const chartData = {
    labels: radarData.map(item => {
      const percentage = ((item.value / total) * 100).toFixed(2); // Calculate percentage
      return [`${item.label}`, `(${percentage}%)`]; // Display label and percentage on separate lines
    }),
    datasets: [
      {
        label: 'Specialties Distribution',
        data: radarData.map(item => item.value),
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      r: {
        angleLines: { color: '#ddd' },
        grid: { color: '#ddd' },
        ticks: { display: false },
        suggestedMin: 0,
        suggestedMax: Math.max(...radarData.map(item => item.value)) + 10,
      },
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        enabled: true,
        callbacks: {
          label: function (context) {
            const label = context.label || '';
            const percentage = ((context.raw / total) * 100).toFixed(2);
            return `${label}: ${percentage}%`;
          },
        },
        bodyFont: {
          weight: 'bold',
          size: 14,
        },
        bodyColor: '#1E3A8A', // Tooltip text color
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        borderColor: '#1E3A8A',
        borderWidth: 1,
      },
    },
  };

  return (
    <div className="specialities-container">
      <h5 className="specialities-title">
        <img src={specialty} className="icon" alt="Specialty Icon" /> Specialties
      </h5>
      <div className="specialities-content">
        {/* Radar chart for top 5 + Others */}
        <div className="radar-chart">
          <Radar data={chartData} options={chartOptions} />
        </div>

        {/* Full list of specialties on the right */}
        <div className="specialities-list">
          <div className="scrollable-list">
            {allSpecialities.map((specialty, index) => (
              <div key={index} className="specialty-item">
                <span className="specialty-label">{specialty.label}</span>
                <span className="specialty-value">{specialty.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Specialities;

