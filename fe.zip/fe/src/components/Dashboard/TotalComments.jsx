import React from 'react';
import './TotalComments.css';
import docIcon from '../LandingPageNew/svgIcons/filledDocIcon.svg'
const TotalComments = ({ sentimentCounts = {} ,isSubthemeClicked}) => {
  // Filter to include only Positive, Neutral, and Negative sentiments
  const filteredSentiments = ['Positive', 'Neutral', 'Negative'];

  // Calculate total comments based only on filtered sentiments
  const totalComments = filteredSentiments.reduce(
    (acc, label) => acc + (sentimentCounts[label] || 0),
    0
  );

  // Prepare the data for rendering, only for the required sentiments
  const data = filteredSentiments.map((label) => ({
    label,
    value: sentimentCounts[label] || 0,
    total: totalComments,
    color:
      label === 'Positive'
        ? '#2563eb'
        : label === 'Neutral'
        ? '#f97316'
        : '#b91c1c', // Assign colors based on label
  }));

  return (
    <div className={`total-comments-container ${isSubthemeClicked ? 'with-border' : ''}`}>
      <h3 className="total-comments-title"><img src={docIcon} className='icon-doc' />Sentiment Distribution of Comments</h3>
      {data.map((item, index) => (
        <div key={index} className="comment-item">
          <div className="comment-value">
            <span className="comment-count">{item.value}</span> / {item.total}
          </div>
          <div className="progress-bar-container">
            <div
              className="progress-bar"
              style={{
                width: `${item.total > 0 ? (item.value / item.total) * 100 : 0}%`,
                backgroundColor: item.color,
              }}
            ></div>
          </div>
          <div className="comment-label">
            <span style={{ color: item.color }}>{item.label}</span>
            <span className="comment-percentage">
              {item.total > 0 ? ((item.value / item.total) * 100).toFixed(1) : 0}%
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TotalComments;
