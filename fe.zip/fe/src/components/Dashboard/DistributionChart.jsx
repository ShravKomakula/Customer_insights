import React, { useState, useEffect,useRef } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './DistributionChart.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const DistributionChart = ({ subThemeCounts = {},totalHCP, onSubThemeClick,selectedSubTheme,themecountTotal, activeTab, selectedTheme, isSubthemeClicked }) => {
  const [selectedLabel, setSelectedLabel] = useState(selectedTheme?.name || null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [selectedCount, setSelectedCount] = useState(selectedTheme?.count || 0);
  const [selectedPercentage, setSelectedPercentage] = useState(0);
  const [showBarChart, setShowBarChart] = useState(true); // New state to control bar chart visibility

  // Calculate total comments
  const labels = subThemeCounts ? Object.keys(subThemeCounts) : [];
  const dataValues = subThemeCounts ? Object.values(subThemeCounts) : [];
  const totalComments = dataValues.length > 0 ? dataValues.reduce((acc, value) => acc + value, 0) : 0;

  const refs = useRef({}); // Store refs for labels
  
  useEffect(() => {
    if (selectedTheme && totalComments > 0) {
      const percentage = ((selectedTheme.count * 100) / totalComments).toFixed(1);
      setSelectedPercentage(percentage);
    } else {
      setSelectedPercentage(0); // Default to 0 if no theme is selected or totalComments is 0
    }
  }, [selectedTheme, totalComments]);
  

  // Set default colors
  const defaultColors = ['#1e3a8a', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd'];
  const transparentColor = 'rgba(211, 211, 211, 0.5)';

 // Dynamically update colors based on selected segment with decreased opacity for non-clicked segments
const colors = labels.map((_, index) =>
  selectedIndex === null
    ? defaultColors[index % defaultColors.length]  // Show all segments in full color when no segment is selected
    : selectedIndex === index
    ? defaultColors[index % defaultColors.length]  // Keep clicked segment fully opaque
    : `${defaultColors[index % defaultColors.length]}80` // Reduce opacity of non-clicked segments
);


const percentages = dataValues.map(value => ((value / totalComments) * 100).toFixed(1)); // Calculate percentage

// Sort labels, values, and percentages in descending order based on values
const sortedSubThemes = labels
  .map((label, index) => ({ label, value: dataValues[index], percentage: percentages[index] }))
  .sort((a, b) => b.value - a.value); // Sort by value in descending order

// Extract sorted data
const sortedLabels = sortedSubThemes.map(item => item.label);
const sortedDataValues = sortedSubThemes.map(item => item.value);
const sortedPercentages = sortedSubThemes.map(item => item.percentage);

// Update donutData to use sorted values
const donutData = {
  labels: sortedLabels,
  datasets: [
    {
      data: sortedDataValues,
      backgroundColor: colors,
      hoverBackgroundColor: colors,
      borderWidth: 0,
      
    },
  ],
};
const donutOptions = {
  cutout: '70%',
  plugins: {
    legend: { display: false },
    tooltip: {
      enabled: false, // Disable default tooltip rendering
      external: function (context) {
        const tooltipModel = context.tooltip;
    
        // Get or create the tooltip element
        let tooltipEl = document.getElementById('chartjs-tooltip');
        if (!tooltipEl) {
          tooltipEl = document.createElement('div');
          tooltipEl.id = 'chartjs-tooltip';
          tooltipEl.style.position = 'absolute';
          tooltipEl.style.background = 'rgba(0, 0, 0, 0.8)';
          tooltipEl.style.color = '#fff';
          tooltipEl.style.padding = '8px';
          tooltipEl.style.borderRadius = '4px';
          tooltipEl.style.pointerEvents = 'none';
          tooltipEl.style.whiteSpace = 'nowrap';
          tooltipEl.style.fontSize = '12px';
          tooltipEl.style.zIndex = '9999';
          document.body.appendChild(tooltipEl);
        }
    
        // Hide tooltip if it's not visible
        if (tooltipModel.opacity === 0) {
          tooltipEl.style.opacity = 0;
          return;
        }
    
        // Set tooltip content with label and value
        if (tooltipModel.body) {
          const label = tooltipModel.dataPoints[0].label; // Get the label name
          const value = tooltipModel.dataPoints[0].raw;  // Get the value
          const percentage = totalComments > 0 ? ((value / totalComments) * 100).toFixed(1) : 0;
          const fullText = `${label}: ${value} (${percentage}%)`;
          
         
          // Wrap text manually
          const maxLineLength = 20; // Adjust this value to control line length
          const lines = [];
          let currentLine = '';
    
          fullText.split(' ').forEach((word) => {
            if ((currentLine + word).length > maxLineLength) {
              lines.push(currentLine);
              currentLine = word; // Start a new line
            } else {
              currentLine += (currentLine.length ? ' ' : '') + word; // Append word
            }
          });
    
          if (currentLine) lines.push(currentLine);
    
          tooltipEl.innerHTML = lines.map((line) => `<div>${line}</div>`).join('');
        }
    
        // Position the tooltip
        const chartPosition = context.chart.canvas.getBoundingClientRect();
        const tooltipX = chartPosition.left + window.scrollX + tooltipModel.caretX;
        const tooltipY = chartPosition.top + window.scrollY + tooltipModel.caretY;
    
        tooltipEl.style.opacity = 1;
        tooltipEl.style.left = `${tooltipX}px`;
        tooltipEl.style.top = `${tooltipY}px`;
      },
    },
      },
  onClick: (_, elements) => {
    if (elements.length > 0) {
      const index = elements[0].index;
      const label = sortedLabels[index]; // Match sortedLabels
      setSelectedIndex(index);
      setSelectedLabel(label);

      // Scroll to the corresponding label
      if (refs.current[label]) {
        refs.current[label].scrollIntoView({
          behavior: 'smooth',
          block: 'center',
        });
      }

      setSelectedCount(sortedDataValues[index]); // Match sortedDataValues
      const percentage = totalComments > 0
        ? ((sortedDataValues[index] * 100) / totalComments).toFixed(1)
        : 0;
      setSelectedPercentage(percentage);
      setShowBarChart(false);

      if (typeof onSubThemeClick === 'function') {
        onSubThemeClick(label);
      }
    }
  },
  elements: {
    arc: {
      borderWidth: 0,
    },
  },
};

const [lastClickTime, setLastClickTime] = useState(0);

const handleLabelClick = (label) => {
  const currentTime = Date.now();
  const timeDifference = currentTime - lastClickTime;

  if (timeDifference < 300) { // Double click
    setSelectedIndex(null);
    setSelectedLabel(null);
    setSelectedCount(0);
    setSelectedPercentage(0);
    setShowBarChart(true); // Show the bar chart on double-click
    onSubThemeClick(null); // Pass null for deselecting the subtheme
  } else { // Single click
    const index = sortedLabels.indexOf(label);
    if (index !== -1) {
      setSelectedIndex(index);
      setSelectedLabel(label);
      setSelectedCount(sortedDataValues[index]);
      const percentage = totalComments > 0 ? ((sortedDataValues[index] * 100) / totalComments).toFixed(1) : 0;
      setSelectedPercentage(percentage);
      setShowBarChart(false); // Hide bar chart on selection
      onSubThemeClick(label); // Trigger sub-theme click action
    }
  }

  setLastClickTime(currentTime); // Update last click time
};



const barlabelpercentage = totalHCP > 0 && totalComments > 0 
  ? ((totalComments / totalHCP) * 100).toFixed(1) 
  : 0;

  return (
    <div className="distribution-chart-container">
      {/* Conditionally render bar chart based on showBarChart state */}
      {showBarChart && (
        <div className="bar-chart1">
          <div className="bar-label1">
            
     <p>
{/* {barlabelpercentage}% */}{totalComments}
</p>

          </div>
          <div className="vertical-bar1">
            <div
              className="bar-fill1"
              style={{
                height: `${barlabelpercentage}%`,
                backgroundColor: '#0000ff',
           
              }}
            ></div>
          </div>
          <div className="bar-title1">
            <p>{activeTab}</p>
          </div>
        </div>
      ) }

      <div className='donut-comment-container '>
        <div className="title-container">
          Total Distribution of {activeTab} Comments
        </div>
        <div className="donut-comment-row">
          {labels.length > 0 ? (
            <>
              <div className="donut-chart">
                <Doughnut data={donutData} options={donutOptions} />
                <div className="donut-center-label">
                {selectedSubTheme ? (
    <>
  {/*     <p>{selectedPercentage}%</p> */}<p>{totalComments}</p>
      <span>comments</span>
    </>
  ) : (
    <>
      <p>{totalComments}</p>
      <span>Total Comments</span>
    </>
  )}
                </div>
              </div>

<div className="comment-list">
  {sortedLabels.map((label, index) => (
    <div
      key={index}
      ref={(el) => (refs.current[label] = el)} // Assign ref to each label
      className="comment-items"
      onClick={() => handleLabelClick(label)}
      style={{
        cursor: 'pointer',
        backgroundColor: selectedLabel === label ? 'rgba(1, 144, 255, 0.2)' : 'transparent',
        border: selectedLabel === label ? '2px solid #1e3a8a' : '1px solid rgba(211, 211, 211, 0.5)',
        borderRadius: '8px',
        padding: '5px 10px',
      }}
    >
      <div className="comment-labels" style={{ color: selectedLabel === label ? '#1e3a8a' : '#666' }}>
        <span
          className="dot"
          style={{
            backgroundColor: donutData.datasets[0].backgroundColor[index],
            marginRight: '5px',
          }}
        ></span>
        {label}
      </div>
      <span className="comment-values" style={{ fontWeight: selectedLabel === label ? 'bold' : 'normal' }}>
        {sortedDataValues[index]}
      </span>
    </div>
  ))}
</div>


            </>
          ) : (
            <p>No Data Available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default DistributionChart;
