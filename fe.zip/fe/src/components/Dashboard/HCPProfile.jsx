// HCPProfile.js
import React from 'react';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';
import './HCPProfile.css';
import hcp from '../LandingPageNew/svgIcons/HCPIcon.svg'
const HCPProfile = ({ data, totalHCP }) => {
  return (
    <div className="hcp-profile-container">
      <h6 className="hcp-profile-title">
     <img src={hcp} className='icon-doc'/> HCP Profile
      </h6>
      <div className="hcp-profile-content">
        <PieChart width={150} height={150}>
          {data.map((entry, index) => (
            <Pie
              key={index}
              data={[
                { name: entry.name, value: entry.value },
                { name: 'Remaining', value: totalHCP - entry.value },
              ]}
              cx="50%"
              cy="50%"
              innerRadius={35 + index * 15}
              outerRadius={45 + index * 15}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
            >
              <Cell fill={entry.color} />
              <Cell fill="#E0E0E0" />
            </Pie>
          ))}
          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="centered-text">
            <tspan x="50%" dy="-0.5em" fontSize="12px" fontWeight="bold">Total HCP</tspan>
            <tspan x="50%" dy="1.2em" fontSize="18px" fontWeight="bold">{totalHCP}</tspan>
          </text>
        </PieChart>
        <div className="hcp-legend">
  {data.map((entry, index) => (
    <div key={index} className="legend-item">
      <span className="legend-group">
        <span className="legend-color" style={{ backgroundColor: entry.color }}></span>
        <span>{entry.name}</span>
      </span>
      <span className="legend-value">{entry.value}</span>
    </div>
  ))}
</div>

      </div>
    </div>
  );
};

export default HCPProfile;
