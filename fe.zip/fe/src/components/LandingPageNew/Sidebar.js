import React, { useState, useEffect } from 'react';
import './Sidebar.css';
import { FaEllipsisH, FaRegFileAlt } from 'react-icons/fa';
import axios from 'axios';
import newchatIcon from './svgIcons/newchatIcon.svg';
import { useNavigate } from 'react-router-dom';

function Sidebar({ onSelectQuery, refreshQueries }) {
  const [activeIndex, setActiveIndex] = useState(null);
  const [queries, setQueries] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Function to fetch past queries from the API
  const fetchPastQueries = async () => {
    const email = localStorage.getItem('email');
    if (!email) {
      setError('User email not found. Please log in.');
      return;
    }

    const encodedEmail = encodeURIComponent(email);
    const url = `https://emcustomerinsights.pfizer.com/backend/service/past_queries/${encodedEmail}`;

    try {
      const response = await axios.get(url);
      if (response.data.status === 'success') {
        // Sort queries by timestamp (latest first)
        const sortedQueries = response.data.past_queries.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        setQueries(sortedQueries);
      } else {
        setError('Failed to fetch past queries.');
      }
    } catch (error) {
      console.error('Error fetching past queries:', error);
      setError('No past queries found.');
    }
  };

  // Re-fetch queries when the component mounts, and automatically reload every 30 seconds
  useEffect(() => {
    fetchPastQueries();  // Initial fetch

    // Set up an interval to reload queries periodically (e.g., every 30 seconds)
    const intervalId = setInterval(() => {
      fetchPastQueries();
    }, 10000); // 10 seconds

    // Clear the interval when the component is unmounted
    return () => clearInterval(intervalId);
  }, [refreshQueries]);  // Trigger fetch when `refreshQueries` is updated

  const handleQueryClick = (queryData) => {
    console.log('Query Data:', queryData); // Debug output
    onSelectQuery({
        query: queryData.query,
        country: queryData.country,
        response: queryData.response, // Ensure this is correct
        rating: queryData.rating,
        isPastQuery: true,
    });
};


  const handleNewChatClick = () => {
     // Trigger a reload of past queries after 2 seconds
     setTimeout(() => {
      fetchPastQueries(); // Fetch the past queries
    }, 1000); // 1-second delay
    navigate('/NewChat'); // Navigate to NewChatScreen on click
  
   
  };
  

  return (
    <aside className="sidebar">
      <div className="newchat-heading" onClick={handleNewChatClick}>
        <h3>
          <img src={newchatIcon} alt="newchatIcon" /> <span>Start New Chat</span>
        </h3>
      </div>
      <div className="sidebar-header">
        <h3>Past Queries</h3>
      </div>
      {error ? (
        <p className="error-message">{error}</p>
      ) : (
        <ul className="query-list">
          {queries.length > 0 ? (
            queries.map((queryData, index) => (
              <li
                key={index}
                className={`query-item ${activeIndex === index ? 'active' : ''}`}
                onClick={() => handleQueryClick({ ...queryData, index })}
              >
                <FaRegFileAlt className="document-icon" />
                <div className="query-text">
                  <p>{queryData.query}</p>
                </div>
              </li>
            ))
          ) : (
            <p className="loadingPastQueries">Loading past queries...</p>
          )}
        </ul>
      )}
    </aside>
  );
}

export default Sidebar;
