// useQueryHandler.js
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const predefinedQuestions = [
  `What is the count and percentage of potential customers in segment A who are classified as 'Omnichannel Pro'?`,
  "What is the count and percentage of sentiments in segment A and B combined?",
"What is count and percentage of cardiologists who are Omnichannel Pro ?",
    "What is the distribution of customer segments?"
];

function useQueryHandler() {
  const [queryMode, setQueryMode] = useState('Insight Mode');
  const [selectedCountry, setSelectedCountry] = useState('MX');
  const [selectedQuery, setSelectedQuery] = useState('');
  const [selectedRating, setSelectedRating] = useState('');
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const navigate = useNavigate();

  const handleSendQuery = (mode) => {
    if (!selectedQuery.trim()) {
      toast.warn('Please enter a query');
      return;
    }

    // Make sure the mode is passed here
    const queryData = {
      query: selectedQuery.trim(),
      country: selectedCountry,
      mode: mode || queryMode,  // Ensure mode is passed (fallback to state if undefined)
      rating: selectedRating,
      answer: selectedAnswer,
    };

    navigate('/results', { state: queryData });  // Pass queryData to results page

    // Clear the input field after navigation
    setSelectedQuery('');  // Clear query
  };

  const handlePastQuerySelection = (queryData) => {
    const { query, country, response, rating } = queryData;
    navigate('/results', {
        state: {
            query,
            country,
            rating,
            response, // Pass the response field explicitly
            isPastQuery: true, // Indicate this is a past query
        },
    });
};


  return {
    queryMode,
    setQueryMode,
    selectedCountry,
    setSelectedCountry,
    selectedQuery,
    setSelectedQuery,
    selectedRating,
    setSelectedRating,
    selectedAnswer,
    setSelectedAnswer,
    handleSendQuery,
    predefinedQuestions,
    handlePastQuerySelection,
  };
}


export default useQueryHandler;
