// Header.js
import React, { useState } from 'react';
import './Header.css';
import PfizerLogo from "../../assets/images/Logo_3-removebg-preview 1 (1).svg";
import userAvthar from './svgIcons/userAvthar.svg';
import { FaBell, FaSearch, FaCircle } from 'react-icons/fa'; // Importing icons including the dot icon
import { useNavigate } from "react-router-dom";
import signOut from "./svgIcons/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
import { IoHomeOutline } from "react-icons/io5";
import { Link, useLocation } from 'react-router-dom'; // Import Link and useLocation from react-router-dom


function Header() {
  const location = useLocation(); // Get current location
  const [activeLink, setActiveLink] = useState(location.pathname); // Set initial active link based on current path

  // Update active link on click
  const handleLinkClick = (path) => {
    setActiveLink(path);
  }; const navigate = useNavigate();
    const goToLanding = () => {
        navigate("/");
      };
      
    const { logout } = useAuth();

    const handleLogout = () => {
      try {
          logout(); // Execute the logout functionality
      } catch (error) {
          console.error("Error during logout:", error); // Handle errors gracefully
      }
  };
  
  return (
    <>
      {/* Header */}
      <header className="header">
        <div className="logo-container">
          <img src={PfizerLogo} alt='pfizer logo' className="logo"     onClick={goToLanding} />
          <span className="header-title">EM CUSTOMER INSIGHTS</span>
        </div>
        <div className="user-profile">
<IoHomeOutline className='homeIcon'  onClick={goToLanding}  style={{width:'20px',height:'20px'}} />Home{/* home icon */}
          <FaSearch className="icon" /> {/* Search Icon */}
          <FaBell className="icon" />   {/* Bell Icon */}
          <span className='userName'>{localStorage.getItem("userName")}</span>
         {/*  <img src={userAvthar} alt="User Avatar" /> */}
         <img className='logoutIcon'
                style={{ marginLeft: "10px", cursor: "pointer" }}
                src={signOut}
                onClick={() => handleLogout()}
                alt="logout Icon"
              />
        </div>
      </header>

      {/* Navigation Links Section */}
      <div className="nav-section">
        <nav className="nav-links">
          <Link
            to="/"
            className={`nav-item ${activeLink === '/' ? 'active' : ''}`}
            onClick={() => handleLinkClick('/')}
          >
            {activeLink === '/' && <FaCircle className="bullet-icon" />}
            Dashboard
          </Link>
          <Link
            to="/chatBot"
            className={`nav-item ${activeLink === '/chatBot' ? 'active' : ''}`}
            onClick={() => handleLinkClick('/chatBot')}
          >
            {activeLink === '/chatBot' && <FaCircle className="bullet-icon" />}
            Customer Insight Bot
          </Link>
        </nav>
      </div>
    </>
  );
}

export default Header;
