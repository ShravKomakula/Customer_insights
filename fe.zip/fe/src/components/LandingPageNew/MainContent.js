import React, { useState, useEffect } from 'react';
import './MainContent.css';
import PfizerIcon from './svgIcons/pfizerIocn.svg';
import SendIcon from './svgIcons/sendbutton.svg';
import SearchIcon from './svgIcons/search.svg';
import docIcon from './svgIcons/docIcon.svg';
import LocationIcon from './svgIcons/LocationIcon.svg';
import useQueryHandler from './useQueryHandler';

function MainContent({ selectedQuery, onSelectQuery, selectedCountry, onSelectCountry, onSendQuery }) {
  const { queryMode, setQueryMode, predefinedQuestions } = useQueryHandler();

  // Handle query mode change to clear the input for Database Mode
  useEffect(() => {
    if (queryMode === 'Database Mode') {
      onSelectQuery(''); // Clear the input when switching to Database Mode
    }
  }, [queryMode, onSelectQuery]);

  const handleQueryClick = (query) => {
    onSelectQuery(query); // Pass the selected query to the parent
  };

  const handleSendClick = () => {
    onSendQuery(queryMode); // Pass queryMode when clicked
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      onSendQuery(queryMode); // Ensure queryMode is passed
    }
  };

  return (
    <main className="main-content">
      <img src={PfizerIcon} alt="Pfizer Logo" className="pfizer-icon" />
      <h1 className="heading">Hello, {localStorage.getItem('userName')}..!</h1>
      <p className="subheading">How can we help you today?</p>
      <p className="line">Here are some popular queries for you to start</p>

      <div className="popular-queries">
        <div className="query-tile" onClick={() => handleQueryClick("Are there specific patient populations that physicians believe face greater challenges in accessing medications and vaccines? If so, what are the reasons behind these challenges?")}>
          <img src={docIcon} alt="doc icon" className="doc-icon" />
          <p className="popularQuery">Are there specific patient populations that physicians believe face greater challenges in accessing medications and vaccines? If so, what are the reasons behind these challenges?</p>
        </div>
        <div className="query-tile" onClick={() => handleQueryClick("How do physicians perceive the impact of insurance coverage and reimbursement policies on patient access to medications and vaccines?")}>
          <img src={docIcon} alt="doc icon" className="doc-icon" />
          <p className="popularQuery">How do physicians perceive the impact of insurance coverage and reimbursement policies on patient access to medications and vaccines?</p>
        </div>
        <div className="query-tile" onClick={() => handleQueryClick("What are the main barriers that physicians perceive in terms of patient adherence to medication regimens?")}>
          <img src={docIcon} alt="doc icon" className="doc-icon" />
          <p className="popularQuery">What are the main barriers that physicians perceive in terms of patient adherence to medication regimens?</p>
        </div>
      </div>

      {/* Scope Information Box */}
      <div className="scope-info">
        <p>
          Current scope of this chatbot covers only specific Therapeutic Areas (TAs) and Themes:<br />
          For <strong>Mexico</strong>: TAs covered are Vaccines, Covid & Migraine. Themes are restricted to Access, Treatment & Diagnosis.<br />
          For <strong>Brazil</strong>: TAs covered are Atrial Fibrillation, VTE & Covid. Themes are restricted to Access, Treatment & Adherence.<br />
          Other areas are out of scope as of now.
        </p>
      </div>

      <div className="search-bar">
        <div className="search-bar-container1">
          <select
            className="query-mode-select"
            value={queryMode}
            onChange={(e) => setQueryMode(e.target.value)}
          >
            <option value="Insight Mode">Insight Mode</option>
            <option value="Database Mode">Database Mode</option>
          </select>
          <img src={LocationIcon} alt="Location Icon" className="icon" />
          <select
            className="country-select"
            value={selectedCountry}
            onChange={(e) => onSelectCountry(e.target.value)}
          >
            <option value="MX">Mexico</option>
            <option value="BR">Brazil</option>
            <option value="All">All</option>
          </select>

          <div className="search-input">
            <img src={SearchIcon} alt="search" className="search-icon" />
            {queryMode === 'Database Mode' ? (
              <select
                className="search-input"
                style={{ fontSize: '12px' }}
                value={selectedQuery}
                onChange={(e) => onSelectQuery(e.target.value)}
              >
                <option value="" disabled>
                  Select a question
                </option>
                {predefinedQuestions.map((question, index) => (
                  <option key={index} value={question}>
                    {question}
                  </option>
                ))}
              </select>
            ) : (
              <input
                type="text"
                placeholder="Type your question..."
                value={selectedQuery}
                style={{ fontSize: '12px' }}
                onChange={(e) => onSelectQuery(e.target.value)}
                onKeyDown={handleKeyDown}
              />
            )}
          </div>

          <img src={SendIcon} alt="sendIcon" className="send-icon" onClick={handleSendClick} />
        </div>

        <p className="Disclaimer-text">Insights generated by AI may not be fully accurate. Use with discretion.</p>
      </div>
    </main>
  );
}

export default MainContent;
