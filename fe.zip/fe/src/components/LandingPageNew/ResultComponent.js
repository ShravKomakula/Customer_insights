import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import './ResultComponent.css';
import Header from './Header';
import Sidebar from './Sidebar';
import LocationIcon from './svgIcons/LocationIcon.svg';
import starIcon from './svgIcons/starIcon.svg';
import starFillIcon from './svgIcons/starFillIcon.svg';
import copyIcon from './svgIcons/copyIcon.svg';
import reloadIcon from './svgIcons/reloadIcon.svg';
import sendIcon from './svgIcons/sendIcon.svg';
import searchIcon from './svgIcons/search.svg';
import successIcon from './svgIcons/successIcon.svg';
import { RotatingLines } from 'react-loader-spinner';
import PfizerIcon from './svgIcons/pfizerwhiteicon.svg';
import { toast } from 'react-toastify';
import useQueryHandler from './useQueryHandler';
function ResultComponent() {
  const location = useLocation();
  const { query: initialQuery = '', country: initialCountry = 'MX', mode: initialMode = 'Insight Mode' } = location.state || {};


  // Set initial country based on navigation state
  const [country, setCountry] = useState(initialCountry);
  
const [queryMode, setQueryMode] = useState(initialMode); // Set initial query mode based on navigation state
const [refreshQueries, setRefreshQueries] = useState(false);

  const [results, setResults] = useState([]);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [feedbackVisibleIndex, setFeedbackVisibleIndex] = useState(null); // Track which feedback section is visible
  const [feedbackSubmittedIndex, setFeedbackSubmittedIndex] = useState(null);
  const lastResultRef = useRef(null);
  const {
   
    predefinedQuestions, // Access predefined questions here
  } = useQueryHandler();
  const [query, setQuery] = useState('');
  // Define local states for query handling
  const [selectedQuery, setSelectedQuery] = useState(initialQuery || ''); // Initialize with initialQuery if available
 
  
  // Define local handler functions
  const onSelectQuery = (query) => setSelectedQuery(query);
/*   const onSendQuery = (mode) => {
    if (selectedQuery.trim()) {
      console.log("Sending query:", selectedQuery);
  
        handleSendQuery(mode); // Pass mode to handleSendQuery
    
      
      // Add query handling logic here, e.g., API call
    } else {
      console.warn("Query is empty");
    }
  }; */


  const addQueryToResults = (searchQuery) => {
    setResults((prevResults) => [
      ...prevResults,
      { query: searchQuery, answer: null, loading: true, rating: 0 },
    ]);
    fetchResult(searchQuery, country, results.length);
  };
  
  useEffect(() => {
    //console.log('Location state on initial load:', location.state); // Debug output
    if (initialQuery) {
        setSelectedQuery('');
        if (location.state?.isPastQuery) {
            const { response, rating, country } = location.state;
            if (response) {
                //console.log('Past query detected. Response:', response); // Debug
                setResults((prevResults) => [
                    ...prevResults,
                    {
                        query: initialQuery,
                        answer: response, // Add response directly to results
                        rating: rating || 0,
                        country,
                        loading: false,
                    },
                ]);
            } else {
                console.warn('Response is undefined for past query.');
            }
        } else {
            //console.log('New query detected. Fetching results...');
            addQueryToResults(initialQuery);
        }
    }
}, [initialQuery, initialCountry, location.state]);

const handlePastQuerySelection = (queryData) => {
  const { query, response, rating, country } = queryData;

  setResults((prevResults) => [
      ...prevResults,
      {
          query,
          answer: response, // Use `response` for the answer
          rating: rating || 0,
          country,
          loading: false,
      },
  ]);
  setCountry(country);

  // Scroll to the last result after selection
  setTimeout(() => {
      if (lastResultRef.current) {
          lastResultRef.current.scrollIntoView({ behavior: 'smooth' });
      }
  }, 100);
};
const cleanAnswer = (answer) => {
  if (!answer) return '';

  return answer
    .replace(/\*\*Overall Response:\*\*/g, 'Overall Response:')
    .replace(/\*\*Response:\*\*/g, 'Overall Response:')
    .replace(/\*\*/g, '') // Remove asterisks around the text
    .replace(/\\n/g, '\n') // Convert escaped newlines
    .replace(/\n/g, '<br />') // Convert actual newlines to <br />
    .replace(/Citation[s]?:/gi, '<br /><span class="blue-text"><b>Citations:</b></span>') // Handle Citation or Citations
    .replace(/\((\d+(?:,\s*\d+)*)\)/g, (match, p1) => {
      // Match any set of numbers inside parentheses and style them
      const numbers = p1.split(',').map(num => num.trim()).join(', ');
      return `<span class="blue-text">(${numbers})</span>`;
    });
};

  
  const handleFeedbackThanksClick = (index) => {
    // Hide feedback container and thank you message
    setFeedbackSubmittedIndex(null);
    setFeedbackVisibleIndex(null);
  };
  const fetchResult = async (searchQuery, searchCountry, index, rating, comment, regenerate = false) => {
    try {
      const email = localStorage.getItem('email');
      if (!email) {
        alert("User email is missing. Please log in.");
        return;
      }
  
      let url, payload;
      if (queryMode === 'Insight Mode') {
        url = 'https://emcustomerinsights.pfizer.com/backend/service/generate_answer';
        payload = {
          query: searchQuery,
          country: searchCountry,
          email: email,
          regenerate: regenerate, // Set regenerate to true for reload, false for initial generation
        };
      } else if (queryMode === 'Database Mode') {
        url = 'https://emcustomerinsights.pfizer.com/backend/service/query_answer';
        payload = {
          user_query: searchQuery,
          country: searchCountry,
          email: email,
        };
      }
  
      const response = await axios.post(url, payload);
      //console.log("API Response:", response.data);
  
      if (queryMode === 'Insight Mode' && response.data.status === 'success') {
        setResults((prevResults) =>
          prevResults.map((item, idx) =>
            idx === index ? { ...item, answer: response.data.answer, loading: false } : item
          )
        );
  
        // Automatically trigger the feedback API after response is received
        if (response.data.answer) {
          submitFeedbackAPI(
            searchQuery,  // The query that was searched
            response.data.answer,  // The response data
            rating,  // Dynamic rating
            comment,  // Dynamic comment
            searchCountry,  // Country
            queryMode  // Mode
          );
        }
  
      } else if (queryMode === 'Database Mode' && response.data.answer) {
        const parsedAnswer = JSON.parse(response.data.answer)?.Answer || response.data.answer;
  
        setResults((prevResults) =>
          prevResults.map((item, idx) =>
            idx === index ? { ...item, answer: parsedAnswer, loading: false } : item
          )
        );
  
        // Automatically trigger the feedback API after response is received
        if (parsedAnswer) {
          submitFeedbackAPI(
            searchQuery,  // The query that was searched
            parsedAnswer,  // The response data
            rating,  // Dynamic rating
            comment,  // Dynamic comment
            searchCountry,  // Country
            queryMode  // Mode
          );
        }
      } else {
        console.warn('Unexpected response format:', response.data);
        alert('Error fetching result');
      }
    } catch (error) {
      console.error('Error fetching result:', error);
      alert('Error fetching result');
    }
  };
  
  
  const submitFeedbackAPI = async (query, response, rating, comment, country, mode) => {
    try {
      const email = localStorage.getItem('email');
      if (!email) {
        alert('User email is missing. Please log in.');
        return;
      }
  
      const url = 'https://emcustomerinsights.pfizer.com/backend/service/submit_feedback'; // Make sure the endpoint is correct
      const payload = {
        email: email,  // User email from local storage
        query: query,  // The query that was sent to the API
        response: response,  // The response received from the API
        rating: rating,  // The rating given by the user
        comment: comment,  // User's comment for the feedback
        country: country,  // Country info
        mode: mode,  // Mode (Insight Mode or Database Mode)
      };
  
      const responseAPI = await axios.post(url, payload);
      
      if (responseAPI.data.status === 'success') {
        //console.log('query loader successfully!');
      } else {
        //console.log('Failed to load result.');
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast.error('Error submitting feedback.');
    }
  };
  
  
  const handleSendQuery = () => {
    if (selectedQuery.trim()) {
      addQueryToResults(selectedQuery);
      setSelectedQuery(''); 
      setQuery(''); 
      
      // Scroll to the last result after adding a new query
      setTimeout(() => {
        if (lastResultRef.current) {
          lastResultRef.current.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      console.warn("Query is empty");
    }
  };

  const handleFeedbackSubmit = async (index) => {
    if (!feedback.trim()) {
      toast.warn("Please enter your feedback.");
      return;
    }
  
    const email = localStorage.getItem('email'); // Ensure this is set
    if (!email) {
      toast.error("User email is missing. Please log in.");
      return;
    }
  
    const currentTimestamp = new Date().toISOString(); // Get current timestamp
    const queryData = results[index];
  
    // Updated payload with mode
    const payload = {
      email: email,
      query: queryData.query,
      response: queryData.answer,
      rating: queryData.rating,
      comment: feedback,
      country: country,
      timestamp: currentTimestamp, // Include timestamp
      mode: queryMode, // Include mode (Insight Mode / Database Mode)
    };
  
    //console.log("Submitting feedback with payload:", payload);
  
    try {
      const response = await axios.post('https://emcustomerinsights.pfizer.com/backend/service/update_feedback', payload);
  
      if (response.data.status === 'success') {
        setFeedbackSubmittedIndex(index); // Show thank you message
        setFeedback(''); // Clear feedback input
        toast.success("Feedback submitted successfully.");
  
        // After successful feedback submission, trigger the refresh of past queries
        setRefreshQueries(!refreshQueries);  // Toggle refreshQueries to re-fetch the queries
      } else {
        toast.error("Error submitting feedback. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
  
      if (error.response && error.response.status === 422) {
        toast.error("Failed to submit feedback. Please check the payload structure.");
      } else {
        toast.error("Error submitting feedback. Please try again.");
      }
    }
  };
  
  const handleRatingClick = (index, ratingValue) => {
    setResults((prevResults) =>
      prevResults.map((item, idx) =>
        idx === index ? { ...item, rating: ratingValue } : item
      )
    );
    setFeedbackVisibleIndex(index); // Set the feedback section to be visible for this answer
  };

  const handleCopy = (answer, index) => {
    navigator.clipboard.writeText(answer).then(() => {
      setCopiedIndex(index);
    });
  };
  const handleReload = (queryToReload, index) => {
    setResults((prevResults) => [
      ...prevResults,
      { query: queryToReload, answer: null, loading: true, rating: 0 },
    ]);
    fetchResult(queryToReload, country, results.length, null, null, true);  // Pass regenerate: true for reload
    // Scroll to the last result after reload
    setTimeout(() => {
      if (lastResultRef.current) {
        lastResultRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };
  

  return (
    <div className="app-container">
      <Header />
      <div className="content-wrapper">
        <Sidebar onSelectQuery={(queryData) => handlePastQuerySelection(queryData)} />
        <div className="result-container">
          <div className="query-result-container">
            {results.map((item, index) => (
              <div key={index} className="result-section" ref={index === results.length - 1 ? lastResultRef : null}>
                <div className="question-container">
                  <div className="queryText">{item.query}</div>
                </div>
                {item.loading ? (
                  <div className="loader-container1" style={{ textAlign: 'center', margin: '20px 0' }}>
                    <RotatingLines width="40" strokeColor="#0190FF" />
                  </div>
                ) : (
                  <div className="d-flex flex-row align-items-start mt-3 answer-container mb-3">
                    <img src={PfizerIcon} alt="Pfizer Icon" className="pfizerIcon" />
                    <div className="answerText">
                      <p dangerouslySetInnerHTML={{ __html: cleanAnswer(item.answer) }}></p>
                      <hr />
                      <div className="actionIcons">
                        {[1, 2, 3, 4, 5].map((star, idx) => (
                          <img
                            key={idx}
                            src={item.rating >= star ? starFillIcon : starIcon}
                            className="starIcon"
                            alt={`Star ${star}`}
                            onClick={() => handleRatingClick(index, star)}
                          />
                        ))}
                        <img
                          src={copiedIndex === index ? successIcon : copyIcon}
                          alt="Copy"
                          className="icon"
                          onClick={() => handleCopy(item.answer, index)}
                        />
                        <img
                          src={reloadIcon}
                          alt="Reload"
                          className="icon"
                          onClick={() => handleReload(item.query)}
                        />
                      </div>
                      <div className="feedback-section">
  {feedbackVisibleIndex === index && feedbackSubmittedIndex !== index ? (
    <div className="feedback-container">
      <h5 className="comment-heading">Tell us, how could we do better?</h5>
      <textarea
        value={feedback}
        onChange={(e) => setFeedback(e.target.value)}
        placeholder="Enter your comments here..."
        rows="3"
        className="feedback-input"
      ></textarea>
    <div style={{textAlign:'right'}}>
    <button
        className="feedback-submit-btn"
        onClick={() => handleFeedbackSubmit(index)}
      >
        Submit Feedback
      </button>
      </div>
    </div>
  ) : feedbackSubmittedIndex === index ? (
    <div
      className="feedback-thanks"
      onClick={() => handleFeedbackThanksClick(index)}
    >
      Thank you for your feedback!
    </div>
  ) : null}
</div>


                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="search-bar-container1">
            <select
              className="query-select"
              value={queryMode}
              onChange={(e) => setQueryMode(e.target.value)}
            >
              <option value="Insight Mode">Insight Mode</option>
              <option value="Database Mode">Database Mode</option>
            </select>

            <div className="country-select-wrapper">
              <img src={LocationIcon} alt="Location Icon" className="icon" />
              <select
                className="country-select"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
              >
                <option value="BR">Brazil</option>
                <option value="MX">Mexico</option>
                <option value="All">All</option>
              </select>
            </div>

            <div className="divider"></div>

            <div className="search-input-wrapper">
              <img src={searchIcon} alt="Search Icon" className="icon" />
              {queryMode === 'Database Mode' ? (
              <select
                className="search-input"
                value={selectedQuery}  style={{fontSize:'12px'}}
                onChange={(e) => onSelectQuery(e.target.value)}
              >
                <option value=""style={{fontSize:'12px'}}>Select a question</option>
                {predefinedQuestions.map((question, index) => (
                  <option key={index} value={question}  style={{fontSize:'12px'}}>{question}</option>
                ))}
              </select>
            ) : (
              <input 
              type="text" 
              placeholder="Type your question..."   style={{fontSize:'12px'}}
              value={selectedQuery} // Bind input to selectedQuery
              onChange={(e) => setSelectedQuery(e.target.value)} 
              onKeyDown={(e) => e.key === 'Enter' && handleSendQuery()} 
            />
            
            
            )}
         {/*    <img src={MicIcon} alt="mic" className="mic-icon" /> */}
         
            </div>

            <img src={sendIcon} className="send-icon" alt="Send" onClick={handleSendQuery} />
          </div>
          <p className="Disclaimer-text">Insights generated by AI may not be fully accurate. Use with discretion.</p>
        </div>
      </div>
    </div>
  );
}

export default ResultComponent;  