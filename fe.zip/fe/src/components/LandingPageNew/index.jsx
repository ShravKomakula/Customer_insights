// LandingPageNew.js
import React from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import MainContent from './MainContent';
import './LandingPageNew.css';
import useQueryHandler from './useQueryHandler';

function LandingPageNew() {
  
  const {
    queryMode,
    setQueryMode,
    selectedCountry,
    setSelectedCountry,
    selectedQuery,
    setSelectedQuery,
    handleSendQuery,
    handlePastQuerySelection,
  } = useQueryHandler(); // Use the custom hook for shared logic

  return (
    <div className="app-container">
      <Header />
      <div className="content-wrapper">
        <Sidebar onSelectQuery={handlePastQuerySelection} />
        <MainContent 
          selectedQuery={selectedQuery}
          onSelectQuery={setSelectedQuery}
          selectedCountry={selectedCountry}
          onSelectCountry={setSelectedCountry}
          queryMode={queryMode}
          setQueryMode={setQueryMode}
          onSendQuery={handleSendQuery}
        />
      </div>
    </div>
  );
}

export default LandingPageNew;
