import { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'react-toastify';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(null); // Initially null to check loading state

  useEffect(() => {
    // Sync authentication status with localStorage on mount
    const storedAuth = localStorage.getItem('authenticated') === 'true';
    setAuthenticated(storedAuth);  // Set the authentication state from localStorage
  }, []);

  const handleLoginSuccess = (email, userName, navigate) => {
    setAuthenticated(true);
    localStorage.setItem('authenticated', true);
    localStorage.setItem('email', email);
    localStorage.setItem('userName', userName);
    toast.success('Logged in successfully', { position: toast.POSITION.TOP_CENTER });
    navigate('/'); // Navigate to home
  };
 
  const email = localStorage.getItem('email');
  const userName = localStorage.getItem('userName');
  const isAuthenticated = localStorage.getItem('authenticated') === 'true';
  
  console.log('Email:', email);
  console.log('User Name:', userName);
  console.log('Is Authenticated:', isAuthenticated);
  
  const login = (email, password, navigate, firstname = '') => {
    const userCredentials = [
      { email: 'shravani.komakula@pfizer.com', password: 'Admin@123', name: 'Shravani' },
      { email: 'nithin.makkina@pfizer.com', password: 'Admin@123', name: 'Nithin' },
      { email: 'sainath.kumar@pfizer.com', password: 'Admin@123', name: 'Sainath' },
      { email: 'subba.chaparala@pfizer.com', password: 'Admin@123', name: 'Subba' },
      { email: 'sampath.basa@pfizer.com', password: 'Admin@123', name: 'Sampath' },
      { email: 'rinisha.mohammed@pfizer.com', password: 'Admin@123', name: 'Rinisha' },
      { email: 'rupesh.nehra@pfizer.com', password: 'Admin@123', name: 'Rupesh' },
      { email: 'deependra.singh@pfizer.com', password: 'User.Pfizer@123', name: 'Deependra' },
      { email: 'vinayak.sg@pfizer.com', password: 'Admin@123', name: 'Vinayak' },
      { email: 'vinayramdhani.gupta@pfizer.com', password: 'Admin@123', name: 'Vinay' },
      { email: 'nikhilkumar.mishra@pfizer.com', password: 'Admin@123', name: 'Nikhil' },
      { email: 'Anna.Batur@Pfizer.com', password: 'User.Pfizer@123', name: 'Anna Batur' },
      { email: 'Cal.Austin@pfizer.com', password: 'User.Pfizer@123', name: 'Cal Austin' },
      { email: 'JuanPablo.Caricatti@pfizer.com', password: 'User.Pfizer@123', name: 'Juan Pablo' },
      { email: 'CarlosHumberto.Zavala@pfizer.com', password: 'User.Pfizer@123', name: 'Carlos Zavala' },
      { email: 'claudio.terra@pfizer.com', password: 'User.Pfizer@123', name: 'Claudio Terra' },
      { email: 'Carlos.E.Valente@pfizer.com', password: 'User.Pfizer@123', name: 'Carlos Valente' },
      { email: 'Michele.PavoniAldoney@pfizer.com', password: 'User.Pfizer@123', name: 'Michele Pavoni' },
      { email: 'Lucas.SilvanoAnselmoDorsa@pfizer.com', password: 'User.Pfizer@123', name: 'Lucas Dorsa' },
      { email: 'flavio.maruyama@pfizer.com', password: 'User.Pfizer@123', name: 'Flavio' },
      { email: 'daniel.gonzalez2@pfizer.com', password: 'User.Pfizer@123', name: 'Daniel Gonzalez' },
      { email: 'fernando.alvarez2@pfizer.com', password: 'User.Pfizer@123', name: 'Fernando Alvarez' },
    
    ];
   
  
   
   
   
   
    const user = userCredentials.find(u => u.email === email && u.password === password);

    if (user) {
      handleLoginSuccess(user.email, user.name, navigate);
    } else if (password === 'ssologin') {
      handleLoginSuccess(email, firstname, navigate);
    } else {
      toast.warning('Please provide valid Email & Password', { position: toast.POSITION.TOP_CENTER });
    }
  };

  const logout = (navigate) => {
    setAuthenticated(false);
    localStorage.removeItem('authenticated');
    localStorage.removeItem('email');
    localStorage.removeItem('userName');
    toast.success('Logged out successfully', { position: toast.POSITION.TOP_CENTER });
    navigate('/login', { replace: true });
  };

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {authenticated === null ? null : children} {/* Render children only when auth is set */}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
