const BASIC_GATEWAY = "https://emcustomerinsights.pfizer.com/backend/service/";
export const GetSsoTokenOauth2 = (code) => (`${BASIC_GATEWAY}token_oauth2?code=${code}`)
export const ValidateSsoOauth2 = (token) => (`${BASIC_GATEWAY}validate_oauth2?token=${token}`)
export const RefreshTokenEndpoint =(refresh_token) => (`${BASIC_GATEWAY}refresh_oauth2?refresh_token=${refresh_token}`)
