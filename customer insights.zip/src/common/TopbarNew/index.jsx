import React from 'react';
import { FaRegBell,FaSearch, FaUserCheck } from 'react-icons/fa';
import './TopbarNew.css';
import { useNavigate } from "react-router-dom";
import imageTheia from "../../assets/images/Logo_3-removebg-preview 1 (1).svg";
import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
/* import { RevokeTokenEndPoint } from '../api-config'; */
import axios from 'axios';

const TopbarNew = () => {
    const navigate = useNavigate();
    const goToLanding = () => {
        navigate("/");
      };
/* 
  const revokeToken = async () => {
    try {
      const accessToken = JSON.parse(localStorage.access_token).tokenInfo.access_token;
      await axios.post(RevokeTokenEndPoint, { token: accessToken });
      localStorage.removeItem("access_token"); // Remove the access token from localStorage after revoking
    } catch (error) {
      console.error("Error revoking token", error);
      throw error;
    }
  };
 */

    const { logout } = useAuth();

    const handleLogout = () => {
    /*   revokeToken(); */
        logout()
    }
    return (
      <div className='top-section'>
          <div className="header w-100 justify-content-between p-1">
        <div className="logo-section d-flex flex-row align-items-center">
         
          <img
            src={imageTheia}
            alt="imageTheia"
            className="ml-3"
            onClick={goToLanding}
            style={{ height: "50px", cursor: "pointer" }}
          /> 
          <span className='top-title'>EM Customer Insight</span>
        </div>

        <div className="d-flex flex-row align-items-center">
          <FaRegBell />&nbsp;&nbsp;&nbsp;&nbsp;
          <FaSearch />
          <div className="user-account" style={{ display: "flex" }}>
            <div
              className="ml-3 TopbarNew-text"
              style={{ marginTop: "3px", marginRight: "5px" }}
            >
              {localStorage.getItem("userName")}
            </div>

            <div>
            <FaUserCheck size={25}/>

              <img
                style={{ marginLeft: "10px", cursor: "pointer" }}
                src={signOut}
                onClick={() => handleLogout()}
                alt="User Icon"
              />
            </div>
          </div>
        </div>
      </div>
    
      </div>

    )
}

export default TopbarNew;