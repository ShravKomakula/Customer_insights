
import { createContext, useContext, useState } from 'react';
import { toast } from 'react-toastify';


const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(localStorage.getItem('authenticated') === 'true');

  const login = (email, password, navigate,firstname='') => {
    console.log("login callled");
   if(email === "komakula.shravani@pfizer.com"&& password === "Admin@123"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Shravani")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/');
  } else if(email === "nithin.makkina@pfizer.com"&& password === "Admin@123"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Nithin")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/');

  }
else if(email === "admin@pfizer.com"&& password === "Admin@123"){
  setAuthenticated(true)
  localStorage.setItem("authenticated", true)
  localStorage.setItem("email", email)
  localStorage.setItem("userName", "Admin")
  toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
  navigate('/');
}else if(password==="ssologin"){
  console.log("SSO logedIn");
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", firstname)
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate("/", { replace: true });
  /*   setTimeout(() => {
      console.log("login....");
      navigate("/", { replace: true });
  }, 2000); //  */
   
  }
   else {
      toast.warning("Please provide valid Email & Password", { position: toast.POSITION.TOP_CENTER });
  }

  };

  const logout = (navigate) => {
    setAuthenticated(false)
    localStorage.removeItem('authenticated');
    localStorage.clear()
    navigate("/login",{ replace: true })
  };

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
