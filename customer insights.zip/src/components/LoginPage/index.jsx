import React, {useState} from 'react';
import './loginPage.css';
import google from '../../assets/images/flat-color-icons_google.svg';
import microsoft from '../../assets/images/logos_microsoft-icon.svg';
import eyeIcon from '../../assets/images/eye-password.svg';
import apple from '../../assets/images/teenyicons_apple-solid.svg';
import robot from '../../assets/images/chatgpt robot sad.svg';
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';


const Login = () => {
    const [showPassword,setShowpassword] = useState(false)
    const list = [
        {
            icon: google,
            name: "Google"
        },
        {
            icon: microsoft,
            name: "Microsoft"
        },
        {
            icon: apple,
            name: "Apple"
        }
    ]
    return (
        <div className='login-container'>
        <div className="content-wrapper">
            <img src={logo} alt="logo" className="logo" />
            <div className="login-font-400">
                Discover the best of&nbsp;
                <span className='landingPage-font-600 landing-hr'>Pfizer</span> &nbsp;
                with&nbsp;
                <span className='landingPage-font-600 landing-hr'>Pfizer search</span>&nbsp;
                <img src={robot} alt="robot" className="robot-icon" />
            </div>
            <div className='login-font-300'>
                The AI Assistant that guides you to be faster, stronger and better
            </div>
            <div className='login-box'>
                <div className='login-text-1'>Login....</div>
                <div className='flex-col mt-15'>
                    <label className='login-email text-align'>Email Address</label>
                    <input type="text" className='login-input mt-1' placeholder='Ex abc@email.com'/>
                </div>
                <div className='flex-col mt-15'>
                    <label className='login-email text-align'>Password</label>
                    <div className='login-position-relative'>
                    <input type={showPassword? "text": "password"} className='login-input mt-1' placeholder='**********'/>
                    <img src={eyeIcon} alt="password" className='login-password-eyeIcon'/>
                    </div>
                </div>
                <div className='login-row flex-space-between mt-15'>
                    <div className='login-row'>
                        <input type="checkbox" />
                        <div className='login-email'>&nbsp;Remember me</div>
                    </div>
                    <div className='login-forgot'>
                        Forgot Password
                    </div>
                </div>
                <button className='login-button mt-15' >
                    Login
                </button>
                <button className='login-button mt-15' >
                    Login With SSO
                </button>
                <div className='dashed-line-container'>
                    <div className='dashed-line'></div>
                    <div className='login-text-2'>&nbsp;&nbsp;or&nbsp;&nbsp;</div>
                    <div className='dashed-line-1'></div>
                </div>
                <div className="login-row flex-space-between mt-5">
                    {
                        list.map((item) => (
                            <div className="login-row list-view">
                                <img src={item.icon} alt="icons"/>
                                <div>&nbsp;&nbsp;{item.name}</div>
                            </div>
                        ))
                    }
                </div>
            </div>
        </div>
        <div className='background-section'>
            <div className='background-top'></div>
            <div className='background-bottom'></div>
        </div>
    </div>
    )
}

export default Login;