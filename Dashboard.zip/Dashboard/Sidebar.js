import React, { useState } from 'react';
import './Sidebar.css';

const Sidebar = () => {
  const [activeCategory, setActiveCategory] = useState('Treatment');
  const categories = [
    'Treatment', 'Medical Education', 'Awareness', 'Diagnosis & Referral',
    'Adherence', 'Access', 'Marketing', 'Vaccination', 'Product Quality', 'Others'
  ];

  const handleCategoryClick = (category) => {
    setActiveCategory(category);
  };

  return (
    <div className="sidebar">
      {categories.map((category, index) => (
        <div
          key={index}
          className={`category-tab ${category === activeCategory ? 'active' : ''}`}
          onClick={() => handleCategoryClick(category)}
        >
          {category}
        </div>
      ))}
    </div>
  );
};

export default Sidebar;
