import React from 'react';
import './OmnichannelProfile.css';

const OmnichannelProfile = () => {
  const profiles = [
    { label: 'Digital Enthusiast', count: 150, percentage: 36, color: '#0000b2' },
    { label: 'Omnichannel Pro', count: 72, percentage: 22, color: '#7e3af2' },
    { label: 'Traditionalist', count: 65, percentage: 20, color: '#4f46e5' },
    { label: 'F2F Hybrid Adapter', count: 66, percentage: 20, color: '#0284c7' },
  ];

  return (
    <div className="omnichannel-profile-container">
      <h4 className="omnichannel-profile-title">
        <span className="icon">🔗</span> Omnichannel Profile
      </h4>
      <div className="profile-grid">
        {profiles.map((profile, index) => (
          <div
            key={index}
            className="profile-box"
            style={{ backgroundColor: profile.color }}
          >
            <div className="profile-label">
              <span className="dot" style={{ backgroundColor: '#ffffff' }}></span>
              {profile.label}
            </div>
            <div className="profile-count">{profile.count}</div>
            <div className="profile-percentage">{profile.percentage}%</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OmnichannelProfile;
