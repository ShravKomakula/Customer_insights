import React from 'react';
import { useParams } from 'react-router-dom';
import FilterBar from './FilterBar';
import CategoryTabs from './CategoryTabs';
import DistributionChart from './DistributionChart';
import TotalComments from './TotalComments';
import OmnichannelProfile from './OmnichannelProfile';
import HCPSegments from './HCPSegments';
import Summary from './Summary';
import Header from '../LandingPageNew/Header';
import './CategoryDetails.css';

const CategoryDetails = () => {
  const { category } = useParams();

  return (
    <div className="category-details-container">
        <Header/>
      <FilterBar />
      <h2 className="category-title">Total Distribution for {category}</h2>

    <div className='body-category'>
    <CategoryTabs />

<div className="content-section">
  {/* Left side with Distribution Chart */}
  <div className="main-chart">
    <h3>Total Distribution of {category} Comments</h3>
    <DistributionChart />
  </div>

  {/* Right side with 2x2 grid */}
  <div className="grid-section">
    <div className="tall-component">
      <TotalComments />
    </div>
    <div className="tall-component">
      <OmnichannelProfile />
    </div>
    <div className="tall-component">
      <HCPSegments />
    </div>
    <div className="tall-component summary-scroll">
      <Summary />
    </div>
  </div>
</div>
    </div>
    </div>
  );
};

export default CategoryDetails;
