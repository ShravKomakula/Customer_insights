import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './DistributionChart.css';

// Register the required components
ChartJS.register(ArcElement, Tooltip, Legend);

const DistributionChart = () => {
  // Data for the donut chart
  const donutData = {
    labels: ['Treatment Access Support', 'Hospital Infection', 'Reheuma Treatment Access', 'NOAC Treatment Access', 'Complicated Cases'],
    datasets: [
      {
        data: [192, 128, 96, 160, 64],
        backgroundColor: ['#1e3a8a', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd'],
        hoverBackgroundColor: ['#1e3a8a', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd'],
        borderWidth: 0,
      },
    ],
  };

  const donutOptions = {
    cutout: '70%', // Creates the donut effect
    plugins: {
      legend: { display: false },
    },
  };

  return (
    <div className="distribution-chart-container">
    <div className="bar-chart">
      {/* Left vertical bar */}
      <div className="vertical-bar">
        <span className="bar-label">20%</span>
        <div className="bar-fill" style={{ height: '60%', backgroundColor: '#000093' }}></div>
        <p className="bar-title">Treatment</p>
      </div>
    </div>
  
    {/* Combined donut and comment list section with title inside */}
    <div className="donut-comment-container">
      <div className="title-container">
        Total Distribution of Treatment Comments
      </div>
      <div className="donut-comment-row">
        <div className="donut-chart">
          <Doughnut data={donutData} options={donutOptions} />
          <div className="donut-center-label">
            <p>640</p>
            <span>Total Treatment Comments</span>
          </div>
        </div>
        <div className="comment-list">
          {donutData.labels.map((label, index) => (
            <div key={index} className="comment-items">
              <div className="comment-labels">
                <span className="dot" style={{ backgroundColor: donutData.datasets[0].backgroundColor[index] }}></span>
                {label}
              </div>
              <span className="comment-values">{donutData.datasets[0].data[index]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
  
  
  );
};

export default DistributionChart;
