import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './HCPSegments.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const HCPSegments = () => {
  const data = {
    labels: ['Segment A', 'Segment B', 'Others'],
    datasets: [
      {
        data: [80, 56, 70],
        backgroundColor: ['#0000b2', '#3b82f6', '#93c5fd'],
        hoverBackgroundColor: ['#0000b2', '#3b82f6', '#93c5fd'],
        borderWidth: 0,
      },
    ],
  };

  const options = {
    cutout: '80%',
    rotation: -90,
    circumference: 180,
    plugins: {
      legend: {
        display: false,
      },
    },
  };

  return (
    <div className="hcp-segments-container">
      <h4 className="hcp-segments-title">
        <span className="icon">👤</span> HCP Segments
      </h4>
      <div className="hcp-donut-chart">
        <Doughnut data={data} options={options} />
        <div className="hcp-center-label">
          <p>206</p>
          <span>Total HCP</span>
        </div>
      </div>
      <div className="hcp-legend">
        {data.labels.map((label, index) => (
          <div key={index} className="hcp-legend-item">
            <span
              className="hcp-dot"
              style={{ backgroundColor: data.datasets[0].backgroundColor[index] }}
            ></span>
            <span className="hcp-label">{label}</span>
            <span className="hcp-value">{data.datasets[0].data[index]}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HCPSegments;
