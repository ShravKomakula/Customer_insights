import React from 'react';
import { useNavigate } from 'react-router-dom';
import './CommentsDistribution.css';

const CommentsDistribution = () => {
  const navigate = useNavigate();

  const barData = [
    { label: 'Treatment', value: 80, color: '#000093' },
    { label: 'Medical Education', value: 60, color: '#000093' },
    { label: 'Awareness', value: 50, color: '#000093' },
    { label: 'Diagnosis & Referral', value: 45, color: '#000093' },
    { label: 'Adherence', value: 35, color: '#000093' },
    { label: 'Access', value: 85, color: '#000093' },
    { label: 'Marketing', value: 95, color: '#000093' },
    { label: 'Vaccination', value: 30, color: '#000093' },
    { label: 'Product Quality', value: 15, color: '#000093' },
    { label: 'Others', value: 10, color: '#000093' },
  ];

  const handleBarClick = (label) => {
    navigate(`/category/${label}`);
  };

  return (
    <div className="comments-distribution-container">
      <h5 className="chart-title">Comments Distribution Across Key Categories of Treatment</h5>
      <div className="bar-chart">
        {barData.map((data, index) => (
          <div key={index} className="bar-container" onClick={() => handleBarClick(data.label)}>
            <p className="bar-percentage">{data.value}%</p>
            <div className="bar-wrapper">
              <div
                className="bar-fill"
                style={{
                  height: `${data.value}%`,
                  backgroundColor: data.color,
                }}
              ></div>
            </div>
            <span className="bar-label">{data.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentsDistribution;
