import React from 'react';
import './TotalComments.css';

const TotalComments = () => {
  const data = [
    { label: 'Positives', value: 300, total: 640, color: '#2563eb', percentage: 50 },
    { label: 'Neutral', value: 240, total: 640, color: '#f97316', percentage: 37 },
    { label: 'Negatives', value: 100, total: 640, color: '#b91c1c', percentage: 15 },
  ];

  return (
    <div className="total-comments-container">
      <h4 className="total-comments-title">
        <span className="icon">💬</span> Total Comments
      </h4>
      {data.map((item, index) => (
        <div key={index} className="comment-item">
          <div className="comment-value">
            <span className="comment-count">{item.value}</span> / {item.total}
          </div>
          <div className="progress-bar-container">
            <div
              className="progress-bar"
              style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
            ></div>
          </div>
          <div className="comment-label">
            <span style={{ color: item.color }}>{item.label}</span>
            <span className="comment-percentage">{item.percentage}%</span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TotalComments;
