import React from 'react';
import './SentimentDistribution.css';

const data = [
  { label: 'Positive', value: 1500, total: 3200, color: '#4caf50', percentage: '47%' },
  { label: 'Neutral', value: 1200, total: 3200, color: '#ff9800', percentage: '37%' },
  { label: 'Negative', value: 500, total: 3200, color: '#f44336', percentage: '15%' },
];

const SentimentDistribution = () => {
  return (
    <div className="sentiment-container">
      <h6 className="sentiment-title">
        <span className="icon">💬</span> Sentiment Distribution of Comments
      </h6>
      {data.map((item, index) => (
        <div key={index} className="sentiment-item">
          <div className="sentiment-label">
            <span className="sentiment-value">{item.value} / {item.total}</span>
          </div>
          <div className="sentiment-bar-container">
            <div className="sentiment-bar">
              <div
                className="bar-fill"
                style={{
                  width: `${(item.value / item.total) * 100}%`,
                  backgroundColor: item.color,
                }}
              ></div>
            </div>
            <span className="sentiment-percentage">{item.percentage}</span>
          </div>
        </div>
      ))}
      <div className="updated-date">Updated Last Month</div>
    </div>
  );
};

export default SentimentDistribution;
