import React from 'react';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';
import './HCPProfile.css';

const data = [
  { name: 'Segment A', value: 300, color: '#1E3A8A' }, // Reduced value for Segment A
  { name: 'Segment B', value: 500, color: '#3B82F6' }, // Medium blue
  { name: 'Others', value: 300, color: '#93C5FD' },    // Light blue
];

const totalHCP = data.reduce((sum, entry) => sum + entry.value, 0);

const HCPProfile = () => {
  return (
    <div className="hcp-profile-container">
      <h6 className="hcp-profile-title">
        <span className="icon">👤</span> HCP Profile
      </h6>
      <div className="hcp-profile-content">
        <PieChart width={150} height={150}>
          <Pie
            data={[
              { name: 'Others', value: data[2].value },
              { name: 'Remaining', value: totalHCP - data[2].value },
            ]}
            cx="50%"
            cy="50%"
            innerRadius={35}
            outerRadius={45}
            dataKey="value"
            startAngle={90}
            endAngle={-270}
          >
            <Cell fill={data[2].color} />
            <Cell fill="#E0E0E0" />
          </Pie>

          <Pie
            data={[
              { name: 'Segment B', value: data[1].value },
              { name: 'Remaining', value: totalHCP - data[1].value },
            ]}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={60}
            dataKey="value"
            startAngle={90}
            endAngle={-270}
          >
            <Cell fill={data[1].color} />
            <Cell fill="#E0E0E0" />
          </Pie>

          <Pie
            data={[
              { name: 'Segment A', value: data[0].value }, // Reduced Segment A value
              { name: 'Remaining', value: totalHCP - data[0].value },
            ]}
            cx="50%"
            cy="50%"
            innerRadius={65}
            outerRadius={75}
            dataKey="value"
            startAngle={90}
            endAngle={-270}
          >
            <Cell fill={data[0].color} />
            <Cell fill="#E0E0E0" />
          </Pie>

          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="centered-text">
            <tspan x="50%" dy="-0.5em" fontSize="12px" fontWeight="bold">Total HCP</tspan>
            <tspan x="50%" dy="1.2em" fontSize="18px" fontWeight="bold">{totalHCP}</tspan>
          </text>
        </PieChart>
        <div className="hcp-legend">
          {data.map((entry, index) => (
            <div key={index} className="legend-item">
              <span className="legend-color" style={{ backgroundColor: entry.color }}></span>
              <span>{entry.name}</span>&nbsp;
              <span className="legend-value">{entry.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HCPProfile;
