import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CategoryTabs.css';

const CategoryTabs = () => {
  const navigate = useNavigate();
  const categories = [
    'Treatment',
    'Medical Education',
    'Awareness',
    'Diagnosis & Referral',
    'Adherence',
    'Access',
    'Marketing',
    'Vaccination',
    'Product Quality',
    'Others',
  ];

  const [activeTab, setActiveTab] = useState('Treatment');

  const handleTabClick = (category) => {
    setActiveTab(category);
    navigate(`/category/${category}`);
  };

  return (
    <div className="category-tabs">
      {categories.map((category) => (
        <div
          key={category}
          className={`tab-item ${activeTab === category ? 'active' : ''}`}
          onClick={() => handleTabClick(category)}
        >
          {category}
        </div>
      ))}
    </div>
  );
};

export default CategoryTabs;
