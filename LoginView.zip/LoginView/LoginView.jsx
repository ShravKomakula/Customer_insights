import React, { useState, useEffect } from 'react';
import './LoginView.css';
import leftlogo from './sideimage.svg';
import logo from './../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
import { useAuth } from '../AuthContext';
import { useNavigate } from "react-router-dom";
import { GetSsoTokenOauth2, ValidateSsoOauth2 } from '../../common/api-config';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { ThreeDots } from 'react-loader-spinner';
 import frame from './sideimage.svg';
function Login() {
    const [params, setParams] = useSearchParams();
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
 
    useEffect(() => {
        const code = params.get('code');
        if (code) {
            handleSsoLogin(code);
        }
    }, [params]);
 
    const handleSsoLogin = async (code) => {
        setLoading(true);
        try {
            const ssoTokenResponse = await axios.post(GetSsoTokenOauth2(code), { code: code });
            if (ssoTokenResponse && ssoTokenResponse.status === 200) {
                const validateTokenResponse = await axios.post(ValidateSsoOauth2(ssoTokenResponse.data.data.access_token), {});
                localStorage.setItem("access_token", JSON.stringify({
                    loginType: 'SSO',
                    tokenInfo: ssoTokenResponse.data.data,
                    userInfo: validateTokenResponse.data.data,
                }));
                setLoading(false);
                console.log("Login successful, navigating to /",validateTokenResponse);
                login(validateTokenResponse.data.data.access_token.mail, "ssologin", navigate, validateTokenResponse.data.data.access_token.firstname);
               
            } else {
                console.error("Error in SSO token response");
                setLoading(false);
            }
        } catch (error) {
            console.error("Error", error);
            setLoading(false);
        }
    };
 
    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
 
    const handleLoginWithAd = () => {
        console.log("SSO button clicked");
        const oauthUrl = `https://devfederate.pfizer.com/as/authorization.oauth2?client_id=theia_client&grant_type=authorization_code&response_type=code&scope=edit`;
        window.location.href = oauthUrl;
    };
 
    const handleLogin = () => {
        login(email, password, navigate);
    }
 
    return (
<div class="split-screen-wrapper">
    <img src={logo}  class="logo"  ></img>
    <div class="left-side">
<div className='mt-4 '>
    <h2><strong>Log in...</strong></h2>
    <span className='ash'>Welcome back ! Please enter your details.</span><br></br>
    <label className="txt-label-mt mt-4">Email</label>
                                        <input
                                            type="text"
                                            placeholder='Ex abc@email.com'
                                            className="form-control input-item-fill"
                                            onChange={(event) => setEmail(event.target.value)} value={email}
                                        />
                                         <label className="txt-label-mt mt-2">Password</label>
                                        <input
                                            type={showPassword ? "text" : "password"}
                                            placeholder='**********'
                                            className="form-control input-item-fill"
                                            onChange={(event) => setPassword(event.target.value)} value={password}
                                        />
                                        <div className='d-flex align-items-center justify-content-between mt-3'>
                                       <div className='d-flex align-items-center'>
                                        <input
                                                            className="form-check-input-2"
                                                            type="checkbox"
                                                            name="remember"
                                                        />{" "}
<span style={{fontSize:'12px'}} >   Remember for 30 days</span>    
</div>      
                                              <div className="text-end">
                                                    <a className="forgot-pwd">
                                                        Forgot password?
                                                    </a>
                                                </div>
                                        </div>
                                        <div>
                                        <button
                                            type="button"
                                            className="shadeButton btn-lg btn-block"
                                            onClick={handleLogin}
                                        >
                                            Signin
                                        </button>
                                        </div>
                                        <div className="form-group text-center mt-3">
                                        <span className="account-an-txt">
                                            Don't have an account?
                                        </span>
                                        <button
                                            type="button"
                                            className="button-signup"
                                        >
                                            Sign Up
                                        </button>
                                    </div>
</div>
    </div>
    {/* <div class="right-side"> */}
        <div>
    <img src={leftlogo} alt="Image Description" />
    {/* </div> */}
</div>
 
</div>
 
 
 
    );
}
 
export default Login;
 
 