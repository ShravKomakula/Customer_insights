import React, { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import './Donut.css';

const TreatmentChart = () => {
  const data = {
    labels: [
      'Treatment Access Support',
      'Hospital Infection',
      'Rehumea Treatment Access',
      'NOAC Treatment Access',
      'Complicated Cases',
    ],
    datasets: [
      {
        data: [2448, 422, 399, 204, 99], // Updated values
        backgroundColor: [
          '#14B8A6', // Treatment Access Support
          '#35AAF3', // Hospital Infection
          '#6366F1', // Rehumea Treatment Access
          '#F59E0B', // NOAC Treatment Access
          '#FED530', // Complicated Cases
        ],
        hoverBackgroundColor: [
          '#14B8A6',
          '#35AAF3',
          '#6366F1',
          '#F59E0B',
          '#FED530',
        ],
      },
    ],
  };

  const lighterColors = [
    '#d2f7f3', // Light color for Treatment Access Support
    '#cfe8f8', // Light color for Hospital Infection
    '#cecff7', // Light color for Rehumea Treatment Access
    '#f6edde', // Light color for NOAC Treatment Access
    '#f4edd1', // Light color for Complicated Cases
  ];

  const summaries = {
    'Treatment Access Support': `Summary for Treatment Access Support.`,
    'Hospital Infection': `Summary for Hospital Infection.`,
    'Rehumea Treatment Access': `Summary for Rehumea Treatment Access.`,
    'NOAC Treatment Access': `Summary for NOAC Treatment Access.`,
    'Complicated Cases': `Summary for Complicated Cases.`,
  };

  const [selectedLabel, setSelectedLabel] = useState('');
  const [selectedSummary, setSelectedSummary] = useState('');
  const [activeIndex, setActiveIndex] = useState(null);
  const [chartSize, setChartSize] = useState({ width: '200px', height: '200px' });

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
    },
    cutout: '60%',
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        handleLabelClick(index, data.labels[index]);
      }
    },
  };

  const handleLabelClick = (index, label) => {
    setSelectedLabel(label);
    setSelectedSummary(summaries[label]);
    setActiveIndex(index);

    // Adjust chart size on label click
    setChartSize({ width: '150px', height: '150px' }); // Decrease chart size
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#fff',marginTop:'-35px',borderRadius: '10px', boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)' }}>
        <h6 style={{ textAlign: 'left',borderBottom:'1px solid #ccc',padding:'5px'}}>Sub Category </h6>
 
      <div style={{ display: 'flex', justifyContent: 'center', width: '100%', backgroundColor: '#fff', padding: '10px' }}>
        <div style={{ ...chartSize, position: 'relative' }}>
          <Doughnut
            data={{
              ...data,
              datasets: [
                {
                  ...data.datasets[0],
                  backgroundColor: data.datasets[0].backgroundColor.map((color, index) =>
                    activeIndex === null
                      ? color
                      : index === activeIndex
                      ? color
                      : `${color}30`
                  ),
                },
              ],
            }}
            options={options}
          />
          <div
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              color: '#000',
            }}
          >
            <h2 style={{ margin: '0', fontSize: '20px' }}>Brazil</h2>
            <h3 style={{ margin: '0', fontSize: '30px' }}>95 %</h3>
          </div>
        </div>
        <div style={{ marginLeft: '20px', width: '200px', fontSize: '10px' }}> {/* Decreased font size */}
          <ul style={{ listStyleType: 'none', padding: 0 }}>
            {data.labels.map((label, index) => (
              <li
                key={label}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  border: 'none',
                  cursor: 'pointer',
                  margin: '2px 0', // Decreased margin to reduce gap
                  color: '#000',
                  backgroundColor: activeIndex === index ? lighterColors[index] : 'transparent',
                }}
                onClick={() => handleLabelClick(index, label)}
                role="button"
                tabIndex={0}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleLabelClick(index, label);
                  }
                }}
              >
                <span
                  style={{
                    display: 'inline-block',
                    width: '10px',
                    height: '10px',
                    backgroundColor: data.datasets[0].backgroundColor[index],
                    borderRadius: '50%',
                    marginRight: '8px',
                  }}
                ></span>
                {label} <span style={{ marginLeft: 'auto' }}>{data.datasets[0].data[index].toLocaleString()}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      {selectedSummary && (
        <div style={{ marginTop: '20px', padding: '10px', borderRadius: '5px', backgroundColor: '#F7F7F7' }}>
          <h6>Summary of {selectedLabel}</h6>
          <p style={{ fontSize: '12px', textAlign: 'justify' }}>{selectedSummary}</p>
        </div>
      )}
    </div>
  );
};

export default TreatmentChart;
