import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Dashboard.css';
import TopbarNew from "../../common/TopbarNew";
import closeIcon from './closeIcon.svg';
import Barchart from "./Barchart";
import { Bar } from 'react-chartjs-2';
import { Dialog, DialogTitle, DialogContent, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

import 'chart.js/auto';
import {
  Button,
  ButtonGroup,
  Popover,
  Checkbox,
  FormControlLabel,
  Typography,
} from '@mui/material';

const Dashboard = () => {
  const [dialogBackgroundColor, setDialogBackgroundColor] = useState('#ffffff'); // Default color

  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("dashboard");
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedCountries, setSelectedCountries] = useState(['Brazil']);
  const [tempSelectedCountries, setTempSelectedCountries] = useState([...selectedCountries]);
  const [countryFilter, setCountryFilter] = useState('Brazil');
  const [selectedBarIndex, setSelectedBarIndex] = useState(null);
  const countries = ['India', 'Brazil', 'Mexico'];
  const [open, setOpen] = useState(false);
  const handleButtonClick = (event, filterType) => {
    if (filterType === 'country') {
      setAnchorEl(event.currentTarget);
      setTempSelectedCountries([...selectedCountries]);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleClose1 = () => {
    setOpen(null);
  };
  const handleCountryChange = (event) => {
    const value = event.target.value;
    setTempSelectedCountries((prev) =>
      prev.includes(value) ? prev.filter((c) => c !== value) : [...prev, value]
    );
  };

  const applyFilter = () => {
    const finalSelectedCountries = tempSelectedCountries.length > 0
      ? tempSelectedCountries
      : ['Brazil'];
  
    setSelectedCountries(finalSelectedCountries);
  
    if (finalSelectedCountries.length > 1) {
      setCountryFilter(`${finalSelectedCountries.length} Selected`);
    } else if (finalSelectedCountries.length === 1) {
      setCountryFilter(finalSelectedCountries[0]);
    } else {
      setCountryFilter('Brazil');
    }
  
    handleClose();
  };

  const getButtonBackgroundColor = () => {
    if (selectedCountries.length > 1) {
      return '#0190FF1A';
    }

    switch (selectedCountries[0]) {
      case 'Brazil':
        return '#9F84F433';
      case 'India':
        return '#7AAAE133';
      case 'Mexico':
        return '#F882402B';
      default:
        return 'white';
    }
  };


  const barChartData = {
    labels: ['Treatment', 'Infrastructure', 'Diagnosis & Referral', 'Awareness', 'Adherence', 'Access', 'Marketing', 'Others'],
    datasets: [
      {
        label: 'Bar Chart',
        data: [47, 20, 42, 40, 25, 15, 30, 10],
        backgroundColor: (context) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
  
          if (!chartArea) return;
  
          const colors = [
            ['#A68AFF', '#645399'],
            ['#FF8642', '#995028'],
            ['#35B6FF', '#206D99'],
            ['#29CCB4', '#15665A'],
            ['#EF8AFF', '#8F5399'],
            ['#FFDE8A', '#998553'],
            ['#8AC0FF', '#537399'],
            ['#FF8A8A', '#995353'],
          ];
  
          const index = context.dataIndex; // Get the index of the current data point
          const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
          gradient.addColorStop(0, colors[index][1]); // Start color
          gradient.addColorStop(1, colors[index][0]); // End color
          return gradient;
        },
        borderRadius: 5,
        barThickness: 40,
      },
    ],
  };
  
  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: { display: false },
      datalabels: {
        anchor: 'end',
        align: 'end',
        offset: 2,
        formatter: (value) => value,  // Show the value on the bar
        color: '#000',  // Color of the value text
        font: {
          weight: 'bold',
        },
      },
    },
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        setSelectedBarIndex(index);
        const colors = [
          ['#e8e2fc','#cec9dd'],
          ['#fdf5f1', '#f7e7dd'],
          ['#e5f3fc', '#206D99'],
          ['#dbf9f5', '#15665A'],
          ['#f4edf5', '#8F5399'],
          ['#ece9e2', '#998553'],
          ['#d8e0eb', '#537399'],
          ['#f1eded', '#995353'],
        ];
        setDialogBackgroundColor(colors[index][0]); 
        setOpen(true); // Open dialog on bar click
      }
    },
    scales: {
      x: {
        display: true,
        grid: {
          display: false,
        },
        border: {
          display: false,
        },
        barPercentage: 0.5, // Adjust this value for bar width
        categoryPercentage: 7.4, // Adjust this value for the spacing between categories
      },
      y: {
        display: false,
        min: 0,
        max: 50,
        grid: {
          display: false,
        },
        border: {
          display: false,
        },
        ticks: {
          callback: (value) => value,
        },
      },
    },
  };
  
  
  const label = 'Treatment Access Support';
  const value = 2448;




  return (
    <div className="homepage-container">
      <TopbarNew />
      <div className="link-sections">
        <ul className="link-group d-flex flex-row align-items-center">
          <li
            className={`dashboard ${activeSection === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/dashboard")}
          >
            Dashboard
          </li>
          <li
            className={`chatbot ${activeSection === "chatpage" ? "active" : ""}`}
            onClick={() => navigate("/chatbot")}
          >
            Customer Insight Bot
          </li>
        </ul>
      </div>

      <div className="Dashboard-content">
        <div className="input-section">
          <ButtonGroup fullWidth>
            <Button
              variant="contained"
              style={{
                color: 'black',
                flex: 1,
                justifyContent: 'space-between',
              }}
              onClick={(event) => handleButtonClick(event, 'country')}
              className="whitebg-btn country-btn"
            >
              <Typography variant="body1">Country</Typography>
              <Typography variant="body1" style={{ marginLeft: 'auto', padding: '5px 10px', borderRadius: '5px', backgroundColor: getButtonBackgroundColor() }}>
                {countryFilter}
              </Typography>
            </Button>
            <Button
              variant="contained"
              style={{ backgroundColor: 'white', color: 'black', flex: 1, justifyContent: 'flex-start' }}
              onClick={() => handleButtonClick(null, 'speciality')}
              className="whitebg-btn speciality-btn"
            >
              <Typography variant="body1">Speciality</Typography>
            </Button>
            <Button
              variant="contained"
              style={{ backgroundColor: 'white', color: 'black', flex: 1, justifyContent: 'flex-start' }}
              onClick={() => handleButtonClick(null, 'city')}
              className="whitebg-btn city-btn"
            >
              <Typography variant="body1">City</Typography>
            </Button>
          </ButtonGroup>
        </div>

        {Boolean(anchorEl) && (
          <div
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              width: '100vw',
              height: '100vh',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              zIndex: 1,
            }}
          ></div>
        )}

        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          style={{ marginTop: '10px', zIndex: 2 }}
        >
          <div style={{ position: 'relative', padding: '10px', backgroundColor: '#faf8f8', width: '250px' }}>
            <Button 
              onClick={handleClose} 
              style={{ 
                position: 'absolute', 
                top: 0, 
                right: 0, 
                padding: '5px', 
                minWidth: '30px', 
                fontSize: '16px' 
              }}>
              <img src={closeIcon} alt="close icon" className="closeIcon"/>
            </Button>

            <Typography variant="h6" style={{marginBottom:'20px'}}>Countries</Typography>
            <span>Select Country</span>

            {countries.map((country) => (
              <ul key={country}>
                <li className="countryList" style={{padding:'0px'}}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={tempSelectedCountries.includes(country)}
                        onChange={handleCountryChange}
                        value={country}
                        style={{paddingLeft:'20px'}}
                        className="checkboxSize"
                      />
                    }
                    label={country}
                  />
                </li>
              </ul>
            ))}

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
              <Button onClick={applyFilter} color="primary" className="ApplyFilter">
                Apply Filter
              </Button>
            </div>
          </div>
        </Popover>

        <div className="bar-chart-section" style={{ backgroundColor: 'white', padding: '20px', borderRadius: '10px',width:'100%'}}>
          <span>Total Distribution for {countryFilter}</span>
          <Bar data={barChartData} options={barChartOptions} />
        </div>
        <Dialog open={open} onClose={handleClose1} maxWidth="sm" className="dialoguue-content"   PaperProps={{
            style: { backgroundColor: dialogBackgroundColor }, // Set the background color dynamically
          }} >
        <DialogTitle>
        <Typography variant="body1" style={{borderBottom:'1px solid #ccc',padding:'5px'}}>
            <strong>Sub Catagory of {barChartData.labels[selectedBarIndex]}:</strong>
          </Typography>
          <IconButton
            aria-label="close"
            onClick={handleClose1}
            style={{ position: 'absolute', right: 8, top: 8, color: '#000' }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
       
        <DialogContent className="Dooughnut-section"> 
        <Barchart label={label} value={value} />
        </DialogContent>
  
       
      </Dialog>
      </div>

    </div>
  );
};

export default Dashboard;
