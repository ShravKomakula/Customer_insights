import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Dashboard.css';
import TopbarNew from "../../common/TopbarNew";
import closeIcon from './closeIcon.svg';
import CloseIcon from '@mui/icons-material/Close'; // Ensure you import CloseIcon
import Barchart from './Barchart'; // Assuming you have a Barchart component
import {
  Button,
  ButtonGroup,
  Popover,
  Checkbox,
  FormControlLabel,
  Typography,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
} from '@mui/material';
// Barchart.js or wherever you're defining your charts
import { Chart, ArcElement, Tooltip, Legend } from 'chart.js';

// Register the necessary components
Chart.register(ArcElement, Tooltip, Legend);

const Dashboard = () => {
  const [selectedBar, setSelectedBar] = useState(null);
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("dashboard");
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedCountries, setSelectedCountries] = useState(['Brazil']);
  const [tempSelectedCountries, setTempSelectedCountries] = useState([...selectedCountries]);
  const [countryFilter, setCountryFilter] = useState('Brazil');
  const countries = ['India', 'Brazil', 'Mexico'];
  const [open, setOpen] = useState(false);
  const [selectedBarIndex, setSelectedBarIndex] = useState(null); // Track selected bar index

  const handleButtonClick = (event, filterType) => {
    if (filterType === 'country') {
      setAnchorEl(event.currentTarget);
      setTempSelectedCountries([...selectedCountries]);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleCountryChange = (event) => {
    const value = event.target.value;
    setTempSelectedCountries((prev) =>
      prev.includes(value) ? prev.filter((c) => c !== value) : [...prev, value]
    );
  };


  const applyFilter = () => {
    const finalSelectedCountries = tempSelectedCountries.length > 0
      ? tempSelectedCountries
      : ['Brazil'];
  
    setSelectedCountries(finalSelectedCountries);
  
    if (finalSelectedCountries.length > 1) {
      setCountryFilter(`${finalSelectedCountries.length} Selected`);
    } else if (finalSelectedCountries.length === 1) {
      setCountryFilter(finalSelectedCountries[0]);
    } else {
      setCountryFilter('Brazil');
    }
  
    handleClose();
  };

  const getButtonBackgroundColor = () => {
    if (selectedCountries.length > 1) {
      return '#0190FF1A';
    }

    switch (selectedCountries[0]) {
      case 'Brazil':
        return '#9F84F433';
      case 'India':
        return '#7AAAE133';
      case 'Mexico':
        return '#F882402B';
      default:
        return 'white';
    }
  };


  const barData = [
    { label: 'Treatment', value: 47, color: ['#A68AFF', '#645399'] },
    { label: 'Infrastructure', value: 20, color: ['#FF8642', '#995028'] },
    { label: 'Diagnosis & Referral', value: 42, color: ['#35B6FF', '#206D99'] },
    { label: 'Awareness', value: 40, color: ['#29CCB4', '#15665A'] },
    { label: 'Adherence', value: 25, color: ['#EF8AFF', '#8F5399'] },
    { label: 'Access', value: 15, color: ['#FFDE8A', '#998553'] },
    { label: 'Marketing', value: 30, color: ['#8AC0FF', '#537399'] },
    { label: 'Others', value: 10, color: ['#FF8A8A', '#995353'] },
  ];

  const handleBarClick = (index) => {
    if (selectedBar === index) {
      setSelectedBar(null); // Reset selection if the same bar is clicked
    } else {
      setSelectedBar(index); // Select a bar
      setSelectedBarIndex(index); // Set the selected bar index
    }
  };
  const hexToRgb = (hex) => {
    const bigint = parseInt(hex.replace('#', ''), 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;

    return `${r}, ${g}, ${b}`; // return as a string
};

  return (
    <div className="homepage-container">
      <TopbarNew />
      <div className="link-sections">
        <ul className="link-group d-flex flex-row align-items-center">
          <li
            className={`dashboard ${activeSection === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/dashboard")}
          >
            Dashboard
          </li>
          <li
            className={`chatbot ${activeSection === "chatpage" ? "active" : ""}`}
            onClick={() => navigate("/chatbot")}
          >
            Customer Insight Bot
          </li>
        </ul>
      </div>

      <div className="Dashboard-content">
        <div className="input-section">
          <ButtonGroup fullWidth>
            <Button
              variant="contained"
              onClick={(event) => handleButtonClick(event, 'country')}
              className="whitebg-btn country-btn"
            >
              <Typography variant="body1">Country</Typography>
              <Typography variant="body1" style={{ marginLeft: 'auto', padding: '5px 10px', borderRadius: '5px', backgroundColor: getButtonBackgroundColor() }}>
                {countryFilter}
              </Typography>
            </Button>
            <Button
              variant="contained"
              onClick={() => handleButtonClick(null, 'speciality')}
              className="whitebg-btn speciality-btn"
            >
              <Typography variant="body1">Speciality</Typography>
            </Button>
            <Button
              variant="contained"
              onClick={() => handleButtonClick(null, 'city')}
              className="whitebg-btn city-btn"
            >
              <Typography variant="body1">City</Typography>
            </Button>
          </ButtonGroup>
        </div>

        {Boolean(anchorEl) && (
          <div
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              width: '100vw',
              height: '100vh',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              zIndex: 1,
            }}
          ></div>
        )}

        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
          style={{ marginTop: '10px', zIndex: 2 }}
        >
          <div style={{ position: 'relative', padding: '10px', backgroundColor: '#faf8f8', width: '250px' }}>
            <Button
              onClick={handleClose}
              style={{ position: 'absolute', top: 0, right: 0, padding: '5px', minWidth: '30px', fontSize: '16px' }}
            >
              <img src={closeIcon} alt="close icon" className="closeIcon" />
            </Button>

            <Typography variant="h6" style={{ marginBottom: '20px' }}>Countries</Typography>
            <span>Select Country</span>

            {countries.map((country) => (
              <ul key={country}>
                <li className="countryList" style={{ padding: '0px' }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={tempSelectedCountries.includes(country)}
                        onChange={handleCountryChange}
                        value={country}
                        style={{ paddingLeft: '20px' }}
                        className="checkboxSize"
                      />
                    }
                    label={country}
                  />
                </li>
              </ul>
            ))}

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
              <Button onClick={applyFilter} color="primary" className="ApplyFilter">
                Apply Filter
              </Button>
            </div>
          </div>
        </Popover>
        <div className="bar-chart-container">
          {/* Title */}
          <div className="chart-header">
            Distribution for {countryFilter}
          </div>

          {selectedBar === null ? (
  // Full bar chart if no bar is selected
  <div className="bar-chart">
    {barData.map((data, index) => (
      <div
        key={index}
        className="bar-container"
        onClick={() => handleBarClick(index)}
      > 
        <p className="bar-percentage" style={{ color: '#fff', fontWeight: 'bold', padding: '5px', fontSize: '10px', background: `linear-gradient(${data.color[0]}, ${data.color[1]})` }}>
          {data.value}%
        </p>
        <div
          className="bar"
          style={{
            height: `${data.value * 5}px`,
            background: `linear-gradient(${data.color[0]}, ${data.color[1]})`,
          }}
        ></div>
        <span className="bar-label">{data.label}</span>
      </div>
    ))}
  </div>
) : (
  // Split view with selected bar on the left and remaining bars on the right
  <div className="split-view">
    <div
      className="left-side"
      style={{
        padding: '10px',
        borderRadius: '8px',
        backgroundColor: `rgba(${hexToRgb(barData[selectedBar].color[0])}, 0.1)`, // Light background for selected bar
      }}
    >
      <div
        className="bar-container"
        onClick={() => handleBarClick(selectedBar)} // Reset when clicked
      >
        <p className="bar-percentage" style={{ color: '#fff', fontWeight: 'bold', padding: '5px', fontSize: '10px', background: `linear-gradient(${barData[selectedBar].color[0]}, ${barData[selectedBar].color[1]})` }}>
          {barData[selectedBar].value}%
        </p>
        <div
          className="bar"
          style={{
            height: `${barData[selectedBar].value * 5}px`,
            background: `linear-gradient(${barData[selectedBar].color[0]}, ${barData[selectedBar].color[1]})`,
          }}
        ></div>
        <span className="bar-label">{barData[selectedBar].label}</span>
        <IconButton
          style={{
            position: 'absolute',
            top: '10px',
            right: '10px',
          }}
          onClick={() => setSelectedBar(null)} // Close selected bar view
        >
          <CloseIcon />
        </IconButton>
      </div>
      {/* Display subcategory information */}
      <DialogContent className="Doughnut-section"> 
        <Barchart/>
      </DialogContent>
    </div>
    <div className="right-side" style={{ padding: '10px' }}>
      {barData.map((data, index) => (
        index !== selectedBar && (
          <div
            key={index}
            className="bar-container"
            onClick={() => handleBarClick(index)}
          >
            <p className="bar-percentage" style={{ color: '#fff', fontWeight: 'bold', padding: '5px', fontSize: '10px', background: `linear-gradient(${data.color[0]}, ${data.color[1]})` }}>
              {data.value}%
            </p>
            <div
              className="bar"
              style={{
                height: `${data.value * 5}px`,
                background: `linear-gradient(${data.color[0]}, ${data.color[1]})`,
              }}
            ></div>
            <span className="bar-label">{data.label}</span>
          </div>
        )
      ))}
    </div>
  </div>
)}

     
        </div>

     
      </div>
    </div>
  );
};

export default Dashboard;
