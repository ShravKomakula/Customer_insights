import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import axios from 'axios';

const AuthWrapper = ({ children }) => {
  const { authenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.log('Authenticated:', authenticated);
    console.log('Current Path:', location.pathname);

    // If authenticated is still loading (null), wait and don't navigate yet
    if (authenticated === null) {
      return;
    }

    // Redirect unauthenticated users to login page unless they are already there
    if (!authenticated && location.pathname !== '/login') {
      console.log('Navigating to login');
      navigate('/login', { replace: true });
    }
    // Redirect authenticated users away from the login page if they are there
    else if (authenticated && location.pathname === '/login') {
      console.log('Navigating to home');
      navigate('/', { replace: true });
    }
  }, [authenticated, location.pathname, navigate]);

  return <>{children}</>;
};

export default AuthWrapper;
