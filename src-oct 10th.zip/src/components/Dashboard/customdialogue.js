import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Typography,
  Button,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Barchart from './Barchart'; // Import your DoughnutChart component

const CustomDialog = ({ open, handleClose1 }) => {
  const label = 'Treatment Access Support';
  const value = 2448;

  return (
    <Dialog open={open} onClose={handleClose1} maxWidth="sm" fullWidth>
      <DialogTitle>
        {label}
        <IconButton
          aria-label="close"
          onClick={handleClose1}
          style={{ position: 'absolute', right: 8, top: 8, color: '#000' }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Typography variant="body1" style={{ marginBottom: '16px' }}>
          <strong>Summary of {label}:</strong>
        </Typography>
        <Typography variant="body2">This section contains a summary about {label}.</Typography>

        {/* Include the Doughnut Chart */}
        <Barchart label={label} value={value} />
      </DialogContent>
      <Button onClick={handleClose1} style={{ backgroundColor: '#8AC0FF', color: 'white', margin: '10px' }}>
        Close
      </Button>
    </Dialog>
  );
};

export default CustomDialog;
