import React, { useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../components/AuthContext";
import "./LandingPageNew.css";
import docicon from "../../assets/doc-icon.svg";
import { Select, MenuItem, InputLabel, FormControl } from "@mui/material";
import { IoMdSend } from "react-icons/io";
import TopbarNew from "../../common/TopbarNew";
import Sidebar from "../../common/RightSidebar";
import { GrRobot } from "react-icons/gr";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";

const LandingPageNew = () => {
  const navigate = useNavigate();
  const [question, setQuestion] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState("Select Source");
  const [transcript, setTranscript] = useState("");
  const [isListening, setIsListening] = useState(false);
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  const [activeSection, setActiveSection] = useState("chatpage"); // default is 'chatpage'

  const commands = [
    {
      command: ["clear", "clear field"],
      callback: () => setTranscript(""),
    },
    {
      command: ["search *"],
      callback: (searchQuery) => {
        setTranscript(searchQuery);
        searchQuestions();
      },
    },
  ];

  const popularQueries = [
    "What are the key elements that should be included in a successful?",
    "What are the key elements that should be included in a successful?",
    "What are the key elements that should be included in a successful?",
  ]; // Example popular queries
  const pastQueries = ["Past Query 1", "Past Query 2", "Past Query 3"]; // Example past queries

  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };

  const handleDropdownChange = (event) => {
    setSelectedDropdown(event.target.value);
  };

  const searchQuestions = () => {
    let searchQuery = transcript || question;
    if (selectedDropdown === "Select Source") {
      toast.warning("Please select a source.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return;
    }

    if (searchQuery.trim() !== "") {
      navigate("/query", {
        state: { question: searchQuery, sourceType: selectedDropdown },
      });
      localStorage.setItem("queryQuestion", JSON.stringify(searchQuery));
    } else {
      toast.warning("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      searchQuestions();
    }
  };

  const handlePopularQueryClick = (query) => {
    setTranscript(query);
  };

  const popularQueries1 = [
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?",
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?",
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?",
  ];
  const textFileUrl = `${process.env.PUBLIC_URL}/pdfLinks.txt`;
  const startListening = () => {
    recognition.start();
    recognition.onresult = (event) => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setTranscript(transcript);
      setQuestion(transcript); // Automatically set the question from voice input
    };
    setIsListening(true);
  };

  const stopListening = () => {
    recognition.stop();
    setIsListening(false);
  };

  return (
    <div className="homepage-container">
      <TopbarNew />

      <div className="link-sections">
        <ul className="link-group d-flex flex-row align-items-center">
          <li
            className={`dashboard ${activeSection === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/dashboard")} 
          >
            Dashboard
          </li>
          <li
            className={`chatbot ${activeSection === "chatpage" ? "active" : ""}`}
            onClick={() => setActiveSection("chatpage")}
          >
            Customer Insight Bot
          </li>
        </ul>
      </div>

      <div className="main-section">
        <div className="content-and-sidebar">
          <div className="mainpage-content">
            {/* Your main content */}
            {activeSection === "chatpage" && (
              <div className="homepage-content chatpage">
                <div className="welcome-section">
                  <h4 className="greeting">
                    Hello {localStorage.getItem("userName")}
                    <span className="blackc">,</span>
                  </h4>
                  <h6 className="help-text">How can I help you?</h6>
                  <p className="plain-text">Here are some popular Queries to start</p>
                  <div className="popular-questions">
                    {popularQueries1.map((query, index) => (
                      <div
                        key={index}
                        className="popular-question-card"
                        onClick={() => handlePopularQueryClick(query)}
                      >
                        <img src={docicon} className="doc-icon" alt="doc-icon" />
                        <p>{query}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="search-bar-container">
                  <FormControl variant="outlined" className="select-dropdown">
                    <InputLabel id="dropdown-label">Select Source</InputLabel>
                    <Select
                      labelId="dropdown-label"
                      id="dropdown-basic"
                      value={selectedDropdown}
                      onChange={handleDropdownChange}
                      label="Select Source"
                      MenuProps={{
                        anchorOrigin: {
                          vertical: "top",
                          horizontal: "center",
                        },
                        transformOrigin: {
                          vertical: "bottom",
                          horizontal: "center",
                        },
                        getContentAnchorEl: null, // Remove default anchor positioning
                        elevation: 8, // Adjust elevation for the dropdown
                      }}
                    >
                      <MenuItem value="Select Source">Select Country</MenuItem>
                      <MenuItem value="GNT01 SOPs and JobAids">India</MenuItem>
                      <MenuItem value="Grant Details">USA</MenuItem>
                    </Select>
                  </FormControl>

                  <input
                    className="search-bar"
                    type="text"
                    placeholder="Enter Your Query"
                    value={transcript || question}
                    onChange={(event) => setTranscript(event.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                  <div onClick={isListening ? stopListening : startListening}>
                    <img
                      className="voice-icon"
                      src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Google_mic.svg/716px-Google_mic.svg.png"
                      alt="Voice Search"
                    />
                  </div>
                  <IoMdSend
                    className="send-icon"
                    onClick={searchQuestions}
                    src="send-icon-url"
                    alt="Send"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="right-sidebar">
            <Sidebar popularQueries={popularQueries} pastQueries={pastQueries} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPageNew;
