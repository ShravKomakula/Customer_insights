// MainContent.js
import React from 'react';
import './MainContent.css';
import PfizerIcon from './pfizerIocn.svg'; // Assming the Pfizer logo is imported
import SendIcon from './sendbutton.svg';
import SearchIocn from './search.svg';
import MicIcon from './mic.svg';
import docIcon from './docIcon.svg';
function MainContent() {
  return (
    <main className="main-content">
      <img src={PfizerIcon} alt="Pfizer Logo" className="pfizer-icon" /> {/* Pfizer Logo */}
      <h1 className="heading">Hello John Doe,</h1>
      <p className="subheading">How can we help you today?</p>
      <p className="line">Here are some popular queries for you to start</p>

      <div className="popular-queries">
  <div className="query-tile">
    <img src={docIcon} alt="doc icon" className="doc-icon" />
    <p className="popularQuery">What strategies or interventions do physicians believe would improve patient access to medications and vaccines?</p>
  </div>
  <div className="query-tile">
    <img src={docIcon} alt="doc icon" className="doc-icon" />
    <p className="popularQuery">What strategies or interventions do physicians believe would improve patient access to medications and vaccines?</p>
  </div> <div className="query-tile">
    <img src={docIcon} alt="doc icon" className="doc-icon" />
    <p className="popularQuery">What strategies or interventions do physicians believe would improve patient access to medications and vaccines?</p>
  </div>

</div>

<div className="search-bar">
  <div className="search-bar-container">
    <select className="country-select">
      <option value="">Select Country</option> {/* Empty value for the default option */}
      <option value="BR">Brazil</option> {/* Brazil with country code BR */}
      <option value="IN">India</option> {/* India with country code IN */}
      <option value="MX">Mexico</option> {/* Mexico with country code MX */}
      <option value="All">All</option> {/* India with country code IN */}
    </select>
    <div className="search-input">
      <img src={SearchIocn} alt="search" className="search-icon" />
      <input type="text" placeholder="Type your question..." />
      <img src={MicIcon} alt="mic" className="mic-icon" />
    </div>
    <button className="send-icon">
      <img src={SendIcon} alt="sendIcon" className="send-icon" />
    </button>
  </div>
</div>

    </main>
  );
}

export default MainContent;
