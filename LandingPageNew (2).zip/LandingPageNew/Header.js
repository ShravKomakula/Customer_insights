import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom'; // Import Link and useLocation from react-router-dom
import './Header.css';
import PfizerLogo from "./pfizerLogo.svg";
import userAvthar from './userAvthar.svg';
import { FaBell, FaSearch, FaCircle } from 'react-icons/fa';

function Header() {
  const location = useLocation(); // Get current location
  const [activeLink, setActiveLink] = useState(location.pathname); // Set initial active link based on current path

  // Update active link on click
  const handleLinkClick = (path) => {
    setActiveLink(path);
  };

  return (
    <>
      {/* Header */}
      <header className="header">
        <div className="logo-container">
          <img src={PfizerLogo} alt="pfizer logo" className="logo" />
          <span className="header-title">EM CUSTOMER INSIGHTS</span>
        </div>
        <div className="user-profile">
          <FaSearch className="icon" /> {/* Search Icon */}
          <FaBell className="icon" />   {/* Bell Icon */}
          <span className="userName">John Doe</span>
          <img src={userAvthar} alt="User Avatar" />
        </div>
      </header>

      {/* Navigation Links Section */}
      <div className="nav-section">
        <nav className="nav-links">
          <Link
            to="/dashboard"
            className={`nav-item ${activeLink === '/dashboard' ? 'active' : ''}`}
            onClick={() => handleLinkClick('/dashboard')}
          >
            {activeLink === '/dashboard' && <FaCircle className="bullet-icon" />}
            Dashboard
          </Link>
          <Link
            to="/"
            className={`nav-item ${activeLink === '/' ? 'active' : ''}`}
            onClick={() => handleLinkClick('/')}
          >
            {activeLink === '/' && <FaCircle className="bullet-icon" />}
            Customer Insight Bot
          </Link>
        </nav>
      </div>
    </>
  );
}

export default Header;
