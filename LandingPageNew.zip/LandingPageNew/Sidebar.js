// Sidebar.js
import React, { useState } from 'react';
import './Sidebar.css';
import { FaEllipsisH, FaRegFileAlt } from 'react-icons/fa'; // Icons for ellipsis and document

function Sidebar() {
  const [activeIndex, setActiveIndex] = useState(null); // Track the active query

  const queries = [
    "What strategies or interventions do physicians believe would improve patient access to medications and vaccines?",
    "What are common mistakes to avoid in a medical grant proposal?",
    "How do you demonstrate the significance of your research in a grant proposal?",
    "How can you strengthen the methodology section of a medical grant?",
    "What are the key elements that should be included in a successful medical grant proposal?",
    "How can you strengthen the methodology section of a medical grant?"
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h3>Popular Queries</h3>
        <FaEllipsisH className="ellipsis-icon" />
      </div>
      <ul className="query-list">
        {queries.map((query, index) => (
          <li
            key={index}
            className={`query-item ${activeIndex === index ? 'active' : ''}`}
            onClick={() => setActiveIndex(index)} // Set active query on click
          >
            <FaRegFileAlt className="document-icon" /> {/* Document Icon */}
            {query}
          </li>
        ))}
      </ul>
    </aside>
  );
}

export default Sidebar;
