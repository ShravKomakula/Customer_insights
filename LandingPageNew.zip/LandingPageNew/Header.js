// Header.js
import React, { useState } from 'react';
import './Header.css';
import PfizerLogo from "./pfizerLogo.svg";
import userAvthar from './userAvthar.svg';
import { FaBell, FaSearch, FaCircle } from 'react-icons/fa'; // Importing icons including the dot icon

function Header() {
  const [activeLink, setActiveLink] = useState('bot'); // Set 'bot' as the default active link

  return (
    <>
      {/* Header */}
      <header className="header">
        <div className="logo-container">
          <img src={PfizerLogo} alt='pfizer logo' className="logo" />
          <span className="header-title">EM CUSTOMER INSIGHTS</span>
        </div>
        <div className="user-profile">
          <FaSearch className="icon" /> {/* Search Icon */}
          <FaBell className="icon" />   {/* Bell Icon */}
          <span className='userName'>John Doe</span>
          <img src={userAvthar} alt="User Avatar" />
        </div>
      </header>

      {/* Navigation Links Section */}
      <div className="nav-section">
        <nav className="nav-links">
          <a
            href="/dashboard"
            className={`nav-item ${activeLink === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveLink('dashboard')}
          >
            {activeLink === 'dashboard' && <FaCircle className="bullet-icon" />} {/* Show dot when active */}
            Dashboard
          </a>
          <a
            href="/bot"
            className={`nav-item ${activeLink === 'bot' ? 'active' : ''}`}
            onClick={() => setActiveLink('bot')}
          >
            {activeLink === 'bot' && <FaCircle className="bullet-icon" />} {/* Show dot when active */}
            Customer Insight Bot
          </a>
        </nav>
      </div>
    </>
  );
}

export default Header;
