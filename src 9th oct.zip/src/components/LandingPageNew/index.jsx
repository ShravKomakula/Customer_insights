import React, { useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext";
import "./LandingPageNew.css";
import docicon from "../../assets/doc-icon.svg";
import { Select, MenuItem, InputLabel, FormControl } from "@mui/material";
import { IoMdSend } from "react-icons/io";
import Mic from './mic.svg';
import robot from './robot.svg';
import TopbarNew from "../../common/TopbarNew";
import Dashboard from "../Dashboard";
import Sidebar from "../../common/RightSidebar";
import { GrRobot } from "react-icons/gr";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import Send from './sendbutton.svg';
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import { AiOutlineLike, AiOutlineDislike } from "react-icons/ai";
import { PiCopyLight } from "react-icons/pi";
import { FiRefreshCcw } from "react-icons/fi";
import { MdEdit } from "react-icons/md";
import person from './person.svg';
import Search from './search.svg';
const LandingPageNew = () => {
  const navigate = useNavigate();
  const [question, setQuestion] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState("Select Source");
  const [transcript, setTranscript] = useState("");
  const [isListening, setIsListening] = useState(false);
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  const [activeSection, setActiveSection] = useState('chatpage'); // default is 'chatpage'
  const [showQueryResult, setShowQueryResult] = useState(false); // Add this to your state
  const [queryResult, setQueryResult] = useState(null); // To store the result component
  const [isEditing, setIsEditing] = useState(false);
  const [editedQuery, setEditedQuery] = useState(queryResult);


  const commands = [
    {
      command: ["clear", "clear field"],
      callback: () => setTranscript(""),
    },
    {
      command: ["search *"],
      callback: (searchQuery) => {
        setTranscript(searchQuery);
        searchQuestions();
      },
    },
  ];

  const popularQueries = ['What are the key elements that should be included in a successful?',
    'What are the key elements that should be included in a successful?',
    'What are the key elements that should be included in a successful?']; // Example popular queries
  const pastQueries = ['Past Query 1', 'Past Query 2', 'Past Query 3']; // Example past queries

  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };

  const handleDropdownChange = (event) => {
    setSelectedDropdown(event.target.value);
  };

  const searchQuestions = () => {
    let searchQuery = transcript || question;
    if (selectedDropdown === "Select Source") {
      alert("Please select a source.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return;
    }

    if (searchQuery.trim() !== "") {
      // Show query result in the current page
      setShowQueryResult(true);
      setQueryResult(searchQuery); // Save the query result to state

      localStorage.setItem("queryQuestion", JSON.stringify(searchQuery));
    } else {
      alert("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };
  const handleEditQuery = () => {
    setIsEditing(true); // Enable edit mode
  };
  const handleSaveQuery = () => {
    setQueryResult(editedQuery);
    setIsEditing(false); // Disable edit mode
  };

  // Handle canceling the edit
  const handleCancelEdit = () => {
    setEditedQuery(queryResult); // Revert changes
    setIsEditing(false); // Disable edit mode
  };
  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      searchQuestions();
    }
  };

  const handlePopularQueryClick = (query) => {
    setTranscript(query);
  };

  const popularQueries1 = [
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?",
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?",
    "What are the key elements that should be included in a successful medical grant proposal to ensure it effectively addresses the funding criteria and stands out to reviewers?"
  ];
  const textFileUrl = `${process.env.PUBLIC_URL}/pdfLinks.txt`;
  const startListening = () => {
    recognition.start();
    recognition.onresult = event => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setTranscript(transcript);
      setQuestion(transcript); // Automatically set the question from voice input
      //  setTranscript(searchQuery)
    };
    setIsListening(true);
  };

  const stopListening = () => {
    recognition.stop();
    setIsListening(false);
  };

  return (
    <div className="homepage-container">
      <TopbarNew />

      <div className="link-sections">
        <ul className="link-group d-flex flex-row align-items-center">
        <li
            className={`dashboard ${activeSection === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/dashboard")} // Navigate to the dashboard route
          >
            Dashboard
          </li>
          <li
            className={`chatbot ${activeSection === 'chatpage' ? 'active' : ''}`}
            onClick={() => setActiveSection('chatpage')}
          >
            Customer Insight Bot
          </li>
        </ul>
      </div>

      <div className="main-section">
        <div className="content-and-sidebar">
          <div className="mainpage-content">
            {activeSection === 'chatpage' && (
              <div className="homepage-content chatpage">
                {!showQueryResult ? (
                  <>
                    <div className="welcome-section">
                      <h4 className="greeting">
                        Hello {localStorage.getItem("userName")}
                        <span className="blackc">,</span>
                      </h4>
                      <h6 className="help-text">How can I help you?</h6>
                      <p className="plain-text">Here are some popular Queries to start</p>
                      <div className="popular-questions">
                        {popularQueries1.map((query, index) => (
                          <div
                            key={index}
                            className="popular-question-card"
                            onClick={() => handlePopularQueryClick(query)}
                          >
                            <img src={docicon} className="doc-icon" alt="doc-icon" />
                            <p>{query}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="search-bar-container">

                      <FormControl variant="outlined" className="select-dropdown">

                        <Select
                          id="dropdown-basic"
                          value={selectedDropdown}
                          onChange={handleDropdownChange}
                          displayEmpty
                          style={{backgroundColor:'#f7f7f7',borderRadius:'10px'}}
                          IconComponent={KeyboardArrowDownIcon} // Set custom dropdown icon here
                        >
                          <MenuItem value="Select Source">Select Country</MenuItem>

                          <MenuItem value="Brazil">Brazil</MenuItem>
                          <MenuItem value="India">India</MenuItem>
                          <MenuItem value="Mexico">Mexico</MenuItem>
                          <MenuItem value="all">All</MenuItem>
                        </Select>
                      </FormControl>
                      <img src={Search} alt="search icon" className="searchIcon" />

                      <input
                        className="search-bar"
                        type="text"
                        placeholder="Enter The Question"
                        value={transcript || question}
                        onChange={(event) => setTranscript(event.target.value)}
                        onKeyDown={handleKeyDown}
                      />
                      <div onClick={isListening ? stopListening : startListening}>
                        <img
                          className="voice-icon"
                          src={Mic}

                          alt="Voice Search"
                        />
                      </div>
                      <img src={Send} alt="send button " className="send-icon"
                        onClick={searchQuestions} />

                    </div>
                  </>
                ) : (
                  // Show the query result here
                  <>
                    <div className="query-result-section">
                      {/* Query Input Section */}
                      <div className="d-flex flex-row align-items-center query-input-container">
                        <img
                          src={person}
                          className="personicon"
                          alt="Person Icon"
                          style={{ width: "30px", height: "30px", marginRight: "10px" }}
                        />
                        <div className="query-text-box-container flex-grow-1">
                          <div className="d-flex justify-content-between align-items-center query-text-box p-2">
                            <div className="flex-grow-1">{queryResult}</div>
                            {/* Edit Icon Inside the Query Box */}
                            <div className="edit-icon" onClick={handleEditQuery} style={{ cursor: "pointer" }}>
                              <MdEdit />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Answer Section */}
                      <div className="d-flex flex-row align-items-start mt-3 answer-container">
                        <img
                          src={robot}
                          alt="Robot Icon"
                          className="roboticon"
                          style={{ width: "40px", height: "40px", marginRight: "10px" }}
                        />
                        <div className="answer-box p-2">
                          <p>
                            Large language models (LLM) are very large deep learning models that are pre-trained on vast amounts of data.
                            The underlying transformer is a set of neural networks that consist of an encoder and a decoder with self-attention capabilities.
                          </p>

                          {/* Options List */}
                          <div className="options-list d-flex flex-row justify-content-between w-100 p-2">
                            <ul className="d-flex flex-row" style={{ listStyle: "none", padding: 0 }}>
                              <li className="option-item" style={{ marginRight: "10px" }}>pdf file name 1.pdf</li>
                              <li className="option-item" style={{ marginRight: "10px" }}>pdf file name 2.pdf</li>
                              <li className="option-item">pdf file name 3.pdf</li>
                            </ul>
                          </div>

                          {/* Action Buttons */}
                          <div className="action-buttons">
                            <AiOutlineLike />&nbsp;&nbsp;&nbsp;
                            <AiOutlineDislike />&nbsp;&nbsp;&nbsp;
                            <PiCopyLight />&nbsp;&nbsp;&nbsp;
                            <FiRefreshCcw />
                          </div>
                        </div>
                      </div>


                      {/*  <button className="back-button mt-2" onClick={() => setShowQueryResult(false)}>Back to Chat</button> */}
                   
                    </div>

                    <div className="search-bar-container">
                      <FormControl variant="outlined" className="select-dropdown" >
                        <Select
                          id="dropdown-basic"
                          value={selectedDropdown}
                          onChange={handleDropdownChange}
                          displayEmpty
                          style={{backgroundColor:'#f7f7f7',borderRadius:'10px'}}
                          IconComponent={KeyboardArrowDownIcon} // Set custom dropdown icon here
                        >

                          <MenuItem value="Select Source">Select Country</MenuItem>
                          <MenuItem value="Brazil">Brazil</MenuItem>
                          <MenuItem value="India">India</MenuItem>
                          <MenuItem value="Mexico">Mexico</MenuItem>
                          <MenuItem value="all">All</MenuItem>
                        </Select>
                      </FormControl>

                      <input
                        className="search-bar"
                        type="text"
                        placeholder="Enter Your Query"
                        value={transcript}
                        onChange={(event) => setTranscript(event.target.value)}
                        onKeyDown={handleKeyDown}
                      />
                      <div onClick={isListening ? stopListening : startListening}>
                        <img
                          className="voice-icon"
                          src={Mic}
                          alt="Voice Search"
                        />
                      </div>
                      <img src={Send} alt="send button " className="send-icon"
                        onClick={searchQuestions} />
                    </div>
                    
                    </>
                    
                )}

              </div>

            )}
            {activeSection === 'dashboard' && (
              <div className="dashboard-section">
                <Dashboard />
              </div>
            )}
          </div>
          <div className="right-sidebar">
 <Sidebar popularQueries={popularQueries} pastQueries={pastQueries} />
</div>

        </div>
      </div>
    </div>
  );

};

export default LandingPageNew;



