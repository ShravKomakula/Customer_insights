import { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'react-toastify';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(null); // Initially null to check loading state

  useEffect(() => {
    // Sync authentication status with localStorage on mount
    const storedAuth = localStorage.getItem('authenticated') === 'true';
    setAuthenticated(storedAuth);  // Set the authentication state from localStorage
  }, []);

  const handleLoginSuccess = (email, userName, navigate) => {
    setAuthenticated(true);
    localStorage.setItem('authenticated', true);
    localStorage.setItem('email', email);
    localStorage.setItem('userName', userName);
    toast.success('Logged in successfully', { position: toast.POSITION.TOP_CENTER });
    navigate('/'); // Navigate to home
  };

  const login = (email, password, navigate, firstname = '') => {
    const userCredentials = [
      { email: 'komakula.shravani@pfizer.com', password: 'Admin@123', name: 'Shravani' },
      { email: 'nithin.makkina@pfizer.com', password: 'Admin@123', name: 'Nithin' },
      { email: 'admin@pfizer.com', password: 'Admin@123', name: 'Admin' }
    ];

    const user = userCredentials.find(u => u.email === email && u.password === password);

    if (user) {
      handleLoginSuccess(user.email, user.name, navigate);
    } else if (password === 'ssologin') {
      handleLoginSuccess(email, firstname, navigate);
    } else {
      toast.warning('Please provide valid Email & Password', { position: toast.POSITION.TOP_CENTER });
    }
  };

  const logout = (navigate) => {
    setAuthenticated(false);
    localStorage.removeItem('authenticated');
    localStorage.removeItem('email');
    localStorage.removeItem('userName');
    toast.success('Logged out successfully', { position: toast.POSITION.TOP_CENTER });
    navigate('/login', { replace: true });
  };

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {authenticated === null ? null : children} {/* Render children only when auth is set */}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
