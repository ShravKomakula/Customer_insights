import React, { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';

const TreatmentChart = () => {
  const [selectedSummary, setSelectedSummary] = useState('');

  const data = {
    labels: [
      'Treatment Access Support 2448',
      'Hospital Infection 456',
      'Rehumea Treatment Access 987',
      'NOAC Treatment Access 133',
      'Complicated Cases 765',
    ],
    datasets: [
      {
        data: [2448, 422, 399, 204, 99],
        backgroundColor: [
          '#00BFFF', // Treatment Access Support
          '#FF6347', // Hospital Infection
          '#6A5ACD', // Rehumea Treatment Access
          '#FFD700', // NOAC Treatment Access
          '#FF69B4', // Complicated Cases
        ],
        hoverBackgroundColor: [
          '#00BFFF',
          '#FF6347',
          '#6A5ACD',
          '#FFD700',
          '#FF69B4',
        ],
      },
    ],
  };

  const summaries = {
    'Treatment Access Support': 'This category includes all support activities related to treatment access.',
    'Hospital Infection': 'Details on infections that occur within hospital settings.',
    'Rehumea Treatment Access': 'Information about access to Rehumea treatment options.',
    'NOAC Treatment Access': 'Summary of NOAC treatment access points and statistics.',
    'Complicated Cases': 'Overview of complicated cases that require special treatment considerations.',
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }, // Remove top labels
    },
    cutout: '70%', // Makes the donut chart more spacious
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
        <div style={{ width: '250px', height: '250px', position: 'relative' }}> {/* Reduced size */}
          <Doughnut data={data} options={options} />
          <div
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              color: '#000', // Adjust color to your preference
            }}
          >
            <h2 style={{ margin: '0', fontSize: '20px' }}>Brazil</h2> {/* Reduced font size */}
            <h3 style={{ margin: '0', fontSize: '20px' }}>95 %</h3> {/* Reduced font size */}
          </div>
        </div>
        <div style={{ marginLeft: '20px', width: '250px' }}>
          <ul style={{ listStyleType: 'none', padding: 0 }}>
            {data.labels.map((label) => (
              <li
                key={label}
                style={{
                  color: data.datasets[0].backgroundColor[data.labels.indexOf(label)],
                  padding: '5px 0', // Reduced padding
                  borderBottom: '1px solid #ccc',
                  fontSize: '14px', // Reduced font size
                  cursor: 'pointer',
                }}
                onClick={() => setSelectedSummary(summaries[label])}
                role="button"
                tabIndex={0}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    setSelectedSummary(summaries[label]);
                  }
                }}
              >
                {label}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div style={{ marginTop: '20px', padding: '10px', borderRadius: '5px', width: '100%', backgroundColor:'#faf8f8' }}>
        {selectedSummary && (
          <>
            <h4 style={{ fontSize: '16px' }}>Summary:</h4> {/* Reduced font size */}
            <p style={{ fontSize: '14px' }}>{selectedSummary}</p> {/* Reduced font size */}
          </>
        )}
      </div>
    </div>
  );
};

export default TreatmentChart;
