import React, { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import './Donut.css';

const TreatmentChart = () => {
  const data = {
    labels: [
      'Treatment Access Support',
      'Hospital Infection',
      'Rehumea Treatment Access',
      'NOAC Treatment Access',
      'Complicated Cases',
    ],
    datasets: [
      {
        data: [1448, 422, 299, 204, 199],
        backgroundColor: [
          '#14B8A6',
          '#35AAF3',
          '#6366F1',
          '#F59E0B',
          '#FED530',
        ],
        hoverBackgroundColor: [
          '#14B8A6',
          '#35AAF3',
          '#6366F1',
          '#F59E0B',
          '#FED530',
        ],
      },
    ],
  };

  const summaries = {
    'Treatment Access Support': `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop t was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, sheets containing Lorem Ipsum passages, and more recently with desktop`,
    'Hospital Infection': `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop t was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, sheets containing Lorem Ipsum passages, and more recently with desktop`,
    'Rehumea Treatment Access': `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop t was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, sheets containing Lorem Ipsum passages, and more recently with desktop`,
    'NOAC Treatment Access': `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop t was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, sheets containing Lorem Ipsum passages, and more recently with desktop`,
    'Complicated Cases': `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop t was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, sheets containing Lorem Ipsum passages, and more recently with desktop`,
  };

  const [selectedLabel, setSelectedLabel] = useState(''); // State for selected label
  const [selectedSummary, setSelectedSummary] = useState(''); // State for selected summary
  const [activeIndex, setActiveIndex] = useState(null); // Track the currently active index

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
    },
    cutout: '60%',
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index; // Get the index of the clicked segment
        handleLabelClick(index, data.labels[index]); // Call the same function as label click
      }
    },
  };

  const handleLabelClick = (index, label) => {
    setSelectedLabel(label); // Update selected label
    setSelectedSummary(summaries[label]); // Update selected summary
    setActiveIndex(index); // Update the active index
  };

  const lighterColors = [
    '#d2f7f3', // Light color for Treatment Access Support
    '#cfe8f8', // Light color for Hospital Infection
    '#cecff7', // Light color for Rehumea Treatment Access
    '#f6edde', // Light color for NOAC Treatment Access
    '#f4edd1', // Light color for Complicated Cases
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
        <div style={{ width: '180px', height: '180px', position: 'relative' ,cursor:'pointer'}}>
          <Doughnut
            data={{
              ...data,
              datasets: [
                {
                  ...data.datasets[0],
                  backgroundColor: data.datasets[0].backgroundColor.map((color, index) =>
                    activeIndex === null
                      ? color
                      : index === activeIndex
                      ? color
                      : `${color}30` // Highlight active segment and make others transparent
                  ),
                },
              ],
            }}
            options={options}
          />

          <div
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              color: '#000',
            }}
          >
            <h2 style={{ margin: '0', fontSize: '20px' }}>Brazil</h2>
            <h3 style={{ margin: '0', fontSize: '20px' }}>95 %</h3>
          </div>
        </div>
        <div style={{ marginLeft: '20px', width: '300px', marginTop: '-20px', fontSize: '12px' }} className='labelsList'>
          <ul style={{ listStyleType: 'disc', padding: 0 }}>
            {data.labels.map((label, index) => (
              <li
                key={label}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  border: 'none',
                  cursor: 'pointer',
                  marginLeft: '20px',
                  color: '#000',
                  backgroundColor: activeIndex === index ? lighterColors[index] : 'transparent',
                }}
                onClick={() => handleLabelClick(index, label)}
                role="button"
                tabIndex={0}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleLabelClick(index, label);
                  }
                }}
              >
                <span
                  style={{
                    display: 'inline-block',
                    width: '10px',
                    height: '10px',
                    backgroundColor: data.datasets[0].backgroundColor[index],
                    borderRadius: '50%',
                    marginRight: '8px',
                    
                  }}
                ></span>
                {label} <span style={{ marginLeft: 'auto' }}>{data.datasets[0].data[index].toLocaleString()}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div style={{ marginTop: '20px', padding: '10px', borderRadius: '5px', width: '100%', backgroundColor: '#F7F7F7' }}>
        {selectedSummary && (
          <>
            <h6>Summary of {selectedLabel}</h6> {/* Display the selected label */}
            <p style={{ fontSize: '12px', textAlign: 'justify' }}>{selectedSummary}</p>
          </>
        )}
      </div>
    </div>
  );
};

export default TreatmentChart;
