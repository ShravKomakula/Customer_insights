import React from 'react';
import './OmnichannelProfile.css';

const OmnichannelProfile = () => {
  const profiles = [
    { name: 'Digital Enthusiast', value: 150, percentage: '36%' },
    { name: 'Omnichannel Pro', value: 72, percentage: '22%' },
    { name: 'F2F Hybrid Adapter', value: 66, percentage: '20%' },
    { name: 'Traditionalist', value: 65, percentage: '20%' },
  ];

  return (
    <div className="omnichannel-profile">
      <h5>Omnichannel Profile</h5>
      <div className="profile-grid">
        {profiles.map((profile, index) => (
          <div key={index} className="profile-box">
            <span>{profile.name}</span>
            <h2>{profile.value}</h2>
            <span>{profile.percentage}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OmnichannelProfile;
