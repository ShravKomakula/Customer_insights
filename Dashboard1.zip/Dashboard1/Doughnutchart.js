import React from 'react';
import { PieChart, Pie, Cell } from 'recharts';

const DonutChart = ({ total }) => {
  const data = [
    { name: 'Treatment Access Support', value: 192 },
    { name: 'Hospital Infection', value: 128 },
    { name: 'Rheuma Treatment Access', value: 96 },
    { name: 'NOAC Treatment Access', value: 160 },
    { name: 'Complicated Cases', value: 64 },
  ];

  const colors = ['#4A90E2', '#50E3C2', '#F5A623', '#B8E986', '#BD10E0'];

  return (
    <PieChart width={200} height={200}>
      <Pie
        data={data}
        cx="50%"
        cy="50%"
        innerRadius={50}
        outerRadius={80}
        fill="#8884d8"
        paddingAngle={5}
        dataKey="value"
      >
        {data.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
        ))}
      </Pie>
      <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle">
        {total} Total Comments
      </text>
    </PieChart>
  );
};

export default DonutChart;
