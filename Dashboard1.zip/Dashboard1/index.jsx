import React from 'react';
import FilterBar from './FilterBar';
import CommentsDistribution from './CommentsDistribution';
import SentimentDistribution from './SentimentDistribution';
import HCPProfile from './HCPProfile';
import KeyInsights from './KeyInsights';
import Specialities from './Specialities';
import Omnichannel from './Omnichannel';
import Header from '../LandingPageNew/Header'
const Dashboard = () => {
  return (
    <div className="dashboard-container">
<Header />
      <div className="filter-bar-container">
        <FilterBar />
      </div>
      <div className="dashboard">
        {/* First Row */}
        <div className="row first-row">
          <div className="comments-distribution col-6">
            <CommentsDistribution />
          </div>
          <div className="sentiment-distribution col-3">
            <SentimentDistribution />
          </div>
          <div className="hcp-profile col-3">
            <HCPProfile />
          </div>
        </div>
        
        {/* Second Row: Key Insights, Specialities, and Omnichannel */}
        <div className="row second-row" style={{marginTop:'20px'}}>
          <div className="key-insights col-4">
            <KeyInsights />
          </div>
          <div className="specialities col-5">
            <Specialities />
          </div>
          <div className="omnichannel col-3">
            <Omnichannel />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
