import React from 'react';
import { PieChart, Pie, Cell } from 'recharts';

const HcpSegmentsChart = () => {
  const data = [
    { name: 'Segment A', value: 80 },
    { name: 'Segment B', value: 56 },
    { name: 'Others', value: 70 },
  ];

  const colors = ['#4A90E2', '#50E3C2', '#F5A623'];

  return (
    <PieChart width={150} height={150}>
      <Pie
        data={data}
        cx="50%"
        cy="50%"
        innerRadius={50}
        outerRadius={70}
        startAngle={180}
        endAngle={0}
        fill="#8884d8"
        paddingAngle={5}
        dataKey="value"
      >
        {data.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
        ))}
      </Pie>
      <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle">
        206 Total HCP
      </text>
    </PieChart>
  );
};

export default HcpSegmentsChart;
