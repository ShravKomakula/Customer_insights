import React, { useState } from 'react';


const CategoryPage = () => {
  const [activeCategory, setActiveCategory] = useState('Treatment');



  return (
    <div>
      <h2>Total Distribution for Brazil</h2>
   
      <div className="category-content">
        <h3>{activeCategory} Details</h3>
        {/* Render details of the selected category */}
      </div>
    </div>
  );
};

export default CategoryPage;
