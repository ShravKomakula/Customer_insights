import React from 'react';
import './comments.css';

const comments = () => {
  return (
    <div className="comments-distribution">
      <h5>Total Comments</h5>
      <div className="comment-bar">
        <span>Positives: 300</span>
        <div className="bar positive-bar" style={{ width: '50%' }}></div>
      </div>
      <div className="comment-bar">
        <span>Neutral: 240</span>
        <div className="bar neutral-bar" style={{ width: '37%' }}></div>
      </div>
      <div className="comment-bar">
        <span>Negatives: 100</span>
        <div className="bar negative-bar" style={{ width: '15%' }}></div>
      </div>
    </div>
  );
};

export default comments;
