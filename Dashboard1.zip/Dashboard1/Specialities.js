import React from 'react';
import { Radar } from 'react-chartjs-2';
import './Specialities.css';

const Specialities = () => {
  // Data for radar chart
  const chartData = {
    labels: [
      'Internal Medicine',
      'Surgical Specialties',
      'Pediatrics',
      'Oncology & Hematology',
      'Cardiology',
      'Critical Care & Emergency'
    ],
    datasets: [
      {
        label: 'Specialties Distribution',
        data: [15, 17, 8, 13, 40, 7],
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(59, 130, 246, 1)',
      },
    ],
  };

  // List of specialties and their values
  const specialties = [
    { label: 'Internal Medicine', value: '15%' },
    { label: 'General Medicine', value: '22' },
    { label: 'Family Medicine', value: '6' },
    { label: 'Geriatrics', value: '7' },
    { label: 'Endocrinology', value: '12' },
    { label: 'Rheumatology', value: '5' },
    { label: 'Gastroenterology', value: '15' },
    { label: 'Infectious Diseases', value: '33' },
  ];

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      r: {
        angleLines: { color: '#ddd' },
        grid: { color: '#ddd' },
        ticks: { display: false },
        suggestedMin: 0,
        suggestedMax: 50,
      },
    },
    plugins: {
      legend: { display: false },
    },
  };

  return (
    <div className="specialities-container">
      <h5 className="specialities-title">
        <span className="icon">🔄</span> Specialities
      </h5>
      <div className="specialities-content">
        <div className="radar-chart">
          <Radar data={chartData} options={chartOptions} />
        </div>
        <div className="specialities-list">
          {specialties.map((specialty, index) => (
            <div key={index} className="specialty-item">
              <span className="specialty-label">{specialty.label}</span>
              <span className="specialty-value">{specialty.value}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

export default Specialities;
