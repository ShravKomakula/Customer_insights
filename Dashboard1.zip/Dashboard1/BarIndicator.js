import React from 'react';
import './BarIndicator.css';

const BarIndicator = ({ percentage, label }) => {
  return (
    <div className="bar-indicator">
      <div className="bar" style={{ height: `${percentage}%` }}></div>
      <span>{label}</span>
    </div>
  );
};

export default BarIndicator;
