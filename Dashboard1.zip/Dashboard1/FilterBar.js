import React, { useState } from 'react';
import Select, { components } from 'react-select';

const FilterBar = () => {
  const countryOptions = [
    { value: 'brazil', label: 'Brazil' },
    { value: 'mexico', label: 'Mexico' },
    { value: 'india', label: 'India' },
  ];

  const specialityOptions = Array.from({ length: 40 }, (_, i) => ({
    value: `speciality${i + 1}`,
    label: `Speciality ${i + 1}`,
  }));

  const cityOptions = Array.from({ length: 50 }, (_, i) => ({
    value: `city${i + 1}`,
    label: `City ${i + 1}`,
  }));

  const hcpSegmentOptions = [
    { value: 'segment1', label: 'Segment 1' },
    { value: 'segment2', label: 'Segment 2' },
    { value: 'segment3', label: 'Segment 3' },
  ];

  const [selectedCountry, setSelectedCountry] = useState(null);
  const [selectedCities, setSelectedCities] = useState([]);
  const [selectedSpecialities, setSelectedSpecialities] = useState([]);
  const [selectedHcpSegments, setSelectedHcpSegments] = useState([]);

  const handleCountryChange = (selectedOption) => {
    setSelectedCountry(selectedOption);
    if (selectedOption) {
      if (selectedOption.value === 'brazil') {
        setSelectedCities(cityOptions.slice(0, 8));
        setSelectedSpecialities(specialityOptions.slice(0, 10));
        setSelectedHcpSegments(hcpSegmentOptions.slice(0, 1));
      } else if (selectedOption.value === 'mexico') {
        setSelectedCities(cityOptions.slice(0, 5));
        setSelectedSpecialities(specialityOptions.slice(0, 8));
        setSelectedHcpSegments(hcpSegmentOptions.slice(0, 1));
      } else if (selectedOption.value === 'india') {
        setSelectedCities(cityOptions.slice(0, 20));
        setSelectedSpecialities(specialityOptions.slice(0, 15));
        setSelectedHcpSegments(hcpSegmentOptions.slice(0, 2));
      }
    } else {
      setSelectedCities([]);
      setSelectedSpecialities([]);
      setSelectedHcpSegments([]);
    }
  };

  const MultiValue = () => null;

  const Control = ({ children, ...props }) => {
    const selectedCount = props.isMulti ? props.getValue().length : 0;
    const handleClick = () => {
      props.selectProps.onMenuOpen();
    };

    return (
      <components.Control {...props}>
        <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
          <span style={{ marginLeft: '8px', fontWeight: 'bold' }}>
            {props.selectProps.placeholder}
          </span>
          <div style={{ flexGrow: 1 }} />
          {selectedCount > 0 && (
            <div
              style={{
                backgroundColor: '#e0e0e0',
                borderRadius: '12px',
                padding: '2px 8px',
                marginRight: '8px',
                cursor: 'pointer',
              }}
              onClick={handleClick}
            >
              {selectedCount} Selected
            </div>
          )}
        </div>
      </components.Control>
    );
  };

  const Option = (props) => {
    return (
      <components.Option {...props}>
        <input
          type="checkbox"
          checked={props.isSelected}
          readOnly
          style={{ marginRight: 8 }}
        />
        <label>{props.label}</label>
      </components.Option>
    );
  };

  const customStyles = {
    control: (provided) => ({
      ...provided,
      minHeight: '40px',
      borderRadius: '8px',
      width: '100%',
      fontSize: '14px',
      padding: '0 8px',
    }),
    menuPortal: (provided) => ({ ...provided, zIndex: 9999 }),
  };

  return (
    <div style={containerStyle}>
      <Select
        options={countryOptions}
        value={selectedCountry}
        onChange={handleCountryChange}
        placeholder="Select Country"
        styles={customStyles}
        isClearable={false}
        menuPortalTarget={document.body}
      />
      <Select
        options={specialityOptions}
        value={selectedSpecialities}
        isMulti
        placeholder="Speciality"
        styles={customStyles}
        components={{ Control, MultiValue, Option }}
        onChange={(selected) => setSelectedSpecialities(selected || [])}
        isClearable={false}
        menuPortalTarget={document.body}
      />
      <Select
        options={cityOptions}
        value={selectedCities}
        isMulti
        placeholder="City"
        styles={customStyles}
        components={{ Control, MultiValue, Option }}
        onChange={(selected) => setSelectedCities(selected || [])}
        isClearable={false}
        menuPortalTarget={document.body}
      />
      <Select
        options={hcpSegmentOptions}
        value={selectedHcpSegments}
        isMulti
        placeholder="HCP Segment"
        styles={customStyles}
        components={{ Control, MultiValue, Option }}
        onChange={(selected) => setSelectedHcpSegments(selected || [])}
        isClearable={false}
        menuPortalTarget={document.body}
      />
    </div>
  );
};

export default FilterBar;

const containerStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, 1fr)',
  gap: '15px',
  padding: '20px',
  width: '100%',
  alignItems: 'center',
};
