// src/components/Dashboard1/Summary.js
import React from 'react';

const Summary = () => {
  return (
    <div>
      <h4>Summary</h4>
      <p>This is the summary section.</p>
      {/* Placeholder content */}
    </div>
  );
};

export default Summary;
