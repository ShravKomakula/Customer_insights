import React from 'react';
import './KeyInsights.css';

const KeyInsights = () => {
  const insights = [
    "Treatment leads discussions with 20% of comments, followed by Medical Education at 15%.",
    "15.63% of comments are negative, with a small contribution from Segment A and B doctors.",
    "56% of feedback comes from Segment A doctors and 44% from Segment B.",
    "Digital Enthusiasts contribute 45% of the total feedback, showing high engagement.",
    "Cardiology received the highest number of comments at 40%, indicating strong engagement, while Critical Care & Emergency had the lowest with 7%."
  ];

  return (
    <div className="key-insights-container">
      <h5 className="key-insights-title">
        <span className="icon">🔍</span> Key Insights
      </h5>
      <ul className="insights-list">
        {insights.map((insight, index) => (
          <li key={index} className="insight-item">
            <span className="bullet-icon">•</span>
            {insight}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default KeyInsights;
