import React from 'react';
import './Omnichannel.css';

const Omnichannel = () => {
  const channels = [
    { label: 'Digital Enthusiast', value: 1170, percentage: '36%', color: '#2E3EBB' },
    { label: 'F2F Hybrid Adapter', value: 720, percentage: '22%', color: '#3A4EBC' },
    { label: 'Omnichannel Pro', value: 640, percentage: '20%', color: '#8E5AD7' },
    { label: 'Traditionalist', value: 650, percentage: '20%', color: '#24A7A7' },
  ];

  return (
    <div className="omnichannel-container">
      <h5>Omnichannel Profile</h5>
      <div className="channels-grid">
        {channels.map((channel, index) => (
          <div
            key={index}
            className="channel-box"
            style={{ backgroundColor: channel.color }}
          >
            <div className="channel-label">{channel.label}</div>
            <div className="channel-value">{channel.value}</div>
            <div className="channel-percentage">{channel.percentage}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Omnichannel;
