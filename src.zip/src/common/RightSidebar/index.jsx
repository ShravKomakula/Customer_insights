import React, { useState } from 'react';
import './sidebar.css';
import docicon from "../../assets/doc-icon.svg";
const Sidebar = ({ popularQueries, pastQueries }) => {
  const [sidebarSection, setSidebarSection] = useState('popular'); // State to manage the toggle

  return (
    <div className="right-sidebar">
      {/* Sidebar Links */}
      <div className="sidebar-links">
        <span
          className={`sidebar-link ${sidebarSection === 'past' ? 'active' : ''}`}
          onClick={() => setSidebarSection('past')}
        >
         Past Queries
        </span>
        <span
          className={`sidebar-link ${sidebarSection === 'popular' ? 'active' : ''}`}
          onClick={() => setSidebarSection('popular')}
        >
           Popular Queries
        </span>
      </div>

      {/* Sidebar Content */}
      <div className="sidebar-content">
        {sidebarSection === 'popular' && (
          <div className="popular-queries">
           
            <ul>
              {popularQueries.map((query, index) => (
            
               
                 <li key={index}>  <img src={docicon} className="doc-icon" alt="doc-icon" /> {query}</li>
                
               
              ))}
            </ul>
          </div>
        )}
        {sidebarSection === 'past' && (
          <div className="past-queries">
          
            <ul>
              {pastQueries.map((query, index) => (
                <li key={index}> <img src={docicon} className="doc-icon" alt="doc-icon" />  {query}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
