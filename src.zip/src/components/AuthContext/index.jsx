import { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'react-toastify';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    // Sync authentication status with localStorage on mount
    const storedAuth = localStorage.getItem('authenticated') === 'true';
    setAuthenticated(storedAuth);
  }, []);

  const handleLoginSuccess = (email, userName, navigate) => {
    setAuthenticated(true);
    localStorage.setItem('authenticated', true);
    localStorage.setItem('email', email);
    localStorage.setItem('userName', userName);
    toast.success('Logged in successfully', { position: toast.POSITION.TOP_CENTER });
    navigate('/');
  };

  const login = (email, password, navigate, firstname = '') => {
    console.log('login called');
    
    // Predefined credentials for users
    const userCredentials = [
      { email: 'komakula.shravani@pfizer.com', password: 'Admin@123', name: 'Shravani' },
      { email: 'nithin.makkina@pfizer.com', password: 'Admin@123', name: 'Nithin' },
      { email: 'admin@pfizer.com', password: 'Admin@123', name: 'Admin' }
    ];

    // Check if credentials match
    const user = userCredentials.find(u => u.email === email && u.password === password);
    
    if (user) {
      handleLoginSuccess(user.email, user.name, navigate);
    } else if (password === 'ssologin') {
      // Handle SSO login
      console.log('SSO login');
      handleLoginSuccess(email, firstname, navigate);
    } else {
      // Invalid login credentials
      toast.warning('Please provide valid Email & Password', { position: toast.POSITION.TOP_CENTER });
    }
  };
  const logout = (navigate) => {
    try {
      setAuthenticated(false);
      localStorage.removeItem('authenticated');
      localStorage.removeItem('email');
      localStorage.removeItem('userName');
      toast.success('Logged out successfully', { position: toast.POSITION.TOP_CENTER });
      navigate("/login", { replace: true }); // Make sure navigate is passed here
    } catch (error) {
      console.error('Error during logout:', error);
     /*  toast.error('Error during logout. Please try again.', { position: toast.POSITION.TOP_CENTER }); */
    }
  };
  

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
