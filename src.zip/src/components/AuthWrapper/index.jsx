import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { RevokeTokenEndPoint } from '../../common/api-config';
import axios from 'axios';
const AuthWrapper = ({ children }) => {
  const { authenticated } = useAuth();
  const location = useLocation()
  const navigate = useNavigate();

  useEffect(() => {
    console.log('Authenticated:', authenticated);
    console.log('Current Path:', location.pathname);
  
    if (authenticated === null) {
      // Still loading or checking authentication status
      return;
    }
  
    // Redirect unauthenticated users to the login page
    if (!authenticated || location.pathname === '/login') {
      console.log('Navigating to login');
      navigate('/login', { replace: true });
    }
    // Redirect authenticated users only if they are on a login page
    else if (authenticated === 'true') {
      console.log('Navigating to home');
      navigate('/', { replace: true });
    }
  }, [authenticated, location.pathname, navigate]);
  

  
/* const refreshToken = async () => {
        try {
          console.log(JSON.parse(localStorage.access_token).tokenInfo.refresh_token,"access")
            const refreshToken = JSON.parse(localStorage.access_token).tokenInfo.refresh_token;
            const response = await axios.post(`http://10.11.185.89:8011/refresh_oauth2?refresh_token=${refreshToken}`, { refresh_token: refreshToken });
            // Update access token in localStorage or wherever you store tokens
            localStorage.setItem("access_token", response.data.access_token);
            console.log(response)
            return response.data.access_token;
            
        } catch (error) {
            console.error("Error refreshing token", error);
            throw error; // Throw the error to handle it in the calling function
        }
    };
 useEffect(() => {
        const interval = setInterval(() => {
            refreshToken();
        }, 1800); // Refresh token every 30 minutes

        return () => clearInterval(interval); // Clean up the interval on component unmount
    }, []);  
 
  
     */
    return (
      <>
        {children}
     
      </>
    );
  };
  
  export default AuthWrapper;
  
/* import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const AuthWrapper = ({ children }) => {
  const { authenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    console.log('Authenticated:', authenticated);
    console.log('Current Path:', location.pathname);
  
    if (authenticated === null) {
      // Still loading or checking authentication status
      return;
    }
  
    // Redirect unauthenticated users to the login page
    if (!authenticated && location.pathname === '/login') {
      console.log('Navigating to login');
      navigate('/login', { replace: true });
    }
    // Redirect authenticated users only if they are on a login page
    else if (authenticated === 'true') {
      console.log('Navigating to home');
      navigate('/', { replace: true });
    }
  }, [authenticated, location.pathname, navigate]);
  

  return <>{children}</>;
};

export default AuthWrapper;
 */