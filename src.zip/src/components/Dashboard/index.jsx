import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";
import TopbarNew from "../../common/TopbarNew";

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState("dashboard"); // default is 'dashboard'

  return (
    <div className="homepage-container">
   {/*    <TopbarNew />

      <div className="link-sections">
        <ul className="link-group d-flex flex-row align-items-center">
          <li
            className={`dashboard ${activeSection === "dashboard" ? "active" : ""}`}
            onClick={() => navigate("/dashboard")} // Navigate to the dashboard route
          >
            Dashboard
          </li>
          <li
            className={`chatbot ${activeSection === "chatpage" ? "active" : ""}`}
            onClick={() => navigate("/chatbot")} // Navigate to the LandingPageNew route
          >
            Customer Insight Bot
          </li>
        </ul>
      </div>
 */}
      <div className="Dashboard-content">
        <h5>Welcome to Dashboard...</h5>
      </div>
    </div>
  );
};

export default Dashboard;
