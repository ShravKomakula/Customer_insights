import React, { useState, useEffect, useRef, useReducer } from "react";
import "./Chat.css";
import { FaThumbsUp,  FaRegThumbsUp, FaRegCopy, FaThumbsDown, FaRegThumbsDown, FaUserCheck } from "react-icons/fa";
import axios from "axios";
import { IoMdSend } from "react-icons/io";
import { Chart as ChartJS, CategoryScale, LinearScale, Title, Tooltip, Legend } from 'chart.js';
import { FcDocument } from "react-icons/fc";
import { ToastContainer, toast } from "react-toastify";
import { useLocation, Link } from "react-router-dom";
import TopbarNew from "../../common/TopbarNew";

import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'; // Import necessary MUI components
import thumsupWhite from "../../assets/images/ThumbsUp-white.svg";
import {ViewEndpoint,
  LikeEndPoint,
  DisLikeEndPoint,
  TextToSql,UserLogsEndpoint
} from "../../common/api-config";
import person from './person.svg'
import Popup from "../../common/CommentPopup";
import TypingEffect from "../../common/TypingEffect";
import { useNavigate } from "react-router-dom";
import { GrRobot } from "react-icons/gr";
const Chat = (item) => {

  const [sqlQuery, setSqlQuery] = useState("");
  const [table, setTable] = useState("");
  const [selectedQuery, setSelectedQuery] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [alreadyLiked, setAlreadyLiked] = useState(false);
  const [alreadyDisliked, setAlreadyDisliked] = useState(false);
  const navigate = useNavigate();
  const [disliked, setDisliked] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likedItems, setLikedItems] = useState([]);
  const [disLikedItems, setDisLikedItems] = useState([]);
  const [color, setColor] = useState("");
  const [question, setQuestion] = useState("");
  const [responseData, setResponseData] = useState("");
  const [pastQuery, setPastQuery] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [sourceFiles, setSourceFiles] = useState([]);
  const [questionsList, setQuestionList] = useState([]);
  const [pastQueries, setPastQueries] = useState([]);
  const [displayPastQueries, setDisplayPastQueries] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [selectedDocumentOption, setSelectedDocumentOption] = useState(null);
  const [displayQuery, setDisplayQuery] = useState({});
  const [isChatLoading, setChatLoading] = useState(false);
  const location = useLocation();
  const { sourceType } = location.state;
  const selectedSource = localStorage.getItem("selectedSource");
  const [queryList, setQueryList] = useState([]);
  const [assignMargin, setAssignMargin] = useState(0);
  const latestQuestionRef = useRef(null);
  const latestChatLoaderRef = useRef(null);
  const [tableData, setTableData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const isLiked = likedItems.includes(item.query);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState(sourceType ?? "Source");
  const [graphCode, setGraphCode] = useState('');
  const [iframeSrc, setIframeSrc] = useState('');
  const [showSettingsDropdown, setShowSettingsDropdown] = useState(false);
  const [checkedOptions, setCheckedOptions] = useState({
    sql_response: false,
    sql_table_response: true,
    sql_text_response: true,
    sql_graph_response: true
  });
  ChartJS.register(CategoryScale, LinearScale, Title, Tooltip, Legend);

  const [isDocumentPopupOpen, setDocumentPopupOpen] = useState(false);
  function download(data) {
    ////console.log("data", data);
    const url = URL.createObjectURL(data.data);
    const a = document.createElement("a");
    a.download = "test.pdf";
    a.href = url;
    a.target = "_self";

    a.click();
  }
  const [selectedTemparature, setSelectedTemparature] = useState(0.9);
  const [seletedTopp, setSelectedTopp] = useState(0.8);
  const [selectedLength, setSelectedLenth] = useState(4000);
  const [selectedDoc, setSelectedDoc] = useState(2);
  const [, forceUpdate] = useReducer((x) => x + 1, 0);
  const handleTemparature = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedTemparature(newValue);
    forceUpdate();
    ////console.log("Updated Temperature:", newValue);
  };

  const handleTop = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedTopp(newValue);
  };
  const handleLenth = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedLenth(newValue);
  };
  const handleDoc = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedDoc(newValue);
  };
  const openDocumentPopup = () => {
    setDocumentPopupOpen(true);
  };

  const closeDocumentPopup = () => {
    setDocumentPopupOpen(false);
  };
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();

  const startListening = () => {
    recognition.start();
    recognition.onresult = event => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setTranscript(transcript);
      setQuestion(transcript); // Automatically set the question from voice input
      search(transcript); // Optionally trigger search automatically
    };
    setIsListening(true);
  };

  const stopListening = () => {
    recognition.stop();
    setIsListening(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(UserLogsEndpoint());
        // Assuming your API response is an array as shown in your previous example
        setPastQueries(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []); // Empty dependency array ensures useEffect runs only once on mount

  const viewDocument = async (sourcePDF) => {
    //alert('Clicked URL:', sourcePDF);
    const grantDocuments = "gmg_job_Aids&sop/";
    const sourceFile = grantDocuments.concat(sourcePDF);
    ////console.log("sourceFile", sourceFile);
    //////console.log('Blob URL:', blobUrl);
    await axios.get(ViewEndpoint(sourceFile), {}).then((response) => {
      ////console.log("response", response?.data);
      openPdfInNewTab(response?.data);
      ////console.log(sourceFile, "sourceFile");
    });
    // openPdfInNewTab(response?.data)
  };
  const openPdfInNewTab = (response) => {
    const base64PdfData = response;
    const byteCharacters = atob(base64PdfData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });

    // Create a Blob URL for the PDF Blob
    const blobUrl = URL.createObjectURL(blob);

    // Open the PDF in a new tab
    window.open(blobUrl, "_blank");
  };
  const scrollToLatestQuestion = () => {
    // //console.log("hey its working");
    if (latestQuestionRef.current) {
      latestQuestionRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };
  /* //console.log(sourceType,'sourcetype'); */
  const scrollToLatestChatLoader = () => {
    if (latestChatLoaderRef.current) {
      latestChatLoaderRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  useEffect(
    () => {
      // Load liked items from localStorage on component mount
      const storedLikedItems = localStorage.getItem("likedItems");
      if (storedLikedItems) {
        setLikedItems(JSON.parse(storedLikedItems));
      }
      if (
        queryList?.length == 0 &&
        location.state &&
        location.state.question !== undefined
      ) {
        const { question, sourceType } = location.state;
        setQuestion(question);
        search(question);

        // const filteredQuery = questions.filter((data) => data.question === question)
        // setQuestionList(filteredQuery)
      }

      if (queryList.current != queryList) {
        scrollToLatestQuestion();
      }

      if (isChatLoading.current != isChatLoading) {
        scrollToLatestChatLoader();
        // scrollToLatestQuestion()
      }
      if (selectedSource) {
        setSelectedDocumentOption({
          value: selectedSource,
          label: selectedSource,
        });
      }
    },
    [queryList],
    isChatLoading,
    []
  );

  const closeModal = () => {
    setIsModalOpen(false);
  };
  //console.log(location, "loc")

  const closeCommentModal = () => {
    setIsCommentOpen(false);

    setSelectedId(null);
  };

  const CustomToast = ({ message, feedback, icon }) => (
    <div
      style={{ backgroundColor: "rgba(103, 187, 110, 1)", borderRadius: "5px" }}
      className="p-3"
    >
      <div className="d-flex flex-row pb-2 align-items-center">
        <img src={icon} alt="" />
        <span className="ml-2 toast-view-color">{feedback}</span>
      </div>
      <span className="mt-3 ml-2 mb-5 toast-view-subtext">{message}</span>
    </div>
  );
  const DocumentPopup = ({ closePopup, pageContent, pageNames }) => {
    return (

      <div className="document-popup">
        {/* Popup content goes here */}
        <div className="document-popup-content">
          {/* Displaying key content and page content */}
          <div className="page-content">
            {/* Displaying content for each page */}
            {pageContent.map((content, index) => (
              <div key={index} className="page-content-item">
                <h2 className="pdf-name">{pageNames[index]}</h2>
                <div className="horizontal-line"></div>
                <p className="justified-text">{content}</p>
              </div>
            ))}
          </div>
          {/* White background, OK button, and close icon */}
          <button onClick={closePopup} className="OkButton">
            OK
          </button>
          <span onClick={closePopup} className="close-icon">
            &times;
          </span>
        </div>
      </div>
    );
  };
 


  const styles = {
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected ? "#3366ff" : "white",
      color: state.isSelected ? "white" : "black",
    }),
    valueContainer: (base) => ({
      ...base,
      paddingLeft: 24,
    }),
    control: (base) => ({
      ...base,
      minHeight: 50,
      // width: 380,
      borderRadius: "0px 8px 8px 0px",
      border: "1px solid #ccc",
      borderLeftColor: "white",
    }),
    indicatorSeparator: (base) => ({
      ...base,
    }),
    dropdownIndicator: (base) => ({
      ...base,
      color: "grey",
    }),
  };

  const answerView = (text) => {
    // if (text === "question1") {
    return (
      <div>
        {text}

      </div>
    );
    // }
  };

  const search = (question) => {
    setChatLoading(true);

    if (question.trim() === "") {
      setChatLoading(false);
      toast.warning("Please type something.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return;
    }

    let endpoint = TextToSql(); // Use the TextToSql endpoint for both cases

    const payload = {
      query: question,
      source: selectedDropdown,
      k_similarity_docs: selectedDoc,
      temperature: selectedTemparature,
      top_p: seletedTopp,
      max_new_tokens: selectedLength,
      user: localStorage.getItem("userName"),
      sql_response: checkedOptions.sql_response,
      sql_table_response: checkedOptions.sql_table_response,
      sql_text_response: checkedOptions.sql_text_response,
      sql_graph_response: checkedOptions.sql_graph_response,
    };
    //console.log(payload);
    axios
      .post(endpoint, payload)
      .then((response) => {
        setChatLoading(false);

        if (selectedDropdown === "GNT01 SOPs and JobAids") {
          const responseData = response?.data;
          //console.log(responseData, "res");
          if (responseData) {
            const newEntry = {
              query: question,
              query_id: responseData.id,
              result: responseData.result || '', // Handle SOPs response structure
              source: selectedDropdown,
              page_content: responseData.page_content,
              sources: responseData.source_links || '',
              likes: responseData.likes,
              dislikes: responseData.dislikes,
              comments: responseData.comments,
            };
            // Add the new entry without modifying the existing state
            addToQueryListAndScroll(newEntry, response);

            const sourceDocs = newEntry.sources;
            const fileNames = sourceDocs.map((url) => {
              const parts = url.split("/");
              const fileNameWithExtension = parts[parts.length - 1];
              return fileNameWithExtension;
            });

            // Update sourceFiles for the current query
            setSourceFiles((prevSourceFiles) => [
              ...prevSourceFiles,
              { query: question, sourceFiles: fileNames },
            ]);
          } else {
            //console.log("Invalid response structure for SOPs", responseData);
          }
        } else if (selectedDropdown === "Grant Details") {
          const responseData = response?.data;

          if (responseData) {
            
            const newEntry = {
              query: question,
              query_id: responseData.id,
              result: responseData.result !== undefined ? responseData.result : '',
              sqlQuery: responseData.sql || '',
              table: responseData.table || '',
              result_text: responseData.result_text || '',
              graph_response:responseData.graph_response || '',
              source: selectedDropdown,
              likes: responseData.likes,
              iframeSrc: null,
              dislikes: responseData.dislikes,
              comments: responseData.comments,
            };

        // Extract column names from the first item in the data
        if (table.length > 0) {
          const columnNames = Object.keys(table[0]);

          // Create columns array dynamically
          const dynamicColumns = columnNames.map((key) => ({
            field: key,
            headerName: key.charAt(0).toUpperCase() + key.slice(1), // Capitalize first letter
            width: 150, // Adjust width as needed
          }));

          setColumns(dynamicColumns);
        }

        setTableData(table);
        setLoading(false);
           //const hdata=` `;
           if (responseData.graph_response) {
            const htmlContent = responseData.graph_response.trim();
            console.log("Graph HTML content:", htmlContent); // Debugging log
      
            // Check if the HTML content is valid
            if (htmlContent) {
              const blob = new Blob([htmlContent], { type: 'text/html' });
              const url = URL.createObjectURL(blob);
              console.log("Generated URL:", url); // Debugging log
      
              // Set the iframeSrc for the new entry
              newEntry.iframeSrc = url;
            } else {
              console.log("Graph response is empty or invalid."); // Debugging log
            }
          }
      
       
        
           
            // Add the new entry without modifying the existing state
            addToQueryListAndScroll(newEntry, response);
          } else {
            //console.log("Invalid response structure for Grants", responseData);
          }
        }
      })
      .catch((error) => {
        setChatLoading(false);
        console.error("Error occurred:", error);
      });

    setQuestion("");
  };

  // Function to add new entry to the state and scroll
  const addToQueryListAndScroll = (newEntry, response) => {
    setQueryList((prevQueryList) => [...prevQueryList, newEntry]);

    // Your scroll logic here
  };

  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };
  const handleDropdownChange = (event) => {
    setSelectedDropdown(event.target.value);
  };
  const selectLike = (query_id) => {
    if (likedItems.includes(query_id)) {
      // Show a popup indicating that the user has already liked this query
      // You can use a library like react-toastify to display the popup
      toast.warning("You already liked this query", {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        // ... (other toast options)
      });
      return;
    }

    // The user has not already liked the query, proceed with the API call
    axios
      .post(LikeEndPoint(), {

        query_id: query_id

      })
      .then((likeResponse) => {
        ////console.log("like response", likeResponse.data);
        const updateQuerylist = queryList.map((item) =>
          item.query_id === query_id
            ? {
              ...item,
              likes: item.likes + 1,
              liked: true,
              disliked: false,
            }
            : item
        );
        setQueryList(updateQuerylist);

        // Update likedItems state
        setLikedItems((prevLikedItems) => [...prevLikedItems, query_id]);
      })
      .catch((likeError) => {
        console.error("Error occurred while liking", likeError);
      });

    // Display a success message using toastify or any other notification library
    toast(
      <CustomToast
        message="Your feedback will help us to improve"
        icon={thumsupWhite}
        feedback="Thanks for your feedback"
      />,
      {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        closeButton: false,
        progress: undefined,
        style: {
          backgroundColor: "rgba(103, 187, 110, 1)",
          padding: "5px",
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
        },
        bodyClassName:
          "d-flex flex-row align-items-center justify-content-between",
      }
    );
  };

  const selectDislike = (query_id) => {

    if (disLikedItems.includes(query_id)) {
      // Show a popup indicating that the user has already disliked this query
      // You can use a library like react-toastify to display the popup
      toast.warning("You already Disliked this query", {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        // ... (other toast options)
      });
      return;
    }

    // The user has not already disliked the query, proceed with the API call
    axios
      .post(DisLikeEndPoint(), {

        query_id: query_id
      })
      .then((dislikeResponse) => {
        ////console.log("dislike response", dislikeResponse.data);
        const updateQuerylist = queryList.map((item) =>
          item.query_id === query_id
            ? {
              ...item,
              dislikes: item.dislikes + 1,
              liked: false,
              disliked: true,
            }
            : item
        );
        setQueryList(updateQuerylist);

        setAlreadyDisliked(true); // Set the flag indicating that the user has disliked
      })
      .catch((dislikeError) => {
        console.error("Error occurred while disliking", dislikeError);
      });
    // Open the comment section
    commentSection(query_id);
  };

  const commentSection = (query_id) => {

    setIsCommentOpen(true);
    setSelectedId(query_id);
  };
  const handleCopyToClipboard = (text) => {
    //  //console.log("Copying to clipboard:", text);
    navigator.clipboard
      .writeText(text)
      .then(() => {
        toast.success("Copied successfully:");
        // alert(`Copied to clipboard: ${text}`);
      })
      .catch((error) => {
        console.error("Failed to copy:", error);
        alert("Failed to copy to clipboard. Please try again.");
      });
  };

  const renderResultText = (text) => {
    return (
      <div>
        {text.split('\n').map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
    );
  };
  const textFileUrl = `${process.env.PUBLIC_URL}/pdfLinks.txt`;
  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    setCheckedOptions(prevState => ({
      ...prevState,
      [name]: checked
    }));
  };
  return (
    <>
      <div className="homepage-container">
        <TopbarNew />

        <div className="sidebar-and-content">
      

          <div className="homepage-content">
            <h5 className="assistant">Customer Insights Assistant</h5> &nbsp;&nbsp;
            <span>
              {selectedDropdown === "GNT01 SOPs and JobAids" ? (
                <a href={textFileUrl} target="_blank" rel="noopener noreferrer">
                  SOP JobAids Documents List
                </a>
              ) : (
                ''
              )}
            </span>
            <div
              className="col-12 d-flex justify-content-between queries-container"
              style={{ padding: "16px 16px 0px 16px" }}
            >



              <div
                className="d-flex flex-column justify-content-between w-100"
                style={{ paddingRight: "16px" }}
              >
                <div className="d-flex flex-column queries-widget mb-3">

                  {queryList?.map((item, index) => {

                    return (
                      <>
                        <div
                          className="d-flex flex-column mr-3 mb-4"
                          style={{ marginBottom: `${assignMargin}px` }}
                          ref={
                            index === queryList.length - 1
                              ? latestChatLoaderRef
                              : null
                          }
                        >
                          <div
                            className={
                              displayPastQueries
                                ? "max-width-100 d-flex flex-row w-100"
                                : "max-width-100 d-flex flex-row w-100"
                            }
                          >

                            <div className="d-flex flex-row p-1 align-items-center mt-2 w-100">

                              <img src={person} className="personicon" />&nbsp;<div className="queries-box-top -flex flex-row p-2 align-items-center mt-2 w-100">{item.query}</div>
                            </div>
                          </div>

                          <div
                            className={
                              displayPastQueries
                                ? "max-width-100 d-flex flex-column mt-2"
                                : "max-width-100 d-flex flex-column mt-2"
                            }
                          >
                            <div className="d-flex flex-row">
                              <GrRobot className="Robot1" />
                              <div className="d-flex flex-column queries-box-bottom w-100 p-2">
                                <div
                                  className="text-wrap p-2 mb-5"

                                >


                                  <div>
                                    {item.result !== "" ? (
                                      <TypingEffect text={item.result} delay={10} />
                                    ) : (
                                      <>
                                        <div className="sql-result-text">
                                          {checkedOptions.sql_text_response && item.result_text && (
                                            <div className="result-text-container">
                                              {renderResultText(item.result_text)}
                                            </div>
                                          )}
                                        </div>
                                      <div className="sql_result-query">
                                      {checkedOptions.sql_response && item.sqlQuery && (

<div className="code-snippet">
  <code>    {item.sqlQuery}</code>

</div>
)}
                                      </div>

                                        {checkedOptions.sql_table_response && item.table && (
                                          <div className="table-view">
                                            <span>Table:</span>
                                            <table>
                                              <tbody>
                                                {item.table.split('\n').map((row, index) => (
                                                  <tr key={index}>
                                                    {row.split(/\s{2,}/).map((cell, cellIndex) => (
                                                      <td key={cellIndex}>{cell}</td>
                                                    ))}
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </div>
                                        )}
                                       <div className="sql-graph">
                                       {checkedOptions.sql_graph_response && item.graph_response && (
      <div className="sql-graph">
        <div className="graph-container" style={{ height: '500px', width: '100%' }}>
         
          {item.iframeSrc ? (
            <iframe src={item.iframeSrc} style={{ width: '100%', height: '600px', border: 'none' }} />
          ) : (
            'No graph available'
          )}
        </div>
      </div>
    )}
            </div>
                                      </>
                                    )}
                                  </div>

                                </div>

                                <div
                                  className="d-flex flex-row"
                                  style={{ marginLeft: "50px" }}
                                >
                                  {item.liked ? (
                                    <FaThumbsUp
                                      style={{
                                        cursor: "pointer",
                                        color: "#43A047",
                                      }}
                                    />
                                  ) : (
                                    <FaRegThumbsUp
                                      style={{
                                        cursor: "pointer",
                                      }}
                                      onClick={() => selectLike(item.query_id)}
                                    />
                                  )}

                                  {item.disliked ? (
                                    <FaThumbsDown
                                      style={{
                                        cursor: "pointer",
                                        color: "red",
                                      }}
                                      className="ml-3"
                                    />
                                  ) : (
                                    <FaRegThumbsDown
                                      style={{
                                        cursor: "pointer",
                                      }}
                                      className="ml-3"
                                      onClick={() => selectDislike(item.query_id)}
                                    />
                                  )}

                                  {item.source === "GNT01 SOPs and JobAids" ?
                                    <FaRegCopy
                                      className="ml-3"
                                      style={{ cursor: "pointer" }}
                                      onClick={() =>
                                        handleCopyToClipboard(item.result)
                                      }
                                    /> : <FaRegCopy
                                      className="ml-3"
                                      style={{ cursor: "pointer" }}
                                      onClick={() =>
                                        handleCopyToClipboard(item.result_text)
                                      }
                                    />}
                                  {item.source === "GNT01 SOPs and JobAids" ?
                                    <>
                                      <FcDocument
                                        className="ml-3"
                                        style={{ cursor: "pointer" }}
                                        onClick={() => openDocumentPopup(item.result)}
                                      /> </> : null

                                  }

                                  {isDocumentPopupOpen && (
                                    <DocumentPopup
                                      closePopup={closeDocumentPopup}
                                      pageContent={item.page_content}
                                      pageNames={item.sources.map((url) => {
                                        const parts = url.split("/");
                                        return parts[parts.length - 1]; // Extracting the PDF name
                                      })}
                                    />
                                  )}


                                </div>
                                <div
                                  className={
                                    displayPastQueries
                                      ? "max-width-100 d-flex flex-row flex-wrap mt-3"
                                      : "max-width-100 d-flex flex-row flex-wrap mt-3"
                                  }
                                  style={{
                                    alignSelf: "flex-start",
                                    marginLeft: "50px",
                                  }}
                                >
                                  {Array.from(
                                    new Set(
                                      sourceFiles
                                        .find((entry) => entry.query === item.query)
                                        ?.sourceFiles ?? []
                                    )
                                  ).map((url, index) => {
                                    const parts = url.split('/');
                                    const fileNameWithExtension = parts[parts.length - 1];

                                    return (
                                      <div
                                        className="suggestions-border"
                                        key={index}
                                        style={{ fontSize: "10px" }}
                                        onClick={() => viewDocument(url)}
                                      >
                                        {fileNameWithExtension}
                                      </div>
                                    );
                                  })}
                                </div>

                              </div>

                            </div>
                          </div>
                        </div>
                      </>
                    );
                  })}

                  {queryList.length == 0 && isChatLoading ? (
                    <div className="bouncing-loader" ref={latestChatLoaderRef}>
                      <div></div>
                      <div></div>
                      <div></div>
                    </div>
                  ) : null}
                </div>
                {queryList.length !== 0 && isChatLoading ? (
                  <div className="bouncing-loader" ref={latestChatLoaderRef}>
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                ) : null}

                <div className="d-flex flex-row align-items-center justify-content-between flex-wrap mt-2 w-100">
               
               <>
 {selectedDropdown === "Grant Details" ? (
        <div className="checkbox-container">
          <label className={`checkbox-label ${checkedOptions.sql_text_response ? 'checked' : ''}`}>
            <input
              type="checkbox"
              name="sql_text_response "
              checked={checkedOptions.sql_text_response}
              onChange={handleCheckboxChange}
            />
            Plain Text
          </label>
          <label className={`checkbox-label ${checkedOptions.sql_response ? 'checked' : ''}`}>
            <input
              type="checkbox"
              name="sql_response"
              checked={checkedOptions.sql_response}
              onChange={handleCheckboxChange}
            />
            SQL Text
          </label>
          <label className={`checkbox-label ${checkedOptions.sql_table_response ? 'checked' : ''}`}>
            <input
              type="checkbox"
              name="sql_table_response"
              checked={checkedOptions.sql_table_response}
              onChange={handleCheckboxChange}
            />
            Table
          </label>
          <label className={`checkbox-label ${checkedOptions.sql_graph_response ? 'checked' : ''}`}>
            <input
              type="checkbox"
              name="sql_graph_response"
              checked={checkedOptions.sql_graph_response}
              onChange={handleCheckboxChange}
            />
            Graph
          </label>
        </div>
      ) : (
        ''
      )}
      </>
      <div className="query-color-input flex-row justify-content-between  mt-2 w-100">
                  <div className="d-flex flex-row flex-wrap col-10 pl-0 pr-0  w-100 search-input">
                    <FormControl variant="outlined" className="select-dropdown">
                      <InputLabel id="dropdown-label">Select Source</InputLabel>
                      <Select style={{ fontSize: '12px' }}
                        labelId="dropdown-label"
                        id="dropdown-basic"
                        value={selectedDropdown}
                        onChange={handleDropdownChange}
                        label="Select Source"
                        MenuProps={{
                          anchorOrigin: {
                            vertical: "top",
                            horizontal: "center",
                          },
                          transformOrigin: {
                            vertical: "bottom",
                            horizontal: "center",
                          },
                          getContentAnchorEl: null, // Remove default anchor positioning
                          elevation: 8, // Adjust elevation for the dropdown
                        }}
                        sx={{
                          ".MuiMenuItem-root": {
                            fontSize: "0.8rem", // Example: Increase MenuItem font size
                          },
                        }}
                      >
                      {/*   <MenuItem style={{ fontSize: '12px' }} value="Select Source">Select Source</MenuItem>
                        */} <MenuItem style={{ fontSize: '12px' }} value="GNT01 SOPs and JobAids">GNT01 SOPs and JobAids</MenuItem>
                        <MenuItem style={{ fontSize: '12px' }} value="Grant Details">Grant Details</MenuItem>
                      </Select>
                    </FormControl>

                    <input
                      placeholder="Type the question"
                      className="col-lg-12 col-md-12 col-sm-12 searchbar"
                      id="searchbar"
                      type="text"
                      value={transcript || question}
                      onChange={(event) => selectQuestion(event)}
                      onKeyPress={(event) => {
                        if (event.key === "Enter") {
                          search(question);
                        }
                      }}
                      onFocus={(event) => event.target.classList.add('input-focused')}
                      onBlur={(event) => event.target.classList.remove('input-focused')}
                    />



                    <img
                      className="voice-icon1"
                      onClick={isListening ? stopListening : startListening}
                      src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Google_mic.svg/716px-Google_mic.svg.png"
                      alt="Voice Search"
                    />


                    <IoMdSend className="send-icon1"
                      onClick={() => search(question)} />
                  </div>
               </div>
           
     
                </div>
      
              </div>

        

            </div>
          </div></div></div>

      <ToastContainer autoClose={false} draggable={false} />

      <Popup
        openModal={isCommentOpen}
        popupWidth={"600px"}
        buttonTop={"4px"}
        close={closeCommentModal}
        closeForm={closeModal}
        type="info"
        id={selectedId}
        toast={CustomToast}
        question={selectedQuery}
        source={selectedDropdown}
        k_similarity_docs={selectedDoc}
        temperature={selectedTemparature}
        top_p={seletedTopp}
        max_new_tokens={selectedLength}
      />

    </>
  );
};

export default Chat;
